package com.cedarsoftware.util;

import java.util.Map;

/**
 * Utility class containing common defensive programming helpers.
 * <p>
 * {@code Convention} offers a set of static convenience methods for
 * validating method arguments such as null checks or ensuring that a
 * string is not empty.  The class is not intended to be instantiated.
 */
public class Convention {

    /**
     * statically accessed class
     */
    private Convention() {
    }

//    /**
//     * Throws an exception if null
//     *
//     * @param value   object to check if null
//     * @param message message to use when thrown
//     * @throws IllegalArgumentException if the string passed in is null or empty
//     */
//    public static void throwIfNull(Object value, String message) {
//        if (value == null) {
//            throw new IllegalArgumentException(message);
//        }
//    }

    /**
     * Throws an exception if the logic is false.
     *
     * @param logic   test to see if we need to throw the exception.
     * @param message to include in the exception explaining why the the assertion failed
     */
    public static int throwIfFalse(boolean logic, String message) {
        if (!logic) {
//            throw new IllegalArgumentException(message);
            return -1;
        }
        return 0;
    }
}

package com.cedarsoftware.util;

import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Thread-safe wrapper for {@link SimpleDateFormat} with copy-on-write semantics.
 *
 * <p>Design goals:
 * <ul>
 *   <li>Source/binary compatible surface for existing users.</li>
 *   <li>Re-entrant and safe across threads (no shared mutable SDF instances).</li>
 *   <li>Performance: at most one {@code SimpleDateFormat} per thread per configuration.</li>
 *   <li>Mutators create a new immutable State; threads lazily rebuild their SDF (copy-on-write).</li>
 * </ul>
 *
 * <p>Hot path: no locks. Lookups happen in a per-thread LRU.</p>
 *
 * <p>For legacy code that used {@code SafeSimpleDateFormat.getDateFormat(pattern)}, this class
 * still provides the static accessor, returning a thread-local {@code SimpleDateFormat} keyed
 * only by pattern (same semantics as before).</p>
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public class SafeSimpleDateFormat  {
    private static final long serialVersionUID = 1L;

    // -------------------- Static legacy accessor (pattern-only) --------------------

    // Per-thread LRU for the static accessor (pattern -> SDF). Keeps original behavior.
    private static final int STATIC_PER_THREAD_LRU_CAPACITY = 16;
    private static final ThreadLocal<Map<String, SimpleDateFormat>> STATIC_TL =
            ThreadLocal.withInitial(() -> new LinkedHashMap<String, SimpleDateFormat>(24, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, SimpleDateFormat> eldest) {
                    return size() > STATIC_PER_THREAD_LRU_CAPACITY;
                }
            });


    /** Clears the static accessor's per-thread cache. */
    public static void clearStaticThreadLocalCache() {
        STATIC_TL.remove();
    }

    // -------------------- Instance-based safe API (copy-on-write) --------------------

}

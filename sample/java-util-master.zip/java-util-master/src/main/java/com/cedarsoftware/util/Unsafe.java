package com.cedarsoftware.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import com.cedarsoftware.util.ClassValueMap;


/**
 * Provides constructor-bypassing object instantiation using two strategies:
 * <ol>
 *   <li><b>ReflectionFactory</b> (preferred) — creates a synthetic constructor that runs
 *       {@code Object.<init>()} instead of the class's own constructors. This is the same
 *       mechanism used by {@code ObjectInputStream}. Fields get Java default values and the
 *       object header is properly initialized. May not be accessible on JDK 17+ without
 *       {@code --add-opens java.base/jdk.internal.reflect=ALL-UNNAMED}.</li>
 *   <li><b>sun.misc.Unsafe</b> (fallback) — allocates raw memory without any constructor call.
 *       Still accessible on current JDKs but deprecated for removal starting in JDK 26.</li>
 * </ol>
 *
 * @author Kai Hufenback
 *         John DeRegnaucourt (jdereg@cedarsoft.com)
 */
final class Unsafe {
    private final ClassValueMap<Constructor<?>> serializationConstructorCache = new ClassValueMap<>();

}

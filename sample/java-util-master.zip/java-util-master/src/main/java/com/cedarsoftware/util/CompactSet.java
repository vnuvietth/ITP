package com.cedarsoftware.util;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * A memory-efficient Set implementation that internally uses {@link CompactMap}.
 * <p>
 * This implementation provides the same memory benefits as CompactMap while
 * maintaining proper Set semantics. It can be configured for:
 * <ul>
 *     <li>Case sensitivity for String elements</li>
 *     <li>Element ordering (sorted, reverse, insertion)</li>
 *     <li>Custom compact size threshold</li>
 * </ul>
 * </p>
 *
 * <h2>Creating a CompactSet</h2>
 * Typically you will create one of the provided subclasses
 * ({@link CompactLinkedSet}, {@link CompactCIHashSet}, or
 * {@link CompactCILinkedSet}) or extend {@code CompactSet} with your own
 * configuration. The builder pattern is available for advanced cases.
 * <pre>{@code
 * CompactLinkedSet<String> set = new CompactLinkedSet<>();
 * set.add("hello");
 *
 * // Builder pattern
 * CompactSet<String> custom = CompactSet.<String>builder()
 *     .caseSensitive(false)
 *     .sortedOrder()
 *     .build();
 * }</pre>
 *
 * @param <E> the type of elements maintained by this set
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public class CompactSet<E>{

}

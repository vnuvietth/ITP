package com.cedarsoftware.util;

import java.util.Collection;

/**
 * A case-insensitive Set implementation that uses a compact internal representation
 * for small sets.  This Set exists to simplify JSON serialization. No custom reader nor
 * writer is needed to serialize this set.  It is a drop-in replacement for HashSet if
 * you want case-insensitive behavior for Strings and compactness.
 *
 * @param <E> the type of elements maintained by this set
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public class CompactCIHashSet<E> extends CompactSet<E> {

    protected boolean isCaseInsensitive() {
        return true;
    }

}

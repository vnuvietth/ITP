package com.cedarsoftware.util;

import java.util.AbstractSet;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * A Set implementation for Class objects that leverages a ClassValue cache for extremely
 * fast membership tests. This specialized collection is designed for scenarios where you
 * frequently need to check if a Class is a member of a set.
 *
 * <h2>Performance Advantages</h2>
 * <p>
 * ClassValueSet provides significantly faster {@code contains()} operations compared to standard
 * Set implementations:
 * <ul>
 *   <li>2-10x faster than HashSet for membership checks</li>
 *   <li>Faster than {@code ConcurrentHashMap.keySet()} for concurrent reads — <b>but only for a
 *       small number of instances.</b> The advantage inverts once many ClassValue-based collections
 *       compete on the same classes; read <a href="#constraints">Critical usage constraints</a>
 *       before adopting</li>
 *   <li>Most significant when a <b>few</b> instances are pre-populated and then checked repeatedly</li>
 * </ul>
 *
 * <p><b>Not a general-purpose "faster {@code Set<Class>}".</b> This is a specialist for a narrow
 * niche (few instances, pre-populated, read-mostly). Outside it a plain
 * {@link java.util.concurrent.ConcurrentHashMap#newKeySet() ConcurrentHashMap.newKeySet()} is as
 * fast or faster — see <a href="#constraints">Critical usage constraints</a>.
 *
 * <h2>Typed fast path: {@link #containsClass(Class)}</h2>
 * <p>
 * The standard {@link #contains(Object)} method must accept an {@code Object} and perform both
 * a null check and a runtime {@code o.getClass() != Class.class} guard before routing to the
 * {@link ClassValue} cache (non-{@code Class} inputs return {@code false}). When the caller
 * already knows the input is a {@code Class}, {@link #containsClass(Class)} skips both guards
 * and compiles to a near-direct {@link ClassValue#get(Class)} call — a JIT-intrinsified,
 * identity-based per-{@code Class} load.
 * <p>
 * For performance-critical call sites, prefer {@code containsClass(Class)}. To take advantage of
 * it, hold the field as {@code ClassValueSet} (not {@code Set<Class<?>>}), so the compiler
 * resolves the typed lookup statically.
 *
 * <h2>How It Works</h2>
 * <p>
 * The implementation utilizes Java's {@link ClassValue} mechanism, which is specially optimized
 * in the JVM through:
 * <ul>
 *   <li>Thread-local caching for reduced contention</li>
 *   <li>Identity-based lookups (faster than equality checks)</li>
 *   <li>Special VM support that connects directly to Class metadata structures</li>
 *   <li>Optimized memory layout that can reduce cache misses</li>
 * </ul>
 *
 * <h2>Ideal Use Cases</h2>
 * <p>
 * ClassValueSet is ideal for:
 * <ul>
 *   <li>High read-to-write ratio scenarios (read-mostly workloads)</li>
 *   <li>Relatively static sets of classes that are checked frequently</li>
 *   <li>Performance-critical operations in hot code paths</li>
 *   <li>Security blocklists (checking if a class is forbidden)</li>
 *   <li>Feature flags or capability testing based on class membership</li>
 *   <li>Type handling in serialization/deserialization frameworks</li>
 * </ul>
 *
 * <h2>Trade-offs</h2>
 * <p>
 * The performance benefits come with some trade-offs:
 * <ul>
 *   <li>Higher memory usage (maintains both a backing set and ClassValue cache)</li>
 *   <li>Write operations (add/remove) aren't faster and may be slightly slower</li>
 *   <li>Only Class objects benefit from the optimized lookups</li>
 *   <li>Elements are strongly referenced: a long-lived (e.g. static) set pins its member
 *       {@code Class} objects and their {@code ClassLoader}s until they are removed or the
 *       set is cleared. Do not use a long-lived set to accumulate dynamically-loaded classes
 *       (the {@link ClassValue}-side cache entries live inside each {@code Class} and do not
 *       pin anything; only the backing set's strong references do)</li>
 * </ul>
 *
 * <h2 id="constraints">Critical usage constraints (read before adopting)</h2>
 * <p>
 * Use {@code ClassValueSet} only when <b>all</b> of the following hold; otherwise prefer a plain
 * {@link java.util.concurrent.ConcurrentHashMap#newKeySet() ConcurrentHashMap.newKeySet()}:
 * <ul>
 *   <li><b>Few instances — the cost is non-local.</b> ClassValue's speed comes from a per-{@code
 *       Class} fast cache, but the JVM gives every {@code Class} <em>one</em> small, fixed-capacity
 *       cache array <b>shared across all {@link ClassValue} instances</b> (open-addressed, probe
 *       limit of 3). Every {@code ClassValueSet} is a distinct {@code ClassValue}, so many of them
 *       keyed on the same classes evict one another from that array and each membership test falls
 *       through to a slower backup path. This set's performance therefore depends on how many
 *       <em>other</em> ClassValue-based collections exist in the JVM — unlike any ordinary {@code
 *       Set}. The advantage holds for a handful and <b>inverts</b> once ~10+ compete on the same
 *       classes.</li>
 *   <li><b>Pre-populated, not lazily built.</b> Build it once and then read. {@link #add}/{@link
 *       #remove} invalidate this set's {@code ClassValue}, which the JVM implements by bumping a
 *       version that drops <em>every</em> cached entry, so mutating on a hot path repeatedly
 *       re-validates the whole cache. Use a plain {@code ConcurrentHashMap.newKeySet()} for
 *       frequently-mutated sets.</li>
 *   <li><b>Not a leak-safe class set</b> — see the strong-reference note under Trade-offs above.</li>
 * </ul>
 *
 * <h2>Thread Safety</h2>
 * <p>
 * This implementation is thread-safe for all operations.
 *
 * <h2>Usage Example</h2>
 * <pre>{@code
 * // Create a set of blocked classes for security checks
 * ClassValueSet blockedClasses = ClassValueSet.of(
 *     ClassLoader.class,
 *     Runtime.class,
 *     ProcessBuilder.class
 * );
 *
 * // Fast membership check in a security-sensitive context — containsClass
 * // skips the null check + instanceof-Class guard that contains(Object) must perform.
 * public void verifyClass(Class<?> clazz) {
 *     if (blockedClasses.containsClass(clazz)) {
 *         throw new SecurityException("Access to " + clazz.getName() + " is not allowed");
 *     }
 * }
 * }</pre>
 *
 * <h2>Important Performance Warning</h2>
 * <p>
 * Wrapping this class with standard collection wrappers like {@code Collections.unmodifiableSet()}
 * will destroy the {@code ClassValue} performance benefits. Always use the raw {@code ClassValueSet} directly
 * or use the provided {@code unmodifiableView()} method if immutability is required. Note that
 * {@code unmodifiableView()} returns a {@code Set<Class<?>>}, which does not expose
 * {@link #containsClass(Class)} — callers that need the typed fast path should hold the view as
 * a reference to the raw {@code ClassValueSet}.
 *
 * @see ClassValue
 * @see Set
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public class ClassValueSet {

}

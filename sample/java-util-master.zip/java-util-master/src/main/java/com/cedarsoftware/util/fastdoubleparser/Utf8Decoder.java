/*
 * @(#)Utf8Decoder.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

/**
 * Decodes UTF-8 encoded bytes to a character array.
 */
final class Utf8Decoder {
    private Utf8Decoder() {
    }

}

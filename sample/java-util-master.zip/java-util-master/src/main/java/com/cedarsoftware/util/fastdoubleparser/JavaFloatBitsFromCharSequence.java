/*
 * @(#)JavaFloatBitsFromCharSequence.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

/**
 * Parses a {@code float} from a {@link CharSequence}.
 */
final class JavaFloatBitsFromCharSequence  {


    /**
     * Creates a new instance.
     */
    public JavaFloatBitsFromCharSequence() {

    }


}
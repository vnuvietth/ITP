/*
 * @(#)FastDoubleMath.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

import static com.cedarsoftware.util.fastdoubleparser.FastIntegerMath.unsignedMultiplyHigh;

/**
 * This class provides the mathematical functions needed by {@link JavaDoubleParser}.
 * <p>
 * References:
 * <dl>
 *     <dt>Daniel Lemire, fast_float number parsing library: 4x faster than strtod.
 *     <a href="https://github.com/fastfloat/fast_float/blob/dc88f6f882ac7eb8ec3765f633835cb76afa0ac2/LICENSE-MIT">MIT License</a>.</dt>
 *     <dd><a href="https://github.com/fastfloat/fast_float">github.com</a></dd>
 *
 *     <dt>Daniel Lemire, Number Parsing at a Gigabyte per Second,
 *     Software: Practice and Experience 51 (8), 2021.
 *     arXiv.2101.11408v3 [cs.DS] 24 Feb 2021</dt>
 *     <dd><a href="https://arxiv.org/pdf/2101.11408.pdf">arxiv.org</a></dd>
 *
 *     <dt>Clinger WD (1990). How to read floating point numbers accurately. ACM SIGPLAN Notices.</dt>
 *     <dd>- no link -</dd>
 * </dl>
 * </p>
 */
final class FastDoubleMath {

    /**
     * Don't let anyone instantiate this class.
     */
    private FastDoubleMath() {

    }

}
/*
 * @(#)JavaDoubleBitsFromCharArray.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

/**
 * Parses a {@code double} from a {@code char} array.
 */
final class JavaDoubleBitsFromCharArray {

    /**
     * Creates a new instance.
     */
    public JavaDoubleBitsFromCharArray() {

    }

}
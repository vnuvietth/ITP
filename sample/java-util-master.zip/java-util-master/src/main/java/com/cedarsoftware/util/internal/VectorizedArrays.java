package com.cedarsoftware.util.internal;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.Arrays;

import com.cedarsoftware.util.SystemUtilities;

public final class VectorizedArrays {


    public VectorizedArrays() {
        // no instances
    }

    public static boolean equalsRangeLoop(char[] a, int aFrom, int aTo, char[] b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        if (aLen != bTo - bFrom) return false;
        for (int i = 0; i < aLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return false;
        }
        return true;
    }

    public static boolean equalsRangeLoop(byte[] a, int aFrom, int aTo, byte[] b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        if (aLen != bTo - bFrom) return false;
        for (int i = 0; i < aLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return false;
        }
        return true;
    }


    public static int mismatchRangeLoop(char[] a, int aFrom, int aTo, char[] b, int bFrom, int bTo) {
        int aLen = aTo - aFrom, bLen = bTo - bFrom;
        int common = Math.min(aLen, bLen);
        for (int i = 0; i < common; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return i;
        }
        return aLen == bLen ? -1 : common;
    }

    public static int mismatchRangeLoop(byte[] a, int aFrom, int aTo, byte[] b, int bFrom, int bTo) {
        int aLen = aTo - aFrom, bLen = bTo - bFrom;
        int common = Math.min(aLen, bLen);
        for (int i = 0; i < common; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return i;
        }
        return aLen == bLen ? -1 : common;
    }

    public static int compareRangeLoop(char[] a, int aFrom, int aTo, char[] b, int bFrom, int bTo) {
        int aLen = aTo - aFrom, bLen = bTo - bFrom;
        int common = Math.min(aLen, bLen);
        for (int i = 0; i < common; i++) {
            char ac = a[aFrom + i], bc = b[bFrom + i];
            if (ac != bc) return Character.compare(ac, bc);
        }
        return Integer.compare(aLen, bLen);
    }

    public static int compareRangeLoop(byte[] a, int aFrom, int aTo, byte[] b, int bFrom, int bTo) {
        int aLen = aTo - aFrom, bLen = bTo - bFrom;
        int common = Math.min(aLen, bLen);
        for (int i = 0; i < common; i++) {
            byte ab = a[aFrom + i], bb = b[bFrom + i];
            if (ab != bb) return Byte.compare(ab, bb);
        }
        return Integer.compare(aLen, bLen);
    }
}

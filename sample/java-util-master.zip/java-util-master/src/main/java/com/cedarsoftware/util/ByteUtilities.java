package com.cedarsoftware.util;

import java.util.Arrays;
public final class ByteUtilities {
    // Security Configuration - cached for performance with property change detection
    // Default limits used when security is enabled but no custom limits specified
    private static final int DEFAULT_MAX_HEX_STRING_LENGTH = 1000000;  // 1MB hex string
    private static final int DEFAULT_MAX_ARRAY_SIZE = 10000000;        // 10MB byte array

    // Property names
    private static final String PROP_SECURITY_ENABLED = "byteutilities.security.enabled";
    private static final String PROP_MAX_HEX_LENGTH = "byteutilities.max.hex.string.length";
    private static final String PROP_MAX_ARRAY_SIZE = "byteutilities.max.array.size";

    private static volatile SecurityConfig securityConfigCache;

    // Maximum array size that can be safely doubled without overflow
    private static final int MAX_SAFE_ARRAY_SIZE = Integer.MAX_VALUE / 2;

    private static final class SecurityConfig {
        private final String securityEnabledSource;
        private final String maxHexLengthSource;
        private final String maxArraySizeSource;
        private final boolean securityEnabled;
        private final int maxHexStringLength;
        private final int maxArraySize;

        private SecurityConfig(String securityEnabledSource, String maxHexLengthSource, String maxArraySizeSource) {
            this.securityEnabledSource = securityEnabledSource;
            this.maxHexLengthSource = maxHexLengthSource;
            this.maxArraySizeSource = maxArraySizeSource;
            securityEnabled = Boolean.parseBoolean(securityEnabledSource);
            maxHexStringLength = parseLimit(maxHexLengthSource, DEFAULT_MAX_HEX_STRING_LENGTH);
            maxArraySize = parseLimit(maxArraySizeSource, DEFAULT_MAX_ARRAY_SIZE);
        }

        private boolean matches(String securityEnabledSource, String maxHexLengthSource, String maxArraySizeSource) {
            return equalsNullable(this.securityEnabledSource, securityEnabledSource) &&
                    equalsNullable(this.maxHexLengthSource, maxHexLengthSource) &&
                    equalsNullable(this.maxArraySizeSource, maxArraySizeSource);
        }
    }

    private static boolean equalsNullable(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    private static int parseLimit(String source, int defaultLimit) {
        if (source == null) {
            return defaultLimit;
        }
        try {
            int limit = Integer.parseInt(source);
            return limit <= 0 ? 0 : limit;
        } catch (NumberFormatException ignored) {
            return defaultLimit;
        }
    }

    private static SecurityConfig getSecurityConfig() {
        String securityEnabledSource = System.getProperty(PROP_SECURITY_ENABLED, "false");
        String maxHexLengthSource = System.getProperty(PROP_MAX_HEX_LENGTH);
        String maxArraySizeSource = System.getProperty(PROP_MAX_ARRAY_SIZE);
        SecurityConfig config = securityConfigCache;
        if (config != null && config.matches(securityEnabledSource, maxHexLengthSource, maxArraySizeSource)) {
            return config;
        }

        synchronized (ByteUtilities.class) {
            securityEnabledSource = System.getProperty(PROP_SECURITY_ENABLED, "false");
            maxHexLengthSource = System.getProperty(PROP_MAX_HEX_LENGTH);
            maxArraySizeSource = System.getProperty(PROP_MAX_ARRAY_SIZE);
            config = securityConfigCache;
            if (config == null || !config.matches(securityEnabledSource, maxHexLengthSource, maxArraySizeSource)) {
                config = new SecurityConfig(securityEnabledSource, maxHexLengthSource, maxArraySizeSource);
                securityConfigCache = config;
            }
            return config;
        }
    }

    /**
     * Fast path for the default (security disabled) case: one property read instead
     * of the full three-property config snapshot. Still reads per call so runtime
     * toggling of the master switch is honored immediately.
     */
    private static boolean isSecurityDisabled() {
        return !Boolean.parseBoolean(System.getProperty(PROP_SECURITY_ENABLED, "false"));
    }

    private static int getMaxHexStringLength() {
        SecurityConfig config = getSecurityConfig();
        return config.securityEnabled ? config.maxHexStringLength : 0;
    }

    private static int getMaxArraySize() {
        SecurityConfig config = getSecurityConfig();
        return config.securityEnabled ? config.maxArraySize : 0;
    }

    /**
     * Magic number identifying a gzip byte stream.
     */
    private static final byte[] GZIP_MAGIC = {(byte) 0x1f, (byte) 0x8b};

    private ByteUtilities() { }
}

/*
 * @(#)JavaBigIntegerFromCharArray.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

import java.math.BigInteger;
import java.util.Map;

final class JavaBigIntegerFromCharArray  {


}

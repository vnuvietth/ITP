package com.cedarsoftware.util;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.File;
import java.io.Flushable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URLConnection;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Locale;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

/**
 * Utility class providing robust I/O operations with built-in error handling and resource management.
 * <p>
 * This class simplifies common I/O tasks such as:
 * </p>
 * <ul>
 *   <li>Stream transfers and copying</li>
 *   <li>Resource closing and flushing</li>
 *   <li>Byte array compression/decompression</li>
 *   <li>URL connection handling</li>
 *   <li>File operations</li>
 * </ul>
 *
 * <p><strong>Key Features:</strong></p>
 * <ul>
 *   <li>Automatic buffer management for optimal performance</li>
 *   <li>GZIP and Deflate compression support</li>
 *   <li>Unchecked exception handling for close/flush operations (fail-fast, not silent)</li>
 *   <li>Progress tracking through callback mechanism</li>
 *   <li>Support for XML stream operations with unchecked exception handling</li>
 *   <li>
 *     <b>XML stream support:</b> Methods {@link #close(XMLStreamReader)}, {@link #close(XMLStreamWriter)},
 *     and {@link #flush(XMLStreamWriter)} work with {@code javax.xml.stream} classes.
 *     <b>These methods require the {@code java.xml} module to be present at runtime.</b>
 *     If you're using JPMS, add {@code requires java.xml;} to your module-info.java if using these methods.
 *     For OSGi, ensure your bundle imports the {@code javax.xml.stream} package or declare it as an optional import
 *     if XML support is not required. The rest of the library does <b>not</b> require {@code java.xml}.
 *   </li>
 * </ul>
 * <p>
 * <b>Exception Handling Philosophy:</b> All close() and flush() methods in this class throw exceptions as
 * <b>unchecked</b> via {@link ExceptionUtilities#uncheckedThrow(Throwable)}. This design choice provides:
 * <ul>
 *   <li>Cleaner code - no try-catch required in finally blocks or cleanup code</li>
 *   <li>Better diagnostics - close/flush failures are visible rather than silently swallowed</li>
 *   <li>Early problem detection - infrastructure issues surface immediately rather than hiding until later failures</li>
 *   <li>Flexibility - callers can catch these as regular exceptions higher in the call stack if desired</li>
 * </ul>
 * While close/flush exceptions are rare, they often indicate serious issues (disk full, network failures,
 * resource exhaustion) that should be diagnosed rather than hidden.
 * </p>
 *
 * <p><strong>Usage Example:</strong></p>
 * <pre>{@code
 * // Copy file to output stream
 * try (InputStream fis = Files.newInputStream(Paths.get("input.txt"))) {
 *     try (OutputStream fos = Files.newOutputStream(Paths.get("output.txt"))) {
 *         IOUtilities.transfer(fis, fos);
 *     }
 * }
 *
 * // Compress byte array
 * byte[] compressed = IOUtilities.compressBytes(originalBytes);
 * byte[] uncompressed = IOUtilities.uncompressBytes(compressed);
 * }</pre>
 *
 * <p><strong>Security and Performance Configuration:</strong></p>
 * <p>IOUtilities provides configurable security and performance options through system properties.
 * Most security features have <strong>safe defaults</strong> but can be customized as needed:</p>
 * <ul>
 *   <li><code>io.debug=false</code> &mdash; Enable debug logging</li>
 *   <li><code>io.connect.timeout=5000</code> &mdash; Connection timeout (1s-5min)</li>
 *   <li><code>io.read.timeout=30000</code> &mdash; Read timeout (1s-5min)</li>
 *   <li><code>io.max.stream.size=2147483647</code> &mdash; Stream size limit (2GB)</li>
 *   <li><code>io.max.decompression.size=2147483647</code> &mdash; Decompression size limit (2GB)</li>
 *   <li><code>io.path.validation.disabled=false</code> &mdash; Path security validation enabled</li>
 *   <li><code>io.url.protocol.validation.disabled=false</code> &mdash; URL protocol validation enabled</li>
 *   <li><code>io.allowed.protocols=http,https,file,jar</code> &mdash; Allowed URL protocols</li>
 *   <li><code>io.file.protocol.validation.disabled=false</code> &mdash; File protocol validation enabled</li>
 *   <li><code>io.debug.detailed.urls=false</code> &mdash; Detailed URL logging disabled</li>
 *   <li><code>io.debug.detailed.paths=false</code> &mdash; Detailed path logging disabled</li>
 * </ul>
 *
 * @author Ken Partlow
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public final class IOUtilities {
    private static final int TRANSFER_BUFFER = 32768;
    private static final int DEFAULT_CONNECT_TIMEOUT = 5000;
    private static final int DEFAULT_READ_TIMEOUT = 30000;
    private static final int MIN_TIMEOUT = 1000;  // Minimum 1 second to prevent DoS
    private static final int MAX_TIMEOUT = 300000; // Maximum 5 minutes to prevent resource exhaustion
    private static final String PROP_CONNECT_TIMEOUT = "io.connect.timeout";
    private static final String PROP_READ_TIMEOUT = "io.read.timeout";
    private static final String PROP_MAX_STREAM_SIZE = "io.max.stream.size";
    private static final String PROP_MAX_DECOMPRESSION_SIZE = "io.max.decompression.size";
    private static final String PROP_ALLOWED_PROTOCOLS = "io.allowed.protocols";
    private static final String DEFAULT_ALLOWED_PROTOCOLS = "http,https,file,jar";
    private static final boolean DEBUG = Boolean.parseBoolean(System.getProperty("io.debug", "false"));
    private static final Logger LOG = Logger.getLogger(IOUtilities.class.getName());
    private static final Object CONFIG_CACHE_LOCK = new Object();
    private static volatile String cachedConnectTimeoutProperty;
    private static volatile int cachedConnectTimeout = DEFAULT_CONNECT_TIMEOUT;
    private static volatile String cachedReadTimeoutProperty;
    private static volatile int cachedReadTimeout = DEFAULT_READ_TIMEOUT;
    private static volatile String cachedMaxStreamSizeProperty;
    private static volatile int cachedMaxStreamSize = Integer.MAX_VALUE;
    private static volatile String cachedMaxDecompressionSizeProperty;
    private static volatile int cachedMaxDecompressionSize = Integer.MAX_VALUE;
    private static volatile String cachedAllowedProtocolsProperty = DEFAULT_ALLOWED_PROTOCOLS;
    private static volatile String[] cachedAllowedProtocols = {"http", "https", "file", "jar"};

    private static void debug(String msg, Exception e) {
        if (DEBUG) {
            if (e == null) {
                LOG.fine(msg);
            } else {
                LOG.log(Level.FINE, msg, e);
            }
        }
    }

    private IOUtilities() { }

}

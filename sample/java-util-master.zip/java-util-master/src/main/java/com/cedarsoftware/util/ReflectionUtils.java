package com.cedarsoftware.util;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.AbstractMap;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Utilities to simplify writing reflective code as well as improve performance of reflective operations like
 * method and annotation lookups.
 *
 * <h2>Security Configuration</h2>
 * <p>ReflectionUtils provides configurable security controls to prevent various attack vectors including
 * unauthorized access to dangerous classes, sensitive field exposure, and reflection-based attacks.
 * All security features are <strong>disabled by default</strong> for backward compatibility.</p>
 *
 * <p>Security controls can be enabled via system properties:</p>
 * <ul>
 *   <li><code>reflectionutils.security.enabled=false</code> &mdash; Master switch for all security features</li>
 *   <li><code>reflectionutils.dangerous.class.validation.enabled=false</code> &mdash; Block dangerous class access</li>
 *   <li><code>reflectionutils.sensitive.field.validation.enabled=false</code> &mdash; Block sensitive field access</li>
 *   <li><code>reflectionutils.max.cache.size=50000</code> &mdash; Maximum cache size per cache type</li>
 *   <li><code>reflectionutils.dangerous.class.patterns=java.lang.Runtime,java.lang.Process,...</code> &mdash; Comma-separated dangerous class patterns</li>
 *   <li><code>reflectionutils.sensitive.field.patterns=password,secret,apikey,...</code> &mdash; Comma-separated sensitive field patterns</li>
 * </ul>
 *
 * <h3>Security Features</h3>
 * <ul>
 *   <li><b>Dangerous Class Protection:</b> Prevents reflection access to system classes that could enable privilege escalation</li>
 *   <li><b>Sensitive Field Protection:</b> Blocks access to fields containing sensitive information (passwords, tokens, etc.)</li>
 *   <li><b>Cache Size Limits:</b> Configurable limits to prevent memory exhaustion attacks</li>
 *   <li><b>Trusted Caller Validation:</b> Allows java-util library internal access while blocking external callers</li>
 * </ul>
 *
 * <h3>Usage Example</h3>
 * <pre>{@code
 * // Enable security with custom settings
 * System.setProperty("reflectionutils.security.enabled", "true");
 * System.setProperty("reflectionutils.dangerous.class.validation.enabled", "true");
 * System.setProperty("reflectionutils.sensitive.field.validation.enabled", "true");
 * System.setProperty("reflectionutils.max.cache.size", "10000");
 *
 * // These will now enforce security controls
 * Method method = ReflectionUtils.getMethod(String.class, "valueOf", int.class);
 * Field field = ReflectionUtils.getField(MyClass.class, "normalField");
 * }</pre>
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public final class ReflectionUtils {
    /** System property key controlling the reflection cache size. */
    private static final String CACHE_SIZE_PROPERTY = "reflection.utils.cache.size";
    private static final int DEFAULT_CACHE_SIZE = 1500;
    private static final int DEFAULT_MAX_CACHE_SIZE = 50000; // Default max to prevent memory exhaustion
    
    private static final Logger LOG = Logger.getLogger(ReflectionUtils.class.getName());
    
    // Default dangerous class patterns (moved to system properties in static initializer)
    private static final String DEFAULT_DANGEROUS_CLASS_PATTERNS = 
        "java.lang.Runtime,java.lang.Process,java.lang.ProcessBuilder,sun.misc.Unsafe,jdk.internal.misc.Unsafe,javax.script.ScriptEngine,javax.script.ScriptEngineManager";
    
    // Default sensitive field patterns (moved to system properties in static initializer)
    private static final String DEFAULT_SENSITIVE_FIELD_PATTERNS = 
        "password,passwd,secret,secretkey,apikey,api_key,authtoken,accesstoken,credential,confidential,adminkey,private";
    
    // Removed static initializer that was mutating System properties
    // Properties are now only read, not set
    
    // Security configuration methods
    
    private static boolean isSecurityEnabled() {
        return Boolean.parseBoolean(System.getProperty("reflectionutils.security.enabled", "false"));
    }

    private static boolean isDangerousClassValidationEnabled() {
        return Boolean.parseBoolean(System.getProperty("reflectionutils.dangerous.class.validation.enabled", "false"));
    }

    private static boolean isSensitiveFieldValidationEnabled() {
        return Boolean.parseBoolean(System.getProperty("reflectionutils.sensitive.field.validation.enabled", "false"));
    }
    
    private static int getMaxCacheSize() {
        String maxSizeProp = System.getProperty("reflectionutils.max.cache.size");
        if (maxSizeProp != null) {
            try {
                return Math.max(1, Integer.parseInt(maxSizeProp));
            } catch (NumberFormatException e) {
                // Fall through to default
            }
        }
        return isSecurityEnabled() ? DEFAULT_MAX_CACHE_SIZE : Integer.MAX_VALUE;
    }
    
    // Single volatile reference pairs a property string with its parsed pattern set,
    // ensuring atomic visibility of both values (no TOCTOU race).
    private static volatile Map.Entry<String, Set<String>> cachedDangerousClass = null;
    private static volatile Map.Entry<String, Set<String>> cachedSensitiveField = null;

    private static Set<String> getDangerousClassPatterns() {
        String currentProperty = System.getProperty("reflectionutils.dangerous.class.patterns", DEFAULT_DANGEROUS_CLASS_PATTERNS);
        Map.Entry<String, Set<String>> holder = cachedDangerousClass;
        if (holder != null && currentProperty.equals(holder.getKey())) {
            return holder.getValue();
        }
        Set<String> set = new HashSet<>();
        for (String pattern : currentProperty.split(",")) {
            String trimmed = pattern.trim();
            if (!trimmed.isEmpty()) {
                set.add(trimmed);
            }
        }
        Set<String> patterns = Collections.unmodifiableSet(set);
        cachedDangerousClass = new AbstractMap.SimpleImmutableEntry<>(currentProperty, patterns);
        return patterns;
    }

    private static Set<String> getSensitiveFieldPatterns() {
        String currentProperty = System.getProperty("reflectionutils.sensitive.field.patterns", DEFAULT_SENSITIVE_FIELD_PATTERNS);
        Map.Entry<String, Set<String>> holder = cachedSensitiveField;
        if (holder != null && currentProperty.equals(holder.getKey())) {
            return holder.getValue();
        }
        Set<String> set = new HashSet<>();
        for (String pattern : currentProperty.split(",")) {
            String processed = pattern.trim().toLowerCase();
            if (!processed.isEmpty()) {
                set.add(processed);
            }
        }
        Set<String> patterns = Collections.unmodifiableSet(set);
        cachedSensitiveField = new AbstractMap.SimpleImmutableEntry<>(currentProperty, patterns);
        return patterns;
    }
    
    private static final int CACHE_SIZE = Math.max(1, Math.min(getMaxCacheSize(),
            Integer.getInteger(CACHE_SIZE_PROPERTY, DEFAULT_CACHE_SIZE)));


    /**
     * Selects the most appropriate method using a composite selection strategy.
     * Selection criteria are applied in order of priority.
     */
    private static Method selectMethod(List<Method> candidates) {
        return candidates.stream()
                .min((m1, m2) -> {
                    // First, prefer non-synthetic/non-bridge methods
                    if (m1.isSynthetic() != m2.isSynthetic()) {
                        return m1.isSynthetic() ? 1 : -1;
                    }
                    if (m1.isBridge() != m2.isBridge()) {
                        return m1.isBridge() ? 1 : -1;
                    }

                    // Then, prefer more accessible methods
                    int accessDiff = getAccessibilityScore(m2.getModifiers()) -
                            getAccessibilityScore(m1.getModifiers());
                    if (accessDiff != 0) return accessDiff;

                    // Finally, prefer methods declared in most specific class
                    if (m1.getDeclaringClass().isAssignableFrom(m2.getDeclaringClass())) return 1;
                    if (m2.getDeclaringClass().isAssignableFrom(m1.getDeclaringClass())) return -1;

                    return 0;
                })
                .orElse(candidates.get(0));
    }

    /**
     * Returns an accessibility score for method modifiers.
     * Higher scores indicate greater accessibility.
     */
    private static int getAccessibilityScore(int modifiers) {
        if (Modifier.isPublic(modifiers)) return 4;
        if (Modifier.isProtected(modifiers)) return 3;
        if (Modifier.isPrivate(modifiers)) return 1;
        return 2; // package-private
    }

    /**
     * Return the name of the class on the object, or "null" if the object is null.
     * @param o Object to get the class name.
     * @return String name of the class or "null"
     */
    public static String getClassName(Object o) {
        return o == null ? "null" : o.getClass().getName();
    }

    // Constant pool tags
    private final static int CONSTANT_UTF8 = 1;
    private final static int CONSTANT_INTEGER = 3;
    private final static int CONSTANT_FLOAT = 4;
    private final static int CONSTANT_LONG = 5;
    private final static int CONSTANT_DOUBLE = 6;
    private final static int CONSTANT_CLASS = 7;
    private final static int CONSTANT_STRING = 8;
    private final static int CONSTANT_FIELDREF = 9;
    private final static int CONSTANT_METHODREF = 10;
    private final static int CONSTANT_INTERFACEMETHODREF = 11;
    private final static int CONSTANT_NAMEANDTYPE = 12;
    private final static int CONSTANT_METHODHANDLE = 15;
    private final static int CONSTANT_METHODTYPE = 16;
    private final static int CONSTANT_DYNAMIC = 17;
    private final static int CONSTANT_INVOKEDYNAMIC = 18;
    private final static int CONSTANT_MODULE = 19;
    private final static int CONSTANT_PACKAGE = 20;

    /**
     * Given a byte[] of a Java .class file (compiled Java), this code will retrieve the class name from those bytes.
     * This method supports class files up to the latest JDK version.
     *
     * @param byteCode byte[] of compiled byte code
     * @return String fully qualified class name
     * @throws IOException if there are problems reading the byte code (thrown as unchecked)
     * @throws IllegalStateException if the class file format is not recognized
     */
    public static String getClassNameFromByteCode(byte[] byteCode) {
        try (InputStream is = new ByteArrayInputStream(byteCode);
             DataInputStream dis = new DataInputStream(is)) {

            dis.readInt(); // magic number
            dis.readShort(); // minor version
            dis.readShort(); // major version
            int cpcnt = (dis.readShort() & 0xffff) - 1;
            // constant_pool_count must be >= 1 per the JVM spec, so cpcnt (count - 1) must be >= 0.
            // Guard so a malformed count of 0 throws the documented IllegalStateException instead of
            // a NegativeArraySizeException from the array allocation below.
            if (cpcnt < 0) {
                throw new IllegalStateException("Invalid constant pool count: " + (cpcnt + 1));
            }
            int[] classes = new int[cpcnt];
            String[] strings = new String[cpcnt];
            int t;

            for (int i = 0; i < cpcnt; i++) {
                t = dis.read(); // tag - 1 byte

                switch (t) {
                    case CONSTANT_UTF8:
                        strings[i] = dis.readUTF();
                        break;

                    case CONSTANT_INTEGER:
                    case CONSTANT_FLOAT:
                        dis.readInt(); // bytes
                        break;

                    case CONSTANT_LONG:
                    case CONSTANT_DOUBLE:
                        dis.readInt(); // high_bytes
                        dis.readInt(); // low_bytes
                        i++; // All 8-byte constants take up two entries
                        break;

                    case CONSTANT_CLASS:
                        classes[i] = dis.readShort() & 0xffff;
                        break;

                    case CONSTANT_STRING:
                        dis.readShort(); // string_index
                        break;

                    case CONSTANT_FIELDREF:
                    case CONSTANT_METHODREF:
                    case CONSTANT_INTERFACEMETHODREF:
                        dis.readShort(); // class_index
                        dis.readShort(); // name_and_type_index
                        break;

                    case CONSTANT_NAMEANDTYPE:
                        dis.readShort(); // name_index
                        dis.readShort(); // descriptor_index
                        break;

                    case CONSTANT_METHODHANDLE:
                        dis.readByte(); // reference_kind
                        dis.readShort(); // reference_index
                        break;

                    case CONSTANT_METHODTYPE:
                        dis.readShort(); // descriptor_index
                        break;

                    case CONSTANT_DYNAMIC:
                    case CONSTANT_INVOKEDYNAMIC:
                        dis.readShort(); // bootstrap_method_attr_index
                        dis.readShort(); // name_and_type_index
                        break;

                    case CONSTANT_MODULE:
                    case CONSTANT_PACKAGE:
                        dis.readShort(); // name_index
                        break;

                    default:
                        throw new IllegalStateException("Unrecognized constant pool tag: " + t);
                }
            }

            dis.readShort(); // access flags
            int thisClassIndex = dis.readShort() & 0xffff; // this_class

            // Bounds checking for malformed class files
            if (thisClassIndex < 1 || thisClassIndex > classes.length) {
                throw new IllegalStateException("Invalid this_class index: " + thisClassIndex);
            }
            int stringIndex = classes[thisClassIndex - 1];
            if (stringIndex < 1 || stringIndex > strings.length) {
                throw new IllegalStateException("Invalid string index: " + stringIndex);
            }
            String className = strings[stringIndex - 1];
            if (className == null) {
                throw new IllegalStateException("Class name not found in constant pool");
            }
            return className.replace('/', '.');
        } catch (IOException e) {
            ExceptionUtilities.uncheckedThrow(e);
            return null; // unreachable
        }
    }

    /**
     * Returns true if the JavaCompiler (JDK) is available at runtime, false if running under a JRE.
     */
    public static boolean isJavaCompilerAvailable() {
        // Allow tests to simulate running on a JRE by setting a system property.
        if (Boolean.getBoolean("java.util.force.jre")) {
            return false;
        }

        try {
            Class<?> toolProvider = Class.forName("javax.tools.ToolProvider");
            Object compiler = toolProvider.getMethod("getSystemJavaCompiler").invoke(null);
            return compiler != null;
        } catch (Throwable t) {
            return false;
        }
    }
    
    /**
     * Return a String representation of the class loader, or "bootstrap" if null.
     *
     * @param c The class whose class loader is to be identified.
     * @return A String representing the class loader.
     */
    private static String getClassLoaderName(Class<?> c) {
        ClassLoader loader = c.getClassLoader();
        if (loader == null) {
            return "bootstrap";
        }
        // Example: "org.example.MyLoader@1a2b3c4"
        return loader.getClass().getName() + '@' + Integer.toHexString(System.identityHashCode(loader));
    }
    
    // Record support (Java 14+) - using holder class for thread-safe lazy initialization
    // with zero synchronization overhead after init
    private static class RecordSupport {
        static final Method IS_RECORD_METHOD;
        static final Method GET_RECORD_COMPONENTS_METHOD;
        static final Method COMPONENT_GET_NAME_METHOD;
        static final Method COMPONENT_GET_ACCESSOR_METHOD;
        static final boolean SUPPORTED;

        static {
            Method isRecord = null;
            Method getComponents = null;
            Method getName = null;
            Method getAccessor = null;
            boolean supported = false;
            try {
                isRecord = Class.class.getMethod("isRecord");
                getComponents = Class.class.getMethod("getRecordComponents");
                // Get RecordComponent methods by getting the class first
                Class<?> recordComponentClass = Class.forName("java.lang.reflect.RecordComponent");
                getName = recordComponentClass.getMethod("getName");
                getAccessor = recordComponentClass.getMethod("getAccessor");
                supported = true;
            } catch (NoSuchMethodException | ClassNotFoundException e) {
                // Running on Java < 14
            }
            IS_RECORD_METHOD = isRecord;
            GET_RECORD_COMPONENTS_METHOD = getComponents;
            COMPONENT_GET_NAME_METHOD = getName;
            COMPONENT_GET_ACCESSOR_METHOD = getAccessor;
            SUPPORTED = supported;
        }
    }

}

package com.cedarsoftware.util;

/**
 * Captures the result of executing a command.
 */
public class ExecutionResult {

}


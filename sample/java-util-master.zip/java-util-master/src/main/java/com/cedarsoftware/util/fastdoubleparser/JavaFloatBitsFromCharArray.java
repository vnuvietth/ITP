/*
 * @(#)JavaFloatBitsFromCharArray.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

/**
 * Parses a {@code float} from a {@code char} array.
 */
final class JavaFloatBitsFromCharArray {


    /**
     * Creates a new instance.
     */
    public JavaFloatBitsFromCharArray() {

    }

}
package com.cedarsoftware.util;

import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A lightweight Set implementation that uses object identity (==) instead of equals()
 * for element comparison. Uses open addressing with linear probing for minimal overhead.
 *
 * <p>Key features:</p>
 * <ul>
 *   <li>Implements full {@link java.util.Set} interface</li>
 *   <li>Uses object identity (==) not equals() for comparison</li>
 *   <li>No Entry objects - single Object[] array</li>
 *   <li>Single identityHashCode call per operation</li>
 *   <li>Excellent cache locality</li>
 * </ul>
 *
 * <p>This class is a high-performance, drop-in replacement for:</p>
 * <pre>{@code
 * Set<Object> set = Collections.newSetFromMap(new IdentityHashMap<>());
 * }</pre>
 *
 * <p>Performance benefits over IdentityHashMap-backed Set:</p>
 * <ul>
 *   <li>No wrapper layer indirection</li>
 *   <li>No Entry object allocations</li>
 *   <li>No Boolean.TRUE value storage</li>
 *   <li>Better CPU cache utilization (contiguous array)</li>
 * </ul>
 *
 * <p><b>Thread Safety:</b> This class is <i>not</i> thread-safe. If multiple threads
 * access an IdentitySet concurrently, external synchronization is required.</p>
 *
 * @param <T> the type of elements maintained by this set
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public class IdentitySet<T>  {
    private static final int DEFAULT_CAPACITY = 16;
    private static final int MAX_CAPACITY = 1 << 30;  // Largest power-of-2 for int
    private static final float DEFAULT_LOAD_FACTOR = 0.75f;  // Keep load low for fast probing

    // Sentinel for deleted slots to maintain probe chains
    private static final Object DELETED = new Object();

    private Object[] elements;
    private int size;
    private int deletedCount;
    private int threshold;
    private int mask;
    private final float loadFactor;

    /**
     * Creates a new IdentitySet with default initial capacity (16).
     */
    public IdentitySet() {
        this(DEFAULT_CAPACITY);
    }

    /**
     * Creates a new IdentitySet with the specified initial capacity.
     *
     * @param initialCapacity the initial capacity (will be rounded up to power of 2)
     */
    public IdentitySet(int initialCapacity) {
        this(initialCapacity, DEFAULT_LOAD_FACTOR);
    }

    /**
     * Creates a new IdentitySet with the specified initial capacity and load factor.
     *
     * @param initialCapacity the initial capacity (will be rounded up to power of 2)
     * @param loadFactor      the load factor threshold that triggers resize ({@code must be > 0 and < 1})
     */
    public IdentitySet(int initialCapacity, float loadFactor) {
        if (loadFactor <= 0.0f || loadFactor >= 1.0f || Float.isNaN(loadFactor)) {
            throw new IllegalArgumentException("loadFactor must be > 0 and < 1");
        }
        this.loadFactor = loadFactor;
        // Round up to power of 2, capping at MAX_CAPACITY to prevent int overflow
        int capacity = 1;
        int target = Math.min(Math.max(initialCapacity, 1), MAX_CAPACITY);
        while (capacity < target) {
            capacity <<= 1;
        }
        elements = new Object[capacity];
        mask = capacity - 1;
        threshold = (int) (capacity * this.loadFactor);
    }


}

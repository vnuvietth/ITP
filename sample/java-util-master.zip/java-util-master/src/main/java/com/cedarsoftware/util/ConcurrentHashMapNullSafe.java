package com.cedarsoftware.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A thread-safe implementation of {@link java.util.concurrent.ConcurrentMap} that supports
 * {@code null} keys and {@code null} values by using internal sentinel objects.
 * <p>
 * {@code ConcurrentHashMapNullSafe} extends {@link AbstractConcurrentNullSafeMap} and uses a
 * {@link ConcurrentHashMap} as its backing implementation. This class retains all the advantages
 * of {@code ConcurrentHashMap} (e.g., high concurrency, thread safety, and performance) while
 * enabling safe handling of {@code null} keys and values.
 * </p>
 *
 * <h2>Key Features</h2>
 * <ul>
 *   <li>Thread-safe and highly concurrent.</li>
 *   <li>Supports {@code null} keys and {@code null} values through internal sentinel objects.</li>
 *   <li>Adheres to the {@link java.util.Map} and {@link java.util.concurrent.ConcurrentMap} contracts.</li>
 *   <li>Provides constructors to control initial capacity, load factor,
 *       concurrency level, and to populate from another map.</li>
 * </ul>
 *
 * <h2>Usage Example</h2>
 * <pre>{@code
 * // Create an empty ConcurrentHashMapNullSafe
 * ConcurrentHashMapNullSafe<String, String> map = new ConcurrentHashMapNullSafe<>();
 * map.put(null, "nullKey");
 * map.put("key", null);
 *
 * // Populate from another map
 * Map<String, String> existingMap = Map.of("a", "b", "c", "d");
 * ConcurrentHashMapNullSafe<String, String> populatedMap = new ConcurrentHashMapNullSafe<>(existingMap);
 *
 * LOG.info(map.get(null));  // Outputs: nullKey
 * LOG.info(map.get("key")); // Outputs: null
 * LOG.info(populatedMap);  // Outputs: {a=b, c=d}
 * }</pre>
 *
 * @param <K> the type of keys maintained by this map
 * @param <V> the type of mapped values
 *
 * @author John DeRegnaucourt
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 * @see ConcurrentHashMap
 * @see AbstractConcurrentNullSafeMap
 */
public final class ConcurrentHashMapNullSafe<K, V> {
}

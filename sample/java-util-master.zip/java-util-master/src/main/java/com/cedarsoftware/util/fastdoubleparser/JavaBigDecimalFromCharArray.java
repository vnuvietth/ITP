/*
 * @(#)JavaBigDecimalFromCharArray.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.NavigableMap;


/**
 * Parses a {@code double} from a {@code byte} array.
 */
final class JavaBigDecimalFromCharArray {
    /**
     * Creates a new instance.
     */
    public JavaBigDecimalFromCharArray() {

    }
}
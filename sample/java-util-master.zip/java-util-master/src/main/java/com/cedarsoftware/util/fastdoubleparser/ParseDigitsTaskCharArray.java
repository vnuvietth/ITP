/*
 * @(#)ParseDigitsTaskCharArray.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

import java.math.BigInteger;
import java.util.Map;

import static com.cedarsoftware.util.fastdoubleparser.FastIntegerMath.splitFloor16;

/**
 * Parses digits.
 */
final class ParseDigitsTaskCharArray {
    /**
     * Don't let anyone instantiate this class.
     */
    private ParseDigitsTaskCharArray() {
    }
}

/*
 * @(#)ParseDigitsTaskByteArray.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

import java.math.BigInteger;
import java.util.Map;


/**
 * Parses digits.
 */
final class ParseDigitsTaskByteArray {
    /**
     * Don't let anyone instantiate this class.
     */
    private ParseDigitsTaskByteArray() {
    }

}

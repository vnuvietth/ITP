/*
 * @(#)JavaFloatBitsFromByteArray.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

import java.nio.charset.StandardCharsets;

/**
 * Parses a {@code float} from a {@code byte} array.
 */
final class JavaFloatBitsFromByteArray {


    /**
     * Creates a new instance.
     */
    public JavaFloatBitsFromByteArray() {

    }


}
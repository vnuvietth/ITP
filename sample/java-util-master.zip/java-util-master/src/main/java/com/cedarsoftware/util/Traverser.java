package com.cedarsoftware.util;

import java.lang.reflect.Field;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.logging.Logger;

/**
 * A Java Object Graph traverser that visits all object reference fields and invokes a
 * provided callback for each encountered object, including the root. It properly
 * detects cycles within the graph to prevent infinite loops. For each visited node,
 * complete field information including metadata is provided.
 *
 * <h2>Security Configuration</h2>
 * <p>Traverser provides configurable security controls to prevent resource exhaustion
 * and stack overflow attacks from malicious or deeply nested object graphs.
 * All security features are <strong>disabled by default</strong> for backward compatibility.</p>
 *
 * <p>Security controls can be enabled via system properties:</p>
 * <ul>
 *   <li><code>traverser.security.enabled=false</code> &mdash; Master switch for all security features</li>
 *   <li><code>traverser.max.stack.depth=0</code> &mdash; Maximum stack depth (0 = disabled)</li>
 *   <li><code>traverser.max.objects.visited=0</code> &mdash; Maximum objects visited (0 = disabled)</li>
 *   <li><code>traverser.max.collection.size=0</code> &mdash; Maximum collection size to process (0 = disabled)</li>
 *   <li><code>traverser.max.array.length=0</code> &mdash; Maximum array length to process (0 = disabled)</li>
 * </ul>
 *
 * <h3>Security Features</h3>
 * <ul>
 *   <li><b>Stack Depth Limiting:</b> Prevents stack overflow from deeply nested object graphs</li>
 *   <li><b>Object Count Limiting:</b> Prevents memory exhaustion from large object graphs</li>
 *   <li><b>Collection Size Limiting:</b> Limits processing of oversized collections and maps</li>
 *   <li><b>Array Length Limiting:</b> Limits processing of oversized arrays</li>
 * </ul>
 *
 * <h3>Usage Example</h3>
 * <pre>{@code
 * // Enable security with custom limits
 * System.setProperty("traverser.security.enabled", "true");
 * System.setProperty("traverser.max.stack.depth", "1000");
 * System.setProperty("traverser.max.objects.visited", "50000");
 *
 * // These will now enforce security controls
 * Traverser.traverse(root, classesToSkip, visit -> {
 *     // Process visit - will throw SecurityException if limits exceeded
 * });
 * }</pre>
 *
 * <p>
 * <b>Usage Examples:</b>
 * </p>
 *
 * <p><b>Using the Modern API (Recommended):</b></p>
 * <pre>{@code
 * // Define classes to skip (optional)
 * Set<Class<?>> classesToSkip = new HashSet<>();
 * classesToSkip.add(String.class);
 *
 * // Traverse with full node information
 * Traverser.traverse(root, classesToSkip, visit -> {
 *     LOG.info("Node: " + visit.getNode());
 *     visit.getFields().forEach((field, value) -> {
 *         LOG.info("  Field: " + field.getName() +
 *             " (type: " + field.getType().getSimpleName() + ") = " + value);
 *
 *         // Access field metadata if needed
 *         if (field.isAnnotationPresent(JsonProperty.class)) {
 *             JsonProperty ann = field.getAnnotation(JsonProperty.class);
 *             LOG.info("    JSON property: " + ann.value());
 *         }
 *     });
 * });
 * }</pre>
 *
 * <p><b>Using the Legacy API (Deprecated):</b></p>
 * <pre>{@code
 * // Define a visitor that processes each object
 * Traverser.Visitor visitor = new Traverser.Visitor() {
 *     @Override
 *     public void process(Object o) {
 *         LOG.info("Visited: " + o);
 *     }
 * };
 *
 * // Create an object graph and traverse it
 * SomeClass root = new SomeClass();
 * Traverser.traverse(root, visitor);
 * }</pre>
 *
 * <p>
 * <b>Thread Safety:</b> This class is <i>not</i> thread-safe. If multiple threads access
 * a {@code Traverser} instance concurrently, external synchronization is required.
 * </p>
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public class Traverser {

    private static final Logger LOG = Logger.getLogger(Traverser.class.getName());

    // Default security limits
    private static final int DEFAULT_MAX_STACK_DEPTH = 1000000;  // 1M depth for heap-based traversal
    private static final int DEFAULT_MAX_OBJECTS_VISITED = 100000;
    private static final int DEFAULT_MAX_COLLECTION_SIZE = 50000;
    private static final int DEFAULT_MAX_ARRAY_LENGTH = 50000;

    static {
        // Initialize system properties with defaults if not already set (backward compatibility)
        initializeSystemPropertyDefaults();
    }

    private static void initializeSystemPropertyDefaults() {
        // Set default values if not explicitly configured
        if (System.getProperty("traverser.max.stack.depth") == null) {
            System.setProperty("traverser.max.stack.depth", "0"); // Disabled by default
        }
        if (System.getProperty("traverser.max.objects.visited") == null) {
            System.setProperty("traverser.max.objects.visited", "0"); // Disabled by default
        }
        if (System.getProperty("traverser.max.collection.size") == null) {
            System.setProperty("traverser.max.collection.size", "0"); // Disabled by default
        }
        if (System.getProperty("traverser.max.array.length") == null) {
            System.setProperty("traverser.max.array.length", "0"); // Disabled by default
        }
    }

    // Security configuration methods

    private static boolean isSecurityEnabled() {
        return Boolean.parseBoolean(System.getProperty("traverser.security.enabled", "false"));
    }

    private static int getMaxStackDepth() {
        if (!isSecurityEnabled()) {
            return 0; // Disabled
        }
        String maxDepthProp = System.getProperty("traverser.max.stack.depth");
        if (maxDepthProp != null) {
            try {
                int value = Integer.parseInt(maxDepthProp);
                return Math.max(0, value); // 0 means disabled
            } catch (NumberFormatException e) {
                // Fall through to default
            }
        }
        return DEFAULT_MAX_STACK_DEPTH;
    }

    private static int getMaxObjectsVisited() {
        if (!isSecurityEnabled()) {
            return 0; // Disabled
        }
        String maxObjectsProp = System.getProperty("traverser.max.objects.visited");
        if (maxObjectsProp != null) {
            try {
                int value = Integer.parseInt(maxObjectsProp);
                return Math.max(0, value); // 0 means disabled
            } catch (NumberFormatException e) {
                // Fall through to default
            }
        }
        return DEFAULT_MAX_OBJECTS_VISITED;
    }

    private static int getMaxCollectionSize() {
        if (!isSecurityEnabled()) {
            return 0; // Disabled
        }
        String maxSizeProp = System.getProperty("traverser.max.collection.size");
        if (maxSizeProp != null) {
            try {
                int value = Integer.parseInt(maxSizeProp);
                return Math.max(0, value); // 0 means disabled
            } catch (NumberFormatException e) {
                // Fall through to default
            }
        }
        return DEFAULT_MAX_COLLECTION_SIZE;
    }

    private static int getMaxArrayLength() {
        if (!isSecurityEnabled()) {
            return 0; // Disabled
        }
        String maxLengthProp = System.getProperty("traverser.max.array.length");
        if (maxLengthProp != null) {
            try {
                int value = Integer.parseInt(maxLengthProp);
                return Math.max(0, value); // 0 means disabled
            } catch (NumberFormatException e) {
                // Fall through to default
            }
        }
        return DEFAULT_MAX_ARRAY_LENGTH;
    }
    
    /**
     * Represents a node visit during traversal, containing the node and its field information.
     */
    public static class NodeVisit {
        private final Object node;
        private final java.util.function.Supplier<Map<Field, Object>> fieldsSupplier;
        private Map<Field, Object> fields;

        public NodeVisit(Object node, Map<Field, Object> fields) {
            this.node = node;
            this.fieldsSupplier = null;
            // Wrap directly - the map is already freshly created by collectFieldValues
            this.fields = fields == null ? Collections.emptyMap() : Collections.unmodifiableMap(fields);
        }

        public NodeVisit(Object node, java.util.function.Supplier<Map<Field, Object>> supplier) {
            this.node = node;
            this.fieldsSupplier = supplier;
        }

        /**
         * @return The object (node) being visited
         */
        public Object getNode() { return node; }

        /**
         * @return Unmodifiable map of fields to their values, including metadata about each field
         */
        public Map<Field, Object> getFields() {
            if (fields == null) {
                Map<Field, Object> f = fieldsSupplier == null ? Collections.emptyMap() : fieldsSupplier.get();
                // Wrap directly - the map is freshly created by collectFieldValues
                fields = (f == null) ? Collections.emptyMap() : Collections.unmodifiableMap(f);
            }
            return fields;
        }

        /**
         * @return The class of the node being visited
         */
        public Class<?> getNodeClass() { return node.getClass(); }
    }

}

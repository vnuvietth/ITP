package com.cedarsoftware.util;

import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A utility class for executing system commands and capturing their output.
 * <p>
 * This class provides a convenient wrapper around Java's {@link Runtime#exec(String)} methods,
 * capturing both standard output and standard error streams. It handles stream management
 * and process cleanup automatically.
 * </p>
 *
 * <p><strong>Features:</strong></p>
 * <ul>
 *   <li>Executes system commands with various parameter combinations</li>
 *   <li>Captures stdout and stderr output</li>
 *   <li>Supports environment variables</li>
 *   <li>Supports working directory specification</li>
 *   <li>Non-blocking output handling</li>
 * </ul>
 *
 * <h2>Security Configuration</h2>
 * <p>Due to the inherent security risks of executing arbitrary system commands, Executor is
 * <strong>disabled by default</strong> and must be explicitly enabled. This is a security-first
 * approach that requires intentional opt-in for command execution capabilities.</p>
 *
 * <p>Security control can be configured via system property:</p>
 * <ul>
 *   <li><code>executor.enabled=false</code> &mdash; Enable/disable all command execution (default: false)</li>
 * </ul>
 *
 * <h3>Security Features</h3>
 * <ul>
 *   <li><b>Disabled by Default:</b> Command execution is disabled unless explicitly enabled</li>
 *   <li><b>Explicit Opt-in:</b> Users must consciously enable this dangerous functionality</li>
 *   <li><b>Complete Control:</b> Single property controls all execution methods</li>
 *   <li><b>Clear Error Messages:</b> SecurityExceptions provide instructions on how to enable</li>
 * </ul>
 *
 * <h3>Security Warning</h3>
 * <p><strong>⚠️ WARNING:</strong> This class executes arbitrary system commands with the privileges 
 * of the JVM process. Only enable with trusted input and in environments where command execution is necessary.</p>
 *
 * <h3>Usage Example</h3>
 * <pre>{@code
 * // Enable command execution (required)
 * System.setProperty("executor.enabled", "true");
 *
 * // Now command execution will work
 * Executor exec = new Executor();
 * int exitCode = exec.exec("ls -l");
 * String output = exec.getOut();
 * }</pre>
 *
 * <h3>Breaking Change Notice</h3>
 * <p><strong>⚠️ BREAKING CHANGE:</strong> As of this version, Executor is disabled by default.
 * Existing code that uses Executor will need to add <code>System.setProperty("executor.enabled", "true")</code>
 * before using any Executor methods.</p>
 *
 * <p><strong>Basic Usage:</strong></p>
 * <pre>{@code
 * // First, enable command execution (required)
 * System.setProperty("executor.enabled", "true");
 * 
 * // Then use Executor normally
 * Executor exec = new Executor();
 * int exitCode = exec.exec("ls -l");
 * String output = exec.getOut();      // Get stdout
 * String errors = exec.getError();    // Get stderr
 * }</pre>
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 *
 * <p><strong>Thread Safety:</strong> Instances of this class are <em>not</em> thread
 * safe. Create a new {@code Executor} per command execution or synchronize
 * externally if sharing across threads.</p>
 */
public class Executor {

    private String cmdArrayToString(String[] cmdArray) {
        return String.join(" ", cmdArray);
    }
}

/*
 * @(#)JavaDoubleBitsFromCharSequence.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

/**
 * Parses a {@code double} from a {@link CharSequence}.
 */
final class JavaDoubleBitsFromCharSequence {

    /**
     * Creates a new instance.
     */
    public JavaDoubleBitsFromCharSequence() {

    }

}
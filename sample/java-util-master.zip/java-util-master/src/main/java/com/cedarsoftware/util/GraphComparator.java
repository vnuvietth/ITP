package com.cedarsoftware.util;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

/**
 * Graph Utility algorithms, such as Asymmetric Graph Difference.
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright [2010] John DeRegnaucourt
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
@SuppressWarnings("unchecked")
public class GraphComparator
{
    public static final String ROOT = "-root-";
    private static final Object NO_ID = new Object();


    /**
     * @return boolean true if the passed in object is a 'Logical' primitive.  Logical primitive is defined
     * as all primitives plus primitive wrappers, String, Date, Calendar, Number, or Character
     */
    private static boolean isLogicalPrimitive(Class<?> c)
    {
        return c.isPrimitive() ||
                String.class == c ||
                Date.class.isAssignableFrom(c) ||
                Number.class.isAssignableFrom(c) ||
                Boolean.class.isAssignableFrom(c) ||
                Calendar.class.isAssignableFrom(c) ||
                TimeZone.class.isAssignableFrom(c) ||
                Character.class == c;
    }

}

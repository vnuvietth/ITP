package com.cedarsoftware.util;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.function.IntSupplier;

/**
 * A flexible InputStream that generates data on-the-fly using various generation strategies.
 * This class is ideal for testing code that handles large streams, generating synthetic data,
 * or creating pattern-based input without consuming memory to store the data.
 *
 * <p>Data is generated as needed and immediately discarded, making it memory-efficient
 * for testing with very large stream sizes.</p>
 *
 * <p>Example usage:</p>
 * <pre>{@code
 * // Random bytes
 * try (InputStream input = DataGeneratorInputStream.withRandomBytes(1024 * 1024)) {
 *     processStream(input);
 * }
 *
 * // Repeating pattern
 * try (InputStream input = DataGeneratorInputStream.withRepeatingPattern(1024, "Hello")) {
 *     processStream(input);
 * }
 *
 * // Custom generator
 * try (InputStream input = DataGeneratorInputStream.withGenerator(1024, () -> 42)) {
 *     processStream(input);
 * }
 * }</pre>
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public class DataGeneratorInputStream {

}
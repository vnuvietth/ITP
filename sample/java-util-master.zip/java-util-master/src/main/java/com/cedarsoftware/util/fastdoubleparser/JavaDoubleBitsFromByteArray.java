/*
 * @(#)JavaDoubleBitsFromByteArray.java
 * Copyright © 2024 Werner Randelshofer, Switzerland. MIT License.
 */
package com.cedarsoftware.util.fastdoubleparser;

import java.nio.charset.StandardCharsets;

/**
 * Parses a {@code double} from a {@code byte} array.
 */
final class JavaDoubleBitsFromByteArray {

    /**
     * Creates a new instance.
     */
    public JavaDoubleBitsFromByteArray() {

    }

}
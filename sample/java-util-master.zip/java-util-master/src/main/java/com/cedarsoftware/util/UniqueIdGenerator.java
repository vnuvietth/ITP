package com.cedarsoftware.util;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Logger;

import static java.lang.Integer.parseInt;
import static java.lang.System.currentTimeMillis;
public final class UniqueIdGenerator {
    // ---- Public environment variable names ----
    public static final String JAVA_UTIL_CLUSTERID = "JAVA_UTIL_CLUSTERID";
    public static final String KUBERNETES_POD_NAME = "HOSTNAME";                 // K8s commonly injects pod name into HOSTNAME
    public static final String TANZU_INSTANCE_ID   = "VMWARE_TANZU_INSTANCE_ID";
    public static final String CF_INSTANCE_INDEX   = "CF_INSTANCE_INDEX";

    // ---- Logging ----
    private static final Logger LOG = Logger.getLogger(UniqueIdGenerator.class.getName());

    // ---- Encoding constants ----
    // IDs end with two digits reserved for serverId; increment step = 100 to preserve that suffix.
    private static final long SEQUENCE_STEP     = 100L;

    private static final long FACTOR_16         = 100_000L;     // [timestampMs]*100_000 + [seq]*100 + [serverId]
    private static final int  SEQ_LIMIT_16      = 1_000;        // 000–999 per millisecond

    private static final long FACTOR_19         = 1_000_000L;   // [timestampMs]*1_000_000 + [seq]*100 + [serverId]
    private static final int  SEQ_LIMIT_19      = 10_000;       // 0000–9999 per millisecond

    // ---- State (lock-free) ----
    private static final AtomicLong LAST_ID_16 = new AtomicLong(0L);
    private static final AtomicLong LAST_ID_19 = new AtomicLong(0L);

    private UniqueIdGenerator() { }

    public static Date getDate(long uniqueId) {
        if (uniqueId < 0) {
            throw new IllegalArgumentException("Invalid uniqueId: must be non-negative");
        }
        return new Date(uniqueId / FACTOR_16);
    }

    public static Date getDate19(long uniqueId19) {
        if (uniqueId19 < 0) {
            throw new IllegalArgumentException("Invalid uniqueId19: must be non-negative");
        }
        return new Date(uniqueId19 / FACTOR_19);
    }

    public static Instant getInstant(long uniqueId) {
        if (uniqueId < 0) {
            throw new IllegalArgumentException("Invalid uniqueId: must be non-negative");
        }
        return Instant.ofEpochMilli(uniqueId / FACTOR_16);
    }

    public static Instant getInstant19(long uniqueId19) {
        if (uniqueId19 < 0) {
            throw new IllegalArgumentException("Invalid uniqueId19: must be non-negative");
        }
        return Instant.ofEpochMilli(uniqueId19 / FACTOR_19);
    }


    // -------------------- Internals --------------------

    /**
     * Wait until the system clock advances beyond the given millisecond.
     * Uses short spin with occasional nanosleep to reduce CPU.
     * Optimized to reduce currentTimeMillis() syscall frequency.
     */
    public static long waitForNextMillis(long lastMs) {
        long ts = currentTimeMillis();
        int parkCount = 0;

        while (ts <= lastMs) {
            // Spin phase: do multiple spin-waits before checking time (reduces syscall overhead)
            // Check time every 8 iterations instead of every iteration
            for (int i = 0; i < 64; i++) {
                onSpinWait();
                onSpinWait();
                onSpinWait();
                onSpinWait();
                onSpinWait();
                onSpinWait();
                onSpinWait();
                onSpinWait();
                if ((i & 7) == 7) {
                    ts = currentTimeMillis();
                    if (ts > lastMs) {
                        return ts;
                    }
                }
            }
            // ~100 microseconds backoff after spin phase
            LockSupport.parkNanos(100_000L);
            ts = currentTimeMillis();
            parkCount++;
            if (parkCount > 64 && ts <= lastMs) {
                // Safety valve: if the clock appears stuck (virtualized env), back off more
                LockSupport.parkNanos(1_000_000L);
                ts = currentTimeMillis();
            }
        }
        return ts;
    }

    /**
     * MethodHandle for Thread.onSpinWait() - much faster than Method.invoke() after JIT warmup.
     * MethodHandle.invokeExact() can be inlined by the JIT compiler, while Method.invoke() cannot.
     */
    public static final MethodHandle ON_SPIN_WAIT_HANDLE;
    static {
        MethodHandle handle = null;
        try {
            handle = MethodHandles.lookup()
                    .findStatic(Thread.class, "onSpinWait", MethodType.methodType(void.class));
        } catch (NoSuchMethodException | IllegalAccessException e) {
            // Java 8 or older - onSpinWait doesn't exist
        }
        ON_SPIN_WAIT_HANDLE = handle;
    }

    public  static void onSpinWait() {
        // Java 9+ spin-wait hint; no-op on older runtimes
        if (ON_SPIN_WAIT_HANDLE != null) {
            try {
                ON_SPIN_WAIT_HANDLE.invokeExact();
            } catch (Throwable ignored) {
                // no-op - required by invokeExact() signature, but void method won't throw
            }
        }
    }

    public  static long computeMaxMillis(long factor, int perMsLimit, int sid) {
        long maxSequenceOffset = ((long) perMsLimit - 1L) * SEQUENCE_STEP;
        long maxBase = Long.MAX_VALUE - sid - maxSequenceOffset;
        return maxBase / factor;
    }
}

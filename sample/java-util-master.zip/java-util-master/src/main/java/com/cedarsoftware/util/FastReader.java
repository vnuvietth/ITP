package com.cedarsoftware.util;

import java.io.IOException;
import java.io.Reader;

/**
 * Buffered, Pushback, Reader that does not use synchronization.   Much faster than the JDK variants because
 * they use synchronization.  Typically, this class is used with a separate instance per thread, so
 * synchronization is not needed.
 * <p>
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public final class FastReader {
    /**
     * Returned by borrowed-slice methods when the requested token/line is not
     * fully available in the current internal buffer and the caller should fall
     * back to the copying API.
     */
    public static final int COPY_REQUIRED = Integer.MIN_VALUE;
    private static final int MAX_CONSECUTIVE_ZERO_READS = 3;
    private Reader in;
    private int position; // Current position in the buffer
    private int limit;    // Number of characters currently in the buffer, or -1 for EOF
    private int pushbackPosition; // Current position in the pushback buffer
    private BufferSlice activeBorrowedSlice;
    // Line/col tracking removed for performance - use getLastSnippet() for error context

    /**
     * Borrowed view of a contiguous range inside {@link FastReader}'s internal buffers.
     * The contents are valid only until {@link #release()} or the next read operation on
     * the same reader, whichever comes first.
     * <p>
     * Callers must consume or copy the slice contents, then call {@link #release()}
     * before invoking any other {@link FastReader} method that reads, pushes back, or
     * closes the reader. With assertions enabled, {@code FastReader} verifies this
     * lifecycle and fails fast if a borrowed slice is left outstanding.
     */
    public static final class BufferSlice {
        private char[] buffer;
        private int offset;
        private int length;
        private FastReader reader;
        private boolean released = true;

        public char[] getBuffer() {
            assert isAccessibleForDebug() : "BufferSlice is not active; consume borrowed data before release";
            return buffer;
        }

        public int getOffset() {
            assert isAccessibleForDebug() : "BufferSlice is not active; consume borrowed data before release";
            return offset;
        }

        public int getLength() {
            assert isAccessibleForDebug() : "BufferSlice is not active; consume borrowed data before release";
            return length;
        }

        /**
         * Mark this borrowed slice as consumed. Call after copying or otherwise
         * materializing the borrowed contents, and before the next FastReader operation.
         */
        public void release() {
            assert releaseForDebug();
        }

        private void set(char[] buffer, int offset, int length) {
            this.buffer = buffer;
            this.offset = offset;
            this.length = length;
        }

        private boolean attachForDebug(FastReader reader) {
            this.reader = reader;
            this.released = false;
            return true;
        }

        private boolean releaseForDebug() {
            released = true;
            FastReader owner = reader;
            if (owner != null && owner.activeBorrowedSlice == this) {
                owner.activeBorrowedSlice = null;
            }
            return true;
        }

        private boolean isAccessibleForDebug() {
            return !released;
        }
    }


}

package com.cedarsoftware.util;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility for parsing String dates with optional times, supporting a wide variety of formats and patterns.
 * Handles inconsistent input formats, optional time components, and various timezone specifications.
 *
 * <h2>Security Configuration</h2>
 * <p>DateUtilities provides configurable security controls to prevent various attack vectors including
 * ReDoS (Regular Expression Denial of Service) attacks, input validation bypasses, and resource exhaustion.
 * All security features are <strong>disabled by default</strong> for backward compatibility.</p>
 *
 * <p>Security controls can be enabled via system properties:</p>
 * <ul>
 *   <li><code>dateutilities.security.enabled=false</code> &mdash; Master switch for all security features</li>
 *   <li><code>dateutilities.input.validation.enabled=false</code> &mdash; Enable input length and content validation</li>
 *   <li><code>dateutilities.regex.timeout.enabled=false</code> &mdash; Enable regex timeout protection</li>
 *   <li><code>dateutilities.malformed.string.protection.enabled=false</code> &mdash; Enable malformed input protection</li>
 *   <li><code>dateutilities.max.input.length=1000</code> &mdash; Maximum input string length</li>
 *   <li><code>dateutilities.max.epoch.digits=19</code> &mdash; Maximum digits for epoch milliseconds</li>
 *   <li><code>dateutilities.regex.timeout.milliseconds=1000</code> &mdash; Timeout for regex operations in milliseconds</li>
 * </ul>
 *
 * <h3>Security Features</h3>
 * <ul>
 *   <li><b>Input Length Validation:</b> Prevents memory exhaustion through oversized input strings</li>
 *   <li><b>ReDoS Protection:</b> Configurable timeouts for regex operations to prevent catastrophic backtracking</li>
 *   <li><b>Malformed Input Protection:</b> Enhanced validation to detect and reject malicious input patterns</li>
 *   <li><b>Epoch Range Validation:</b> Prevents integer overflow in epoch millisecond parsing</li>
 * </ul>
 *
 * <h3>Usage Example</h3>
 * <pre>{@code
 * // Enable security with custom settings
 * System.setProperty("dateutilities.security.enabled", "true");
 * System.setProperty("dateutilities.input.validation.enabled", "true");
 * System.setProperty("dateutilities.regex.timeout.enabled", "true");
 * System.setProperty("dateutilities.max.input.length", "500");
 *
 * // These will now enforce security controls
 * Date date = DateUtilities.parseDate("2024-01-15 14:30:00"); // works
 * Date malicious = DateUtilities.parseDate(veryLongString); // throws SecurityException
 * }</pre>
 *
 * <h2>Supported Date Formats</h2>
 * <table border="1" summary="Supported date formats">
 *   <tr><th>Format</th><th>Example</th><th>Description</th></tr>
 *   <tr>
 *     <td>Numeric with separators</td>
 *     <td>12-31-2023, 12/31/2023, 12.31.2023</td>
 *     <td>mm is 1-12 or 01-12, dd is 1-31 or 01-31, yyyy is 0000-9999</td>
 *   </tr>
 *   <tr>
 *     <td>ISO-style</td>
 *     <td>2023-12-31, 2023/12/31, 2023.12.31</td>
 *     <td>yyyy-mm-dd format with flexible separators (-, /, .)</td>
 *   </tr>
 *   <tr>
 *     <td>Month first</td>
 *     <td>January 6th, 2024</td>
 *     <td>Month name (full or 3-4 letter), day with optional suffix, year</td>
 *   </tr>
 *   <tr>
 *     <td>Day first</td>
 *     <td>17th January 2024</td>
 *     <td>Day with optional suffix, month name, year</td>
 *   </tr>
 *   <tr>
 *     <td>Year first</td>
 *     <td>2024 January 31st</td>
 *     <td>Year, month name, day with optional suffix</td>
 *   </tr>
 *   <tr>
 *     <td>Unix style</td>
 *     <td>Sat Jan 6 11:06:10 EST 2024</td>
 *     <td>Day of week, month, day, time, timezone, year</td>
 *   </tr>
 * </table>
 *
 * <h2>Supported Time Formats</h2>
 * <table border="1" summary="Supported time formats">
 *   <tr><th>Format</th><th>Example</th><th>Description</th></tr>
 *   <tr>
 *     <td>Basic time</td>
 *     <td>13:30</td>
 *     <td>24-hour format (00-23:00-59)</td>
 *   </tr>
 *   <tr>
 *     <td>With seconds</td>
 *     <td>13:30:45</td>
 *     <td>Includes seconds (00-59)</td>
 *   </tr>
 *   <tr>
 *     <td>With fractional seconds</td>
 *     <td>13:30:45.123456</td>
 *     <td>Variable precision fractional seconds</td>
 *   </tr>
 *   <tr>
 *     <td>With offset</td>
 *     <td>13:30+01:00, 13:30:45-0500</td>
 *     <td>Supports +HH:mm, +HHmm, +HH, -HH:mm, -HHmm, -HH, Z</td>
 *   </tr>
 *   <tr>
 *     <td>With timezone</td>
 *     <td>13:30 EST, 13:30:45 America/New_York</td>
 *     <td>Supports abbreviations and full zone IDs</td>
 *   </tr>
 * </table>
 *
 * <h2>Special Features</h2>
 * <ul>
 *   <li>Supports Unix epoch milliseconds (e.g., "1640995200000")</li>
 *   <li>Optional day-of-week in any position (ignored in date calculation)</li>
 *   <li>Flexible date/time separator (space or 'T')</li>
 *   <li>Time can appear before or after date</li>
 *   <li>Extensive timezone support including abbreviations and full zone IDs</li>
 *   <li>Handles ambiguous timezone abbreviations with population-based resolution</li>
 *   <li>Thread-safe implementation</li>
 * </ul>
 *
 * <h2>Usage Example</h2>
 * <pre>{@code
 * // Basic parsing with system default timezone
 * Date date1 = DateUtilities.parseDate("2024-01-15 14:30:00");
 *
 * // Parsing with specific timezone
 * ZonedDateTime date2 = DateUtilities.parseDate("2024-01-15 14:30:00",
 *     ZoneId.of("America/New_York"), true);
 *
 * // Parsing Unix style date
 * Date date3 = DateUtilities.parseDate("Tue Jan 15 14:30:00 EST 2024");
 * }</pre>
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public final class DateUtilities {
    // Default security limits
    private static final int DEFAULT_MAX_INPUT_LENGTH = 1000;
    private static final int DEFAULT_MAX_EPOCH_DIGITS = 19;
    private static final long DEFAULT_REGEX_TIMEOUT_MILLISECONDS = 1000L;

    private static final ExecutorService DATE_REGEX_EXECUTOR = Executors.newCachedThreadPool(r -> {
        Thread thread = new Thread(r, "DateUtilities-Regex-Timeout-Thread");
        thread.setDaemon(true);
        return thread;
    });

    // ----- Security configuration cache -----
    // System.getProperty() reads from the synchronized java.util.Properties singleton; in date-parsing-heavy
    // workloads safeFind/safeMatches were calling several of these per regex match, dominating the profile
    // (~190 ms per million calls just for isRegexTimeoutProtectionEnabled). The values below are resolved
    // lazily on first use and cached in volatile fields. Tests that toggle the relevant system properties
    // at runtime must call resetSecurityConfigCacheForTesting() afterward to pick up the new values.
    private static final int TRI_UNRESOLVED = 0;
    private static final int TRI_FALSE = 1;
    private static final int TRI_TRUE = 2;
    private static final long TIMEOUT_UNRESOLVED = -1L;

    private static volatile int cachedSecurityEnabled = TRI_UNRESOLVED;
    private static volatile int cachedInputValidationEnabled = TRI_UNRESOLVED;
    private static volatile int cachedMalformedStringProtectionEnabled = TRI_UNRESOLVED;
    private static volatile int cachedRegexTimeoutEnabled = TRI_UNRESOLVED;
    private static volatile long cachedRegexTimeoutMs = TIMEOUT_UNRESOLVED;

    private static boolean isSecurityEnabled() {
        int tri = cachedSecurityEnabled;
        if (tri != TRI_UNRESOLVED) {
            return tri == TRI_TRUE;
        }
        boolean value = Boolean.parseBoolean(System.getProperty("dateutilities.security.enabled", "false"));
        cachedSecurityEnabled = value ? TRI_TRUE : TRI_FALSE;
        return value;
    }

    private static boolean isInputValidationEnabled() {
        int tri = cachedInputValidationEnabled;
        if (tri != TRI_UNRESOLVED) {
            return tri == TRI_TRUE;
        }
        boolean value = Boolean.parseBoolean(System.getProperty("dateutilities.input.validation.enabled", "false"));
        cachedInputValidationEnabled = value ? TRI_TRUE : TRI_FALSE;
        return value;
    }

    private static boolean isMalformedStringProtectionEnabled() {
        int tri = cachedMalformedStringProtectionEnabled;
        if (tri != TRI_UNRESOLVED) {
            return tri == TRI_TRUE;
        }
        boolean value = Boolean.parseBoolean(System.getProperty("dateutilities.malformed.string.protection.enabled", "false"));
        cachedMalformedStringProtectionEnabled = value ? TRI_TRUE : TRI_FALSE;
        return value;
    }

    /**
     * Reset the cached security configuration. Intended for tests that toggle the
     * {@code dateutilities.*} / {@code cedarsoftware.regex.timeout.*} system properties at runtime;
     * production callers should not need this.
     */
    static void resetSecurityConfigCacheForTesting() {
        cachedSecurityEnabled = TRI_UNRESOLVED;
        cachedInputValidationEnabled = TRI_UNRESOLVED;
        cachedMalformedStringProtectionEnabled = TRI_UNRESOLVED;
        cachedRegexTimeoutEnabled = TRI_UNRESOLVED;
        cachedRegexTimeoutMs = TIMEOUT_UNRESOLVED;
    }

    private static int getMaxInputLength() {
        if (!isSecurityEnabled()) {
            return Integer.MAX_VALUE;
        }
        String maxLengthProp = System.getProperty("dateutilities.max.input.length");
        if (maxLengthProp != null) {
            try {
                return Math.max(1, Integer.parseInt(maxLengthProp));
            } catch (NumberFormatException ignored) {
                // Use default
            }
        }
        return DEFAULT_MAX_INPUT_LENGTH;
    }

    private static int getMaxEpochDigits() {
        if (!isSecurityEnabled()) {
            return Integer.MAX_VALUE;
        }
        String maxDigitsProp = System.getProperty("dateutilities.max.epoch.digits");
        if (maxDigitsProp != null) {
            try {
                return Math.max(1, Integer.parseInt(maxDigitsProp));
            } catch (NumberFormatException ignored) {
                // Use default
            }
        }
        return DEFAULT_MAX_EPOCH_DIGITS;
    }

    static boolean isRegexTimeoutProtectionEnabled() {
        int tri = cachedRegexTimeoutEnabled;
        if (tri != TRI_UNRESOLVED) {
            return tri == TRI_TRUE;
        }
        boolean value = computeRegexTimeoutProtectionEnabled();
        cachedRegexTimeoutEnabled = value ? TRI_TRUE : TRI_FALSE;
        return value;
    }

    private static boolean computeRegexTimeoutProtectionEnabled() {
        if (!isSecurityEnabled()) {
            return false;
        }
        String timeoutEnabled = System.getProperty("dateutilities.regex.timeout.enabled");
        if (timeoutEnabled != null) {
            return Boolean.parseBoolean(timeoutEnabled);
        }
        String globalTimeoutEnabled = System.getProperty("cedarsoftware.regex.timeout.enabled");
        if (globalTimeoutEnabled != null) {
            return Boolean.parseBoolean(globalTimeoutEnabled);
        }
        return true;
    }

    static long getRegexTimeoutMilliseconds() {
        long ms = cachedRegexTimeoutMs;
        if (ms != TIMEOUT_UNRESOLVED) {
            return ms;
        }
        ms = computeRegexTimeoutMilliseconds();
        cachedRegexTimeoutMs = ms;
        return ms;
    }

    private static long computeRegexTimeoutMilliseconds() {
        Long timeoutMs = parsePositiveLong(System.getProperty("dateutilities.regex.timeout.milliseconds"));
        if (timeoutMs != null) {
            return timeoutMs;
        }
        timeoutMs = parsePositiveLong(System.getProperty("cedarsoftware.regex.timeout.milliseconds"));
        if (timeoutMs != null) {
            return timeoutMs;
        }
        return DEFAULT_REGEX_TIMEOUT_MILLISECONDS;
    }

    private static Long parsePositiveLong(String value) {
        if (value == null) {
            return null;
        }
        try {
            long parsed = Long.parseLong(value);
            return parsed > 0 ? parsed : null;
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    // ----- Per-pattern thread-local Matcher cache -----
    // Pattern.matcher(input) allocates a fresh Matcher (plus internal int[] groups, locals, and
    // localsPos arrays) on every call. Reusing a single Matcher per (Pattern, Thread) and calling
    // reset(input) skips that allocation entirely. Keyed on the Pattern instance so each compiled
    // Pattern (small, fixed set within DateUtilities) gets its own ThreadLocal<Matcher>.
    private static final ConcurrentMap<Pattern, ThreadLocal<Matcher>> PATTERN_MATCHERS = new ConcurrentHashMap<>();

    // Pre-compiled pattern for invalid characters check (avoids creating Pattern on each call)
    private static final Pattern INVALID_CHARS_PATTERN = Pattern.compile("[<>&\"'\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]");

    /**
     * Validates input for malformed patterns that could cause ReDoS attacks.
     *
     * @param input the input string to validate
     * @throws SecurityException if malformed patterns are detected
     */
    private static void validateMalformedInput(String input) {
        // Check for excessive repetition using simple algorithmic approach (avoids ReDoS-vulnerable regex)
        if (hasExcessiveRepetition(input, 10, 5)) {
            throw new SecurityException("Input contains excessive repetition patterns that could cause ReDoS");
        }

        // Check for excessive nested grouping
        int openParens = 0;
        int maxNesting = 0;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c == '(') {
                openParens++;
                maxNesting = Math.max(maxNesting, openParens);
            } else if (c == ')') {
                openParens--;
            }
        }
        if (maxNesting > 20) {
            throw new SecurityException("Input contains excessive nesting that could cause parsing issues");
        }

        // Check for suspicious characters that don't belong in date strings
        if (INVALID_CHARS_PATTERN.matcher(input).find()) {
            throw new SecurityException("Input contains invalid characters for date parsing");
        }
    }

    /**
     * Detects excessive repetition of substrings without using vulnerable regex.
     * Checks if any substring of at least minLength characters repeats at least minRepeats times consecutively.
     *
     * @param input the input string to check
     * @param minLength minimum length of repeated substring
     * @param minRepeats minimum number of consecutive repeats
     * @return true if excessive repetition is detected
     */
    private static boolean hasExcessiveRepetition(String input, int minLength, int minRepeats) {
        int len = input.length();
        if (len < minLength * minRepeats) {
            return false;
        }

        // Check for repeated substrings of various lengths
        for (int subLen = minLength; subLen <= len / minRepeats; subLen++) {
            for (int start = 0; start <= len - subLen * minRepeats; start++) {
                int repeats = 1;
                int pos = start + subLen;

                while (pos + subLen <= len && input.regionMatches(start, input, pos, subLen)) {
                    repeats++;
                    pos += subLen;
                    if (repeats >= minRepeats) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // Performance optimized: Added UNICODE_CHARACTER_CLASS for better digit matching across locales
    private static final Pattern allDigits = Pattern.compile("^-?\\d+$", Pattern.UNICODE_CHARACTER_CLASS);
    private static final String days = "monday|mon|tuesday|tues|tue|wednesday|wed|thursday|thur|thu|friday|fri|saturday|sat|sunday|sun"; // longer before shorter matters
    private static final String mos = "January|Jan|February|Feb|March|Mar|April|Apr|May|June|Jun|July|Jul|August|Aug|September|Sept|Sep|October|Oct|November|Nov|December|Dec";
    private static final String yr = "[+-]?\\d{4,9}\\b";
    private static final String d1or2 = "\\d{1,2}";
    private static final String d2 = "\\d{2}";
    private static final String ord = "st|nd|rd|th";
    private static final String sep = "[./-]";
    private static final String ws = "\\s+";
    private static final String wsOp = "\\s*";
    private static final String wsOrComma = "[ ,]+";
    private static final String tzUnix = "[A-Z]{1,3}";
    private static final String tz_Hh_MM = "[+-]\\d{1,2}:\\d{2}";
    private static final String tz_Hh_MM_SS = "[+-]\\d{1,2}:\\d{2}:\\d{2}";
    private static final String tz_HHMM = "[+-]\\d{4}";
    private static final String tz_Hh = "[+-]\\d{1,2}";
    private static final String tzNamedCore = "(?:GMT[+-]\\d{2}:\\d{2}|[A-Za-z][A-Za-z0-9~/._+-]{1,50})";
    private static final String tzNamed = wsOp + "(?:\\[" + tzNamedCore + "]|" + tzNamedCore + ")";
    private static final String nano = "\\.\\d{1,9}";

    // Patterns defined in BNF influenced style using above named elements
    // Performance optimized: Added UNICODE_CHARACTER_CLASS for better Unicode handling
    private static final Pattern isoDatePattern = Pattern.compile(    // Regex's using | (OR)
            "(" + yr + ")(" + sep + ")(" + d1or2 + ")" + "\\2" + "(" + d1or2 + ")|" +        // 2024/01/21 (yyyy/mm/dd -or- yyyy-mm-dd -or- yyyy.mm.dd)   [optional time, optional day of week]  \2 references 1st separator (ensures both same)
            "(" + d1or2 + ")(" + sep + ")(" + d1or2 + ")" + "\\6(" + yr + ")",              // 01/21/2024 (mm/dd/yyyy -or- mm-dd-yyyy -or- mm.dd.yyyy)   [optional time, optional day of week]  \6 references 2nd 1st separator (ensures both same)
            Pattern.UNICODE_CHARACTER_CLASS);

    // Performance optimized: Combined flags for better performance
    private static final Pattern alphaMonthPattern = Pattern.compile(
            "\\b(" + mos + ")\\b" + wsOrComma + "(" + d1or2 + ")(" + ord + ")?" + wsOrComma + "(" + yr + ")|" +   // Jan 21st, 2024  (comma optional between all, day of week optional, time optional, ordinal text optional [st, nd, rd, th])
            "(" + d1or2 + ")(" + ord + ")?" + wsOrComma + "\\b(" + mos + ")\\b" + wsOrComma + "(" + yr + ")|" +         // 21st Jan, 2024  (ditto)
            "(" + yr + ")" + wsOrComma + "\\b(" + mos + "\\b)" + wsOrComma + "(" + d1or2 + ")(" + ord + ")?",           // 2024 Jan 21st   (ditto)
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CHARACTER_CLASS);

    // Performance optimized: Added UNICODE_CHARACTER_CLASS for consistent Unicode handling
    private static final Pattern unixDateTimePattern = Pattern.compile(
            "(?:\\b(" + days + ")\\b" + ws + ")?"
                    + "\\b(" + mos + ")\\b" + ws
                    + "(" + d1or2 + ")" + ws
                    + "(" + d2 + ":" + d2 + ":" + d2 + ")" + wsOp
                    + "(" + tzUnix + ")?"
                    + wsOp
                    + "(" + yr + ")",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CHARACTER_CLASS);
    
    // Performance optimized: Added UNICODE_CHARACTER_CLASS while preserving original capture group structure
    private static final Pattern timePattern = Pattern.compile(
            "(" + d2 + "):(" + d2 + ")(?::(" + d2 + ")(" + nano + ")?)?(" + tz_Hh_MM_SS + "|" + tz_Hh_MM + "|" + tz_HHMM + "|" + tz_Hh + "|Z)?(" + tzNamed + ")?",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CHARACTER_CLASS);

    // Performance optimized: Reordered alternatives for better matching efficiency and added UNICODE_CHARACTER_CLASS
    private static final Pattern zonePattern = Pattern.compile(
            "(" + tz_Hh_MM + "|" + tz_HHMM + "|" + tz_Hh_MM_SS + "|" + tz_Hh + "|Z|" + tzNamed + ")",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CHARACTER_CLASS);

    // Performance optimized: Added UNICODE_CHARACTER_CLASS for consistent Unicode handling
    private static final Pattern dayPattern = Pattern.compile("\\b(" + days + ")\\b",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CHARACTER_CLASS);
    private static final Map<String, Integer> months;
    public static final Map<String, String> ABBREVIATION_TO_TIMEZONE;

    static {
        // Month name to number map - use HashMap since it's never modified after initialization
        Map<String, Integer> monthBuilder = new HashMap<>();
        monthBuilder.put("jan", 1);
        monthBuilder.put("january", 1);
        monthBuilder.put("feb", 2);
        monthBuilder.put("february", 2);
        monthBuilder.put("mar", 3);
        monthBuilder.put("march", 3);
        monthBuilder.put("apr", 4);
        monthBuilder.put("april", 4);
        monthBuilder.put("may", 5);
        monthBuilder.put("jun", 6);
        monthBuilder.put("june", 6);
        monthBuilder.put("jul", 7);
        monthBuilder.put("july", 7);
        monthBuilder.put("aug", 8);
        monthBuilder.put("august", 8);
        monthBuilder.put("sep", 9);
        monthBuilder.put("sept", 9);
        monthBuilder.put("september", 9);
        monthBuilder.put("oct", 10);
        monthBuilder.put("october", 10);
        monthBuilder.put("nov", 11);
        monthBuilder.put("november", 11);
        monthBuilder.put("dec", 12);
        monthBuilder.put("december", 12);
        months = Collections.unmodifiableMap(monthBuilder);

        // Build timezone abbreviation map - use HashMap since it's only used during initialization
        Map<String, String> timezoneBuilder = new HashMap<>();
        
        // North American Time Zones
        timezoneBuilder.put("EST", "America/New_York");    // Eastern Standard Time
        timezoneBuilder.put("EDT", "America/New_York");    // Eastern Daylight Time

        // CST is ambiguous: could be Central Standard Time (North America) or China Standard Time
        timezoneBuilder.put("CST", "America/Chicago");     // Central Standard Time

        timezoneBuilder.put("CDT", "America/Chicago");     // Central Daylight Time
        // Note: CDT can also be Cuba Daylight Time (America/Havana)

        // MST is ambiguous: could be Mountain Standard Time (North America) or Myanmar Standard Time
        // Chose Myanmar Standard Time due to larger population
        // Conflicts: America/Denver (Mountain Standard Time)
        timezoneBuilder.put("MST", "America/Denver");      // Mountain Standard Time

        timezoneBuilder.put("MDT", "America/Denver");      // Mountain Daylight Time

        // PST is ambiguous: could be Pacific Standard Time (North America) or Philippine Standard Time
        timezoneBuilder.put("PST", "America/Los_Angeles"); // Pacific Standard Time
        timezoneBuilder.put("PDT", "America/Los_Angeles"); // Pacific Daylight Time

        timezoneBuilder.put("AKST", "America/Anchorage");  // Alaska Standard Time
        timezoneBuilder.put("AKDT", "America/Anchorage");  // Alaska Daylight Time

        timezoneBuilder.put("HST", "Pacific/Honolulu");    // Hawaii Standard Time
        // Hawaii does not observe Daylight Saving Time

        // European Time Zones
        timezoneBuilder.put("GMT", "Europe/London");       // Greenwich Mean Time

        // BST is ambiguous: could be British Summer Time or Bangladesh Standard Time
        // Chose British Summer Time as it's more commonly used in international contexts
        timezoneBuilder.put("BST", "Europe/London");       // British Summer Time
        timezoneBuilder.put("WET", "Europe/Lisbon");       // Western European Time
        timezoneBuilder.put("WEST", "Europe/Lisbon");      // Western European summer

        timezoneBuilder.put("CET", "Europe/Berlin");       // Central European Time
        timezoneBuilder.put("CEST", "Europe/Berlin");      // Central European summer

        timezoneBuilder.put("EET", "Europe/Kyiv");         // Eastern European Time
        timezoneBuilder.put("EEST", "Europe/Kyiv");        // Eastern European summer

        // Australia and New Zealand Time Zones
        timezoneBuilder.put("AEST", "Australia/Brisbane"); // Australian Eastern Standard Time
        // Brisbane does not observe Daylight Saving Time

        timezoneBuilder.put("AEDT", "Australia/Sydney");   // Australian Eastern Daylight Time

        timezoneBuilder.put("ACST", "Australia/Darwin");   // Australian Central Standard Time
        // Darwin does not observe Daylight Saving Time

        timezoneBuilder.put("ACDT", "Australia/Adelaide"); // Australian Central Daylight Time

        timezoneBuilder.put("AWST", "Australia/Perth");    // Australian Western Standard Time
        // Perth does not observe Daylight Saving Time

        timezoneBuilder.put("NZST", "Pacific/Auckland");   // New Zealand Standard Time
        timezoneBuilder.put("NZDT", "Pacific/Auckland");   // New Zealand Daylight Time

        // South American Time Zones
        timezoneBuilder.put("CLT", "America/Santiago");    // Chile Standard Time
        timezoneBuilder.put("CLST", "America/Santiago");   // Chile summer

        timezoneBuilder.put("PYT", "America/Asuncion");    // Paraguay Standard Time
        timezoneBuilder.put("PYST", "America/Asuncion");   // Paraguay summer

        // ART is ambiguous: could be Argentina Time or Eastern European Time (Egypt)
        // Chose Argentina Time due to larger population
        // Conflicts: Africa/Cairo (Egypt)
        timezoneBuilder.put("ART", "America/Argentina/Buenos_Aires"); // Argentina Time

        // Middle East Time Zones
        // IST is ambiguous: could be India Standard Time, Israel Standard Time, or Irish Standard Time
        // Chose India Standard Time due to larger population
        // Conflicts: Asia/Jerusalem (Israel), Europe/Dublin (Ireland)
        timezoneBuilder.put("IST", "Asia/Kolkata");        // India Standard Time

        timezoneBuilder.put("IDT", "Asia/Jerusalem");      // Israel Daylight Time

        timezoneBuilder.put("IRST", "Asia/Tehran");        // Iran Standard Time
        timezoneBuilder.put("IRDT", "Asia/Tehran");        // Iran Daylight Time

        // Africa Time Zones
        timezoneBuilder.put("WAT", "Africa/Lagos");        // West Africa Time
        timezoneBuilder.put("CAT", "Africa/Harare");       // Central Africa Time

        // Asia Time Zones
        timezoneBuilder.put("JST", "Asia/Tokyo");          // Japan Standard Time

        // KST is ambiguous: could be Korea Standard Time or Kazakhstan Standard Time
        // Chose Korea Standard Time due to larger population
        // Conflicts: Asia/Almaty (Kazakhstan)
        timezoneBuilder.put("KST", "Asia/Seoul");          // Korea Standard Time

        timezoneBuilder.put("HKT", "Asia/Hong_Kong");      // Hong Kong Time

        // SGT is ambiguous: could be Singapore Time or Sierra Leone Time (defunct)
        // Chose Singapore Time due to larger population
        timezoneBuilder.put("SGT", "Asia/Singapore");      // Singapore Time

        // MST is mapped to America/Denver (Mountain Standard Time) above
        // MYT is Malaysia Time
        timezoneBuilder.put("MYT", "Asia/Kuala_Lumpur");   // Malaysia Time

        // Additional Time Zones
        timezoneBuilder.put("MSK", "Europe/Moscow");       // Moscow Standard Time
        timezoneBuilder.put("MSD", "Europe/Moscow");       // Moscow Daylight Time (historical)

        timezoneBuilder.put("EAT", "Africa/Nairobi");      // East Africa Time

        // HKT is unique to Hong Kong Time
        // No conflicts

        // ICT is unique to Indochina Time
        // Covers Cambodia, Laos, Thailand, Vietnam
        timezoneBuilder.put("ICT", "Asia/Bangkok");        // Indochina Time

        // Chose "COT" for Colombia Time
        timezoneBuilder.put("COT", "America/Bogota");      // Colombia Time

        // Chose "PET" for Peru Time
        timezoneBuilder.put("PET", "America/Lima");        // Peru Time

        // Chose "PKT" for Pakistan Standard Time
        timezoneBuilder.put("PKT", "Asia/Karachi");        // Pakistan Standard Time

        // Chose "WIB" for Western Indonesian Time
        timezoneBuilder.put("WIB", "Asia/Jakarta");        // Western Indonesian Time

        // Chose "KST" for Korea Standard Time (already mapped)
        // Chose "PST" for Philippine Standard Time (already mapped)
        // Chose "CCT" for China Coast Time (historical, now China Standard Time)
        // Chose "SGT" for Singapore Time (already mapped)

        // Add more mappings as needed, following the same pattern
        
        // Make timezone abbreviation map immutable for thread safety and security
        ABBREVIATION_TO_TIMEZONE = Collections.unmodifiableMap(timezoneBuilder);
    }

    private DateUtilities() {
    }

    private static ZonedDateTime tryStrictIsoParse(String dateStr) {
        final int len = dateStr.length();
        // Shape gate: "yyyy-MM-ddT..." — dashes at 4 and 7, 'T' at 10 (case-sensitive,
        // matching the flexible path, which also rejects lowercase 't').
        if (len < 12 || dateStr.charAt(4) != '-' || dateStr.charAt(7) != '-' || dateStr.charAt(10) != 'T') {
            return null;
        }
        // Zone/offset scan beyond the 'T': 'Z'/'+'/'-' marks an offset/UTC form. A '[' marks a
        // bracketed zone region — defer entirely to the flexible path (see Javadoc). Zone-less
        // ISO also defers, so the caller's defaultZoneId is applied.
        boolean zoned = false;
        for (int i = 11; i < len; i++) {
            char c = dateStr.charAt(i);
            if (c == '[') {
                return null;
            }
            if (c == 'Z' || c == '+' || c == '-') {
                zoned = true;
            }
        }
        if (!zoned) {
            return null;
        }
        ZonedDateTime zdt;
        try {
            if (dateStr.charAt(len - 1) == 'Z') {
                // Trailing-Z (the most common machine form): ISO_INSTANT's specialized
                // parser is measurably faster than the general ZonedDateTime.parse.
                // Output parity: ZonedDateTime.parse on a trailing-Z string also yields
                // zone Z, so the two are interchangeable here.
                return Instant.parse(dateStr).atZone(ZoneOffset.UTC);
            }
            zdt = ZonedDateTime.parse(dateStr);
        } catch (Exception notStrictIso) {
            return null;
        }
        if (zdt.getZone() instanceof ZoneOffset && dateStr.charAt(len - 1) != 'Z') {
            // Bare numeric offset ("+05:30", "+00:00"): normalize to the GMT-prefixed
            // ZoneId the flexible path has always produced. Trailing-Z forms keep zone Z.
            zdt = zdt.withZoneSameLocal(ZoneId.ofOffset("GMT", (ZoneOffset) zdt.getZone()));
        }
        return zdt;
    }

    private static ZoneId getTimeZone(String tz) {
        if (tz == null || tz.isEmpty()) {
            return ZoneId.systemDefault();
        }

        // Input validation for security: prevent excessively long timezone strings
        if (tz.length() > 100) {
            throw new IllegalArgumentException("Timezone string too long (max 100 characters): " + tz.length());
        }

        // Additional security validation: prevent control characters and null bytes
        for (int i = 0; i < tz.length(); i++) {
            char c = tz.charAt(i);
            if (c < 32 || c == 127) { // Control characters including null byte
                throw new IllegalArgumentException("Invalid timezone string contains control characters");
            }
        }

        // 1) If tz starts with +/- => offset
        if (tz.startsWith("-") || tz.startsWith("+")) {
            try {
                ZoneOffset offset = ZoneOffset.of(tz);
                return ZoneId.ofOffset("GMT", offset);
            } catch (java.time.DateTimeException e) {
                // Preserve DateTimeException for API compatibility (e.g., test expectations)
                throw e;
            } catch (Exception e) {
                // For other exceptions, apply security measures
                throw new IllegalArgumentException("Invalid timezone offset format: " + tz.substring(0, Math.min(tz.length(), 20)));
            }
        }

        // 2) Handle GMT explicitly to normalize to Etc/GMT (case insensitive)
        if (tz.equalsIgnoreCase("GMT")) {
            return ZoneId.of("Etc/GMT");
        }

        // 3) Check custom abbreviation map first (case insensitive lookup)
        String mappedZone = ABBREVIATION_TO_TIMEZONE.get(tz.toUpperCase(Locale.ROOT));
        if (mappedZone != null) {
            try {
                // e.g. "EST" => "America/New_York"
                return ZoneId.of(mappedZone);
            } catch (Exception e) {
                // Security: Don't expose internal mapping details in exceptions
                throw new IllegalArgumentException("Invalid timezone abbreviation: " + tz.substring(0, Math.min(tz.length(), 10)));
            }
        }

        // 4) Try ZoneId.of(tz) for full region IDs like "Europe/Paris"
        try {
            return ZoneId.of(tz);
        } catch (java.time.zone.ZoneRulesException zoneRulesEx) {
            // Preserve ZoneRulesException for API compatibility (e.g., test expectations)
            // 5) Fallback to TimeZone for legacy support, but if that also fails, rethrow original
            try {
                TimeZone timeZone = TimeZone.getTimeZone(tz);
                if (timeZone.getID().equals("GMT") && !tz.equalsIgnoreCase("GMT")) {
                    // Means the JDK didn't recognize 'tz' (it fell back to "GMT")
                    throw zoneRulesEx;  // rethrow original ZoneRulesException
                }
                // Additional security check: ensure the returned timezone ID is reasonable
                String timeZoneId = timeZone.getID();
                if (timeZoneId.length() > 50) {
                    throw new IllegalArgumentException("Invalid timezone ID returned by system");
                }
                return timeZone.toZoneId();
            } catch (java.time.zone.ZoneRulesException ex) {
                throw ex;  // Preserve ZoneRulesException
            } catch (Exception fallbackEx) {
                // For non-ZoneRulesException, rethrow the original ZoneRulesException for API compatibility
                throw zoneRulesEx;
            }
        } catch (Exception otherEx) {
            // For other exceptions (DateTimeException, etc.), apply security measures
            // 5) Fallback to TimeZone for legacy support, but with enhanced security validation
            try {
                TimeZone timeZone = TimeZone.getTimeZone(tz);
                if (timeZone.getID().equals("GMT") && !tz.equalsIgnoreCase("GMT")) {
                    // Means the JDK didn't recognize 'tz' (it fell back to "GMT")
                    // Security: Don't expose internal exception details
                    throw new IllegalArgumentException("Unrecognized timezone: " + tz.substring(0, Math.min(tz.length(), 20)));
                }
                // Additional security check: ensure the returned timezone ID is reasonable
                String timeZoneId = timeZone.getID();
                if (timeZoneId.length() > 50) {
                    throw new IllegalArgumentException("Invalid timezone ID returned by system");
                }
                return timeZone.toZoneId();
            } catch (Exception fallbackEx) {
                // Security: Sanitize exception message to prevent information disclosure
                throw new IllegalArgumentException("Invalid timezone format: " + tz.substring(0, Math.min(tz.length(), 20)));
            }
        }
    }

    private static String removeDateMarkerCharacters(String input) {
        StringBuilder builder = null;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c == 'T' || c == ',') {
                if (builder == null) {
                    builder = new StringBuilder(input.length() - 1);
                    builder.append(input, 0, i);
                }
            } else if (builder != null) {
                builder.append(c);
            }
        }
        return builder == null ? input : builder.toString();
    }

    private static String stripBrackets(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        if (input.length() >= 2 && input.charAt(0) == '[' && input.charAt(input.length() - 1) == ']') {
            return input.substring(1, input.length() - 1);
        }
        return input;
    }
}

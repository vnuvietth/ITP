package com.cedarsoftware.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.logging.ConsoleHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.LogManager;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

/**
 * Configures java.util.logging to use a uniform log format similar to
 * popular frameworks like SLF4J/Logback.
 */
public final class LoggingConfig {
    private static final String DATE_FORMAT_PROP = "ju.log.dateFormat";
    private static final String DEFAULT_PATTERN = "yyyy-MM-dd HH:mm:ss.SSS";
    private static boolean initialized = false;

    private LoggingConfig() {
    }

    /**
     * Check if the current call stack includes test classes.
     */
    private static boolean isCalledFromTestClass() {
        StackTraceElement[] stack = Thread.currentThread().getStackTrace();
        for (StackTraceElement element : stack) {
            String className = element.getClassName();
            if (className.contains(".test.") || className.endsWith("Test")) {
                return true;
            }
        }
        return false;
    }

    /**
     * Initialize logging with simple format for tests (no timestamps, no thread names).
     * Use this in test environments to get clean output similar to Maven's format.
     * This method will force the test formatter even if logging was already initialized.
     */
    public static synchronized void initForTests() {
        Logger root = LogManager.getLogManager().getLogger("");
        for (Handler h : root.getHandlers()) {
            if (h instanceof ConsoleHandler) {
                h.setFormatter(new SimpleTestFormatter());
            }
        }
        initialized = true;
    }

    /**
     * Simple formatter for tests that produces clean output similar to Maven's format:
     * {@code [LEVEL] message}
     */
    public static class SimpleTestFormatter extends Formatter {
        @Override
        public String format(LogRecord r) {
            String level = r.getLevel().getName();
            String msg = formatMessage(r);
            StringBuilder sb = new StringBuilder();
            sb.append('[').append(level).append("] ").append(msg);
            if (r.getThrown() != null) {
                StringWriter sw = new StringWriter();
                r.getThrown().printStackTrace(new PrintWriter(sw));
                sb.append(System.lineSeparator()).append(sw);
            }
            sb.append(System.lineSeparator());
            return sb.toString();
        }
    }

}

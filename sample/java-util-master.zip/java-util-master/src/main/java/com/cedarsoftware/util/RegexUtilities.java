package com.cedarsoftware.util;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Utility class for safe and efficient regular expression operations.
 * Provides ReDoS (Regular Expression Denial of Service) protection through
 * timeout enforcement and performance optimization through pattern caching.
 *
 * <h2>Key Features</h2>
 * <ul>
 *   <li><b>ReDoS Protection:</b> Enforces configurable timeouts on regex operations to prevent catastrophic backtracking</li>
 *   <li><b>Pattern Caching:</b> Caches compiled Pattern objects to avoid repeated compilation overhead</li>
 *   <li><b>Thread Safety:</b> All operations are thread-safe with concurrent caching</li>
 *   <li><b>Invalid Pattern Tracking:</b> Remembers invalid patterns to avoid repeated compilation attempts</li>
 * </ul>
 *
 * <h2>Security Configuration</h2>
 * Security features can be controlled via system properties:
 * <ul>
 *   <li><code>cedarsoftware.security.enabled</code> - Enable/disable all security features (default: true)</li>
 *   <li><code>cedarsoftware.regex.timeout.enabled</code> - Enable/disable regex timeout (default: true)</li>
 *   <li><code>cedarsoftware.regex.timeout.milliseconds</code> - Timeout in milliseconds (default: 5000)</li>
 * </ul>
 *
 * <h2>Usage Examples</h2>
 * <pre>
 * // Safe matching with timeout protection
 * Pattern pattern = RegexUtilities.getCachedPattern("\\d+");
 * boolean matches = RegexUtilities.safeMatches(pattern, "12345");
 *
 * // Safe find operation with result capture
 * SafeMatchResult result = RegexUtilities.safeFind(pattern, "abc123def");
 * if (result.matched()) {
 *     String found = result.group(0);  // "123"
 * }
 *
 * // Case-insensitive pattern caching
 * Pattern ciPattern = RegexUtilities.getCachedPattern("hello", true);
 * </pre>
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public final class RegexUtilities {

    // System property keys for configuration
    private static final String SECURITY_ENABLED_PROPERTY = "cedarsoftware.security.enabled";
    private static final String REGEX_TIMEOUT_ENABLED_PROPERTY = "cedarsoftware.regex.timeout.enabled";
    private static final String REGEX_TIMEOUT_MS_PROPERTY = "cedarsoftware.regex.timeout.milliseconds";

    // Default configuration values
    private static final long DEFAULT_TIMEOUT_MS = 5000L;
    private static final int MAX_TIMEOUT_THREADS = Math.max(2, Math.min(8, Runtime.getRuntime().availableProcessors()));
    private static final int MAX_TIMEOUT_QUEUE_SIZE = MAX_TIMEOUT_THREADS * 16;
    // Shared bounded executor for regex timeout operations.
    private static final ThreadPoolExecutor REGEX_EXECUTOR = createRegexExecutor();

    private RegexUtilities() {
        // Utility class - prevent instantiation
    }

    private static ThreadPoolExecutor createRegexExecutor() {
        ThreadFactory threadFactory = new ThreadFactory() {
            private final AtomicInteger threadCounter = new AtomicInteger(1);

            @Override
            public Thread newThread(Runnable runnable) {
                Thread thread = new Thread(runnable, "RegexUtilities-Timeout-Thread-" + threadCounter.getAndIncrement());
                thread.setDaemon(true);
                return thread;
            }
        };

        ThreadPoolExecutor executor = new ThreadPoolExecutor(
                MAX_TIMEOUT_THREADS,
                MAX_TIMEOUT_THREADS,
                30L,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(MAX_TIMEOUT_QUEUE_SIZE),
                threadFactory,
                new ThreadPoolExecutor.AbortPolicy());
        executor.allowCoreThreadTimeOut(true);
        return executor;
    }

    private static boolean isTimeoutProtectionEnabled() {
        return isSecurityEnabled() && isRegexTimeoutEnabled();
    }

    private static <T> T executeWithTimeout(Callable<T> operation, long timeout) {
        Future<T> future;
        try {
            future = REGEX_EXECUTOR.submit(operation);
        } catch (RejectedExecutionException e) {
            throw new SecurityException("Regex operation rejected due to timeout executor saturation", e);
        }

        try {
            return future.get(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            future.cancel(true);
            Thread.currentThread().interrupt();
            throw new SecurityException("Regex operation interrupted", e);
        } catch (TimeoutException e) {
            future.cancel(true);
            throw new SecurityException("Regex operation timed out (>" + timeout + "ms) - possible ReDoS attack", e);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause() == null ? e : e.getCause();
            throw new SecurityException("Regex operation failed: " + cause.getMessage(), cause);
        }
    }

    // ========== Configuration Methods ==========

    /**
     * Checks if security features are enabled.
     * @return true if security is enabled (default), false otherwise
     */
    public static boolean isSecurityEnabled() {
        return Boolean.parseBoolean(System.getProperty(SECURITY_ENABLED_PROPERTY, "true"));
    }

    /**
     * Checks if regex timeout protection is enabled.
     * @return true if timeout is enabled (default), false otherwise
     */
    public static boolean isRegexTimeoutEnabled() {
        return Boolean.parseBoolean(System.getProperty(REGEX_TIMEOUT_ENABLED_PROPERTY, "true"));
    }

    /**
     * Gets the configured regex timeout in milliseconds.
     * @return timeout in milliseconds (default: 5000)
     */
    public static long getRegexTimeoutMilliseconds() {
        String value = System.getProperty(REGEX_TIMEOUT_MS_PROPERTY);
        if (value != null) {
            try {
                long timeout = Long.parseLong(value);
                if (timeout > 0L) {
                    return timeout;
                }
            } catch (NumberFormatException ignored) {
                // Fall through to default
            }
        }
        return DEFAULT_TIMEOUT_MS;
    }


}

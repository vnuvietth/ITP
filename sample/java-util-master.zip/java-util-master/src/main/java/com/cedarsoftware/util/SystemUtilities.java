package com.cedarsoftware.util;

import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Utility class providing common system-level operations and information gathering capabilities.
 * This class offers static methods for accessing and managing system resources, environment
 * settings, and runtime information.
 *
 * <h2>Security Configuration</h2>
 * <p>SystemUtilities provides configurable security controls to prevent various attack vectors including
 * information disclosure, resource exhaustion, and system manipulation attacks.
 * All security features are <strong>disabled by default</strong> for backward compatibility.</p>
 *
 * <p>Security controls can be enabled via system properties:</p>
 * <ul>
 *   <li><code>systemutilities.security.enabled=false</code> &mdash; Master switch for all security features</li>
 *   <li><code>systemutilities.environment.variable.validation.enabled=false</code> &mdash; Block sensitive environment variable access</li>
 *   <li><code>systemutilities.file.system.validation.enabled=false</code> &mdash; Validate file system operations</li>
 *   <li><code>systemutilities.resource.limits.enabled=false</code> &mdash; Enforce resource usage limits</li>
 *   <li><code>systemutilities.max.shutdown.hooks=100</code> &mdash; Maximum number of shutdown hooks</li>
 *   <li><code>systemutilities.max.temp.prefix.length=100</code> &mdash; Maximum temporary directory prefix length</li>
 *   <li><code>systemutilities.sensitive.variable.patterns=password,secret,key,...</code> &mdash; Comma-separated sensitive variable patterns</li>
 * </ul>
 *
 * <h3>Security Features</h3>
 * <ul>
 *   <li><b>Environment Variable Protection:</b> Prevents access to sensitive environment variables (passwords, tokens, etc.)</li>
 *   <li><b>File System Validation:</b> Validates temporary directory prefixes to prevent path traversal attacks</li>
 *   <li><b>Resource Limits:</b> Configurable limits on shutdown hooks and other resources to prevent exhaustion</li>
 *   <li><b>Information Disclosure Prevention:</b> Sanitizes variable names and prevents credential exposure</li>
 * </ul>
 *
 * <h3>Usage Example</h3>
 * <pre>{@code
 * // Enable security with custom settings
 * System.setProperty("systemutilities.security.enabled", "true");
 * System.setProperty("systemutilities.environment.variable.validation.enabled", "true");
 * System.setProperty("systemutilities.file.system.validation.enabled", "true");
 * System.setProperty("systemutilities.max.shutdown.hooks", "50");
 *
 * // These will now enforce security controls
 * String var = SystemUtilities.getExternalVariable("NORMAL_VAR"); // works
 * String pass = SystemUtilities.getExternalVariable("PASSWORD"); // returns null (filtered)
 * }</pre>
 *
 * <h2>Key Features:</h2>
 * <ul>
 *     <li>System environment and property access</li>
 *     <li>Memory usage monitoring and management</li>
 *     <li>Network interface information retrieval</li>
 *     <li>Process management and identification</li>
 *     <li>Runtime environment analysis</li>
 *     <li>Temporary file management</li>
 * </ul>
 *
 * <h2>Usage Examples:</h2>
 * <pre>{@code
 * // Get system environment variable with fallback to system property
 * String configPath = SystemUtilities.getExternalVariable("CONFIG_PATH");
 *
 * // Check available system resources
 * int processors = SystemUtilities.getAvailableProcessors();
 * MemoryInfo memory = SystemUtilities.getMemoryInfo();
 *
 * // Get network configuration
 * List<NetworkInfo> networks = SystemUtilities.getNetworkInterfaces();
 * }</pre>
 *
 * <p>All methods in this class are thread-safe unless otherwise noted. The class cannot be
 * instantiated and provides only static utility methods.</p>
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 *
 * @see Runtime
 * @see System
 * @see ManagementFactory
 */
public final class SystemUtilities {
    private static final String osNameRaw = System.getProperty("os.name");
    // Locale.ROOT: on a Turkish-locale JVM, default-locale lowercasing turns "Windows"
    // into "wındows" (dotless ı), breaking any consumer's OS_NAME.contains("windows") check
    public static final String OS_NAME = osNameRaw != null ? osNameRaw.toLowerCase(Locale.ROOT) : "unknown";
    public static final String JAVA_VERSION = System.getProperty("java.version", "unknown");
    public static final String USER_HOME = System.getProperty("user.home", "");
    public static final String TEMP_DIR = System.getProperty("java.io.tmpdir", "");
    private static final Logger LOG = Logger.getLogger(SystemUtilities.class.getName());


    // Default sensitive variable patterns (moved to system properties in static initializer)
    private static final String DEFAULT_SENSITIVE_VARIABLE_PATTERNS =
            "PASSWORD,PASSWD,PASS,SECRET,KEY,TOKEN,CREDENTIAL,AUTH,APIKEY,API_KEY,PRIVATE,CERT,CERTIFICATE,DATABASE_URL,DB_URL,CONNECTION_STRING,DSN,AWS_SECRET,AZURE_CLIENT_SECRET,GCP_SERVICE_ACCOUNT";

    // Default resource limits
    private static final int DEFAULT_MAX_SHUTDOWN_HOOKS = 100;
    private static final int DEFAULT_MAX_TEMP_PREFIX_LENGTH = 100;
    private static final String INVALID_TEMP_PREFIX_CHARS = "<>:\"|?*";

    // Security: Resource limits for system operations
    private static final AtomicInteger SHUTDOWN_HOOK_COUNT = new AtomicInteger(0);

    // Cached security configuration (volatile for thread-safe lazy initialization)
    private static volatile Set<String> cachedSensitivePatterns;
    private static volatile String cachedPatternSource;
    private static final Object PATTERN_LOCK = new Object();

    static {
        // Initialize system properties with defaults if not already set (backward compatibility)
        initializeSystemPropertyDefaults();
    }

    private static void initializeSystemPropertyDefaults() {
        // Set sensitive variable patterns if not explicitly configured
        if (System.getProperty("systemutilities.sensitive.variable.patterns") == null) {
            System.setProperty("systemutilities.sensitive.variable.patterns", DEFAULT_SENSITIVE_VARIABLE_PATTERNS);
        }

        // Set max shutdown hooks if not explicitly configured
        if (System.getProperty("systemutilities.max.shutdown.hooks") == null) {
            System.setProperty("systemutilities.max.shutdown.hooks", String.valueOf(DEFAULT_MAX_SHUTDOWN_HOOKS));
        }

        // Set max temp prefix length if not explicitly configured
        if (System.getProperty("systemutilities.max.temp.prefix.length") == null) {
            System.setProperty("systemutilities.max.temp.prefix.length", String.valueOf(DEFAULT_MAX_TEMP_PREFIX_LENGTH));
        }
    }

    // Security configuration methods

    private static boolean isSecurityEnabled() {
        return Boolean.parseBoolean(System.getProperty("systemutilities.security.enabled", "false"));
    }

    private static boolean isEnvironmentVariableValidationEnabled() {
        return Boolean.parseBoolean(System.getProperty("systemutilities.environment.variable.validation.enabled", "false"));
    }

    private static boolean isFileSystemValidationEnabled() {
        return Boolean.parseBoolean(System.getProperty("systemutilities.file.system.validation.enabled", "false"));
    }

    private static boolean isResourceLimitsEnabled() {
        return Boolean.parseBoolean(System.getProperty("systemutilities.resource.limits.enabled", "false"));
    }

    private static int getMaxShutdownHooks() {
        String maxHooksProp = System.getProperty("systemutilities.max.shutdown.hooks");
        if (maxHooksProp != null) {
            try {
                return Math.max(1, Integer.parseInt(maxHooksProp));
            } catch (NumberFormatException e) {
                // Fall through to default
            }
        }
        return isSecurityEnabled() ? DEFAULT_MAX_SHUTDOWN_HOOKS : Integer.MAX_VALUE;
    }

    private static int getMaxTempPrefixLength() {
        String maxLengthProp = System.getProperty("systemutilities.max.temp.prefix.length");
        if (maxLengthProp != null) {
            try {
                return Math.max(1, Integer.parseInt(maxLengthProp));
            } catch (NumberFormatException e) {
                // Fall through to default
            }
        }
        return isSecurityEnabled() ? DEFAULT_MAX_TEMP_PREFIX_LENGTH : Integer.MAX_VALUE;
    }

    private static Set<String> getSensitiveVariablePatterns() {
        String patterns = System.getProperty("systemutilities.sensitive.variable.patterns", DEFAULT_SENSITIVE_VARIABLE_PATTERNS);

        // Double-checked locking for thread-safe lazy caching
        if (cachedSensitivePatterns == null || !patterns.equals(cachedPatternSource)) {
            synchronized (PATTERN_LOCK) {
                if (cachedSensitivePatterns == null || !patterns.equals(cachedPatternSource)) {
                    // Pre-process patterns: trim and uppercase for efficient matching
                    Set<String> processedPatterns = new HashSet<>();
                    for (String pattern : patterns.split(",")) {
                        String trimmed = pattern.trim().toUpperCase(Locale.ROOT);
                        if (!trimmed.isEmpty()) {
                            processedPatterns.add(trimmed);
                        }
                    }
                    cachedPatternSource = patterns;
                    cachedSensitivePatterns = processedPatterns;
                }
            }
        }
        return cachedSensitivePatterns;
    }

    private SystemUtilities() {
    }

    private static boolean isNullOrEmpty(String value) {
        return value == null || value.isEmpty();
    }

    /**
     * Checks if a variable name matches patterns for sensitive information.
     *
     * @param varName the variable name to check
     * @return true if the variable name suggests sensitive content
     */
    private static boolean isSensitiveVariable(String varName) {
        if (varName == null) {
            return false;
        }

        String upperVar = varName.toUpperCase(Locale.ROOT);
        Set<String> sensitivePatterns = getSensitiveVariablePatterns();
        // Simple loop is more efficient than stream for this use case
        for (String pattern : sensitivePatterns) {
            if (upperVar.contains(pattern)) {
                return true;
            }
        }
        return false;
    }


    /**
     * Get available processors, considering Docker container limits
     */
    public static int getAvailableProcessors() {
        return Math.max(1, Runtime.getRuntime().availableProcessors());
    }

    /**
     * Get system load average over last minute
     *
     * @return load average or -1.0 if not available
     */
    public static double getSystemLoadAverage() {
        return ManagementFactory.getOperatingSystemMXBean().getSystemLoadAverage();
    }


    /**
     * Checks security manager permissions for reflection operations.
     *
     * @throws SecurityException if reflection is not permitted
     */
    private static void checkReflectionPermission() {
        SecurityManager sm = System.getSecurityManager();
        if (sm != null) {
            sm.checkPermission(new RuntimePermission("accessDeclaredMembers"));
        }
    }

    /**
     * Get process ID of current JVM
     *
     * @return process ID for the current Java process
     */
    public static long getCurrentProcessId() {
        String jvmName = ManagementFactory.getRuntimeMXBean().getName();
        int index = jvmName.indexOf('@');
        if (index < 1) {
            return 0;
        }
        try {
            return Long.parseLong(jvmName.substring(0, index));
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    /**
     * Validates the prefix for temporary directory creation.
     *
     * @param prefix the prefix to validate
     * @throws IllegalArgumentException if the prefix is invalid
     */
    private static void validateTempDirectoryPrefix(String prefix) {
        if (prefix == null) {
            throw new IllegalArgumentException("Temporary directory prefix cannot be null");
        }

        if (prefix.isEmpty()) {
            throw new IllegalArgumentException("Temporary directory prefix cannot be empty");
        }

        // Check for path traversal attempts
        if (prefix.contains("..") || prefix.contains("/") || prefix.contains("\\")) {
            throw new IllegalArgumentException("Temporary directory prefix contains invalid path characters: " + prefix);
        }

        // Check for null bytes and control characters
        if (prefix.contains("\0")) {
            throw new IllegalArgumentException("Temporary directory prefix contains null byte");
        }

        // Check for other dangerous characters
        if (containsAnyCharacter(prefix, INVALID_TEMP_PREFIX_CHARS)) {
            throw new IllegalArgumentException("Temporary directory prefix contains invalid characters: " + prefix);
        }

        // Limit length to prevent excessive resource usage
        int maxLength = getMaxTempPrefixLength();
        if (prefix.length() > maxLength) {
            throw new IllegalArgumentException("Temporary directory prefix too long (max " + maxLength + " characters): " + prefix.length());
        }
    }

    private static boolean containsAnyCharacter(String value, String chars) {
        for (int i = 0; i < value.length(); i++) {
            if (chars.indexOf(value.charAt(i)) >= 0) {
                return true;
            }
        }
        return false;
    }

    private static int calculateMapCapacity(int expectedEntries) {
        return Math.max(16, (int) ((expectedEntries / 0.75f) + 1));
    }

    /**
     * Get system timezone, considering the TZ environment variable and system default.
     *
     * @return the system timezone from TZ environment variable if valid, otherwise the JVM default
     */
    public static TimeZone getSystemTimeZone() {
        String tzEnv = System.getenv("TZ");
        if (tzEnv != null && !tzEnv.isEmpty()) {
            TimeZone tz = TimeZone.getTimeZone(tzEnv);
            // TimeZone.getTimeZone() returns GMT for unknown IDs - validate the result
            if (!"GMT".equals(tz.getID()) || "GMT".equalsIgnoreCase(tzEnv)) {
                return tz;
            }
            // TZ was set but invalid, log warning and fall back to default
            LOG.log(Level.WARNING, "Invalid timezone in TZ environment variable: " + tzEnv + ", using system default");
        }
        return TimeZone.getDefault();
    }


}

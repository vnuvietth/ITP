package com.cedarsoftware.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.net.URI;
import java.net.URL;
import java.util.AbstractMap;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.RandomAccess;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;

import static com.cedarsoftware.util.Converter.convert2BigDecimal;
import static com.cedarsoftware.util.Converter.convert2boolean;

@SuppressWarnings("unchecked")
public class DeepEquals {
    // Option keys
    public static final String IGNORE_CUSTOM_EQUALS = "ignoreCustomEquals";
    public static final String ALLOW_STRINGS_TO_MATCH_NUMBERS = "stringsCanMatchNumbers";
    public static final String DIFF = "diff";
    public static final String DIFF_ITEM = "diff_item";
    public static final String INCLUDE_DIFF_ITEM = "deepequals.include.diff_item";
    private static final String DEPTH_BUDGET = "__depthBudget";
    private static final String EMPTY = "∅";
    private static final String TRIANGLE_ARROW = "▶";
    private static final String ARROW = "⇨";
    private static final String ANGLE_LEFT = "《";
    private static final String ANGLE_RIGHT = "》";

    // Strict Base64 pattern that properly validates Base64 encoding
    // Matches strings that are properly padded Base64 (groups of 4 chars with proper padding)
    private static final Pattern BASE64_PATTERN = Pattern.compile(
            "^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$");
    
    // Precompiled patterns for sensitive data detection
    // Note: HEX_32_PLUS and UUID_PATTERN use lowercase patterns since strings are lowercased before matching
    private static final Pattern HEX_32_PLUS = Pattern.compile("^[a-f0-9]{32,}$");
    private static final Pattern SENSITIVE_WORDS = Pattern.compile(
            ".*\\b(password|pwd|secret|token|credential|auth|apikey|api_key|secretkey|secret_key|privatekey|private_key)\\b.*");
    private static final Pattern UUID_PATTERN = Pattern.compile(
            "^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$");
    
    // ThreadLocal stack of Sets to handle re-entrant formatValue() calls
    // Each re-entrant call gets its own Set for circular reference detection
    private static final ThreadLocal<Deque<Set<Object>>> formattingStack =
            ThreadLocal.withInitial(ArrayDeque::new);

    // ThreadLocal to track max depth budget for current comparison (handles re-entrant calls via stack)
    private static final ThreadLocal<Deque<Integer>> maxDepthBudgetStack = ThreadLocal.withInitial(ArrayDeque::new);
    
    // Epsilon values for floating-point comparisons
    private static final double DOUBLE_EPSILON = 1e-12;
    private static final float FLOAT_EPSILON = 1e-6f;
    
    // Configuration for security-safe error messages - removed static final, now uses dynamic method
    
    // Fields that should be redacted in error messages for security
    // Note: "auth" removed to avoid false positives like "author" - it's caught by SENSITIVE_WORDS regex
    private static final Set<String> SENSITIVE_FIELD_NAMES = CollectionUtilities.setOf(
            "password", "pwd", "passwd", "secret", "token", "credential", 
            "authorization", "authentication", "api_key", "apikey", "secretkey"
    );
    
    // Default security limits
    private static final int DEFAULT_MAX_COLLECTION_SIZE = 100000;
    private static final int DEFAULT_MAX_ARRAY_SIZE = 100000;
    private static final int DEFAULT_MAX_MAP_SIZE = 100000;
    private static final int DEFAULT_MAX_OBJECT_FIELDS = 1000;
    private static final int DEFAULT_MAX_RECURSION_DEPTH = 1000000;  // 1M depth for heap-based traversal

    // Cached security configuration values (parsed once at class load, reloadable for testing)
    private static boolean secureErrorsEnabled;
    private static int maxCollectionSize;
    private static int maxArraySize;
    private static int maxMapSize;
    private static int maxObjectFields;
    private static int maxRecursionDepth;

    static {
        reloadSecurityProperties();
    }

    /**
     * Reloads security configuration from system properties.
     * Package-private for testing purposes - allows tests to change system properties
     * and have the changes take effect.
     */
    static void reloadSecurityProperties() {
        secureErrorsEnabled = Boolean.parseBoolean(System.getProperty("deepequals.secure.errors", "false"));
        maxCollectionSize = parseIntProperty("deepequals.max.collection.size", DEFAULT_MAX_COLLECTION_SIZE);
        maxArraySize = parseIntProperty("deepequals.max.array.size", DEFAULT_MAX_ARRAY_SIZE);
        maxMapSize = parseIntProperty("deepequals.max.map.size", DEFAULT_MAX_MAP_SIZE);
        maxObjectFields = parseIntProperty("deepequals.max.object.fields", DEFAULT_MAX_OBJECT_FIELDS);
        maxRecursionDepth = parseIntProperty("deepequals.max.recursion.depth", DEFAULT_MAX_RECURSION_DEPTH);
    }

    private static int parseIntProperty(String propertyName, int defaultValue) {
        String prop = System.getProperty(propertyName);
        if (prop != null) {
            try {
                int value = Integer.parseInt(prop);
                return Math.max(0, value); // 0 means disabled
            } catch (NumberFormatException e) {
                // Fall through to default
            }
        }
        return defaultValue;
    }

    // Security configuration accessor methods (return cached values)

    private static boolean isSecureErrorsEnabled() {
        return secureErrorsEnabled;
    }

    private static int getMaxCollectionSize() {
        return maxCollectionSize;
    }

    private static int getMaxArraySize() {
        return maxArraySize;
    }

    private static int getMaxMapSize() {
        return maxMapSize;
    }

    private static int getMaxObjectFields() {
        return maxObjectFields;
    }

    private static int getMaxRecursionDepth() {
        return maxRecursionDepth;
    }
    
    /**
     * Calculate the depth of the current item in the object graph by counting
     * the number of parent links. This is used for heap-based depth tracking.
     */
    
    // Class to hold information about items being compared
    private final static class ItemsToCompare {
        private final Object _key1;
        private final Object _key2;
        private final ItemsToCompare parent;
        private final String fieldName;
        private final int[] arrayIndices;
        private final Object mapKey;
        private final Difference difference;    // New field
        private final int depth;    // Track depth for recursion limit

        // Modified constructors to include Difference

        // Constructor for root
        private ItemsToCompare(Object k1, Object k2) {
            this(k1, k2, null, null, null, null, null, 0);
        }

        // Constructor for differences where the Difference does not need additional information
        private ItemsToCompare(Object k1, Object k2, ItemsToCompare parent, Difference difference) {
            this(k1, k2, parent, null, null, null, difference, parent != null ? parent.depth + 1 : 0);
        }

        // Constructor for field access with difference
        private ItemsToCompare(Object k1, Object k2, String fieldName, ItemsToCompare parent, Difference difference) {
            this(k1, k2, parent, fieldName, null, null, difference, parent != null ? parent.depth + 1 : 0);
        }

        // Constructor for array access with difference
        private ItemsToCompare(Object k1, Object k2, int[] indices, ItemsToCompare parent, Difference difference) {
            this(k1, k2, parent, null, indices, null, difference, parent != null ? parent.depth + 1 : 0);
        }

        // Constructor for map access with difference
        private ItemsToCompare(Object k1, Object k2, Object mapKey, ItemsToCompare parent, boolean isMapKey, Difference difference) {
            this(k1, k2, parent, null, null, mapKey, difference, parent != null ? parent.depth + 1 : 0);
        }

        // Base constructor
        private ItemsToCompare(Object k1, Object k2, ItemsToCompare parent,
                               String fieldName, int[] arrayIndices, Object mapKey, Difference difference, int depth) {
            this._key1 = k1;
            this._key2 = k2;
            this.parent = parent;
            this.fieldName = fieldName;
            this.arrayIndices = arrayIndices;
            this.mapKey = mapKey;
            this.difference = difference;
            this.depth = depth;
        }

        @Override
        public boolean equals(Object other) {
            if (!(other instanceof ItemsToCompare)) {
                return false;
            }
            ItemsToCompare that = (ItemsToCompare) other;

            // Only compare the actual objects being compared (by identity)
            return _key1 == that._key1 && _key2 == that._key2;
        }

        @Override
        public int hashCode() {
            // Simple hash combining - identity hashcodes already have good distribution
            return System.identityHashCode(_key1) * 31 + System.identityHashCode(_key2);
        }
    }

    /**
     * A lightweight set wrapper for probing operations in unordered collection/map comparison.
     * Instead of copying the entire visited set (O(n)), this creates a view that tracks local
     * additions (O(1) creation). When the probe completes, the local additions are discarded
     * without affecting the original base set.
     *
     * This eliminates the O(n²) overhead from repeated visited set copying during
     * unordered collection comparison probing.
     */
    private static final class ScopedSet extends java.util.AbstractSet<ItemsToCompare> {
        private final Set<ItemsToCompare> base;
        private Set<ItemsToCompare> local;

        ScopedSet(Set<ItemsToCompare> base) {
            this.base = base;
        }

        @Override
        public boolean contains(Object o) {
            return base.contains(o) || (local != null && local.contains(o));
        }

        @Override
        public boolean add(ItemsToCompare item) {
            if (base.contains(item)) {
                return false;
            }
            if (local == null) {
                local = new HashSet<>();
            }
            return local.add(item);
        }

        @Override
        public Iterator<ItemsToCompare> iterator() {
            // Not needed for probing operations
            throw new UnsupportedOperationException("ScopedSet does not support iteration");
        }

        @Override
        public int size() {
            int size = base.size();
            if (local != null) {
                size += local.size();
            }
            return size;
        }

        void reset() {
            if (local != null) {
                local.clear();
            }
        }
    }

    /**
     * Calculate safe HashMap initial capacity to prevent integer overflow.
     * HashMap uses capacity = size * 4/3 to account for 0.75 load factor.
     * For large sizes approaching Integer.MAX_VALUE, this can overflow.
     *
     * @param size the expected number of elements
     * @return safe initial capacity, capped at Integer.MAX_VALUE
     */
    public static int safeHashMapCapacity(int size) {
        if (size < 0) {
            return 16;  // Default capacity for invalid sizes
        }

        // Calculate capacity = size * 4 / 3, but check for overflow
        // Max safe size before overflow: Integer.MAX_VALUE * 3 / 4 = 1,610,612,735
        if (size > 1_610_612_735) {
            return Integer.MAX_VALUE;  // Cap at max to prevent overflow
        }

        // Safe to multiply: size * 4 won't overflow since size <= 1,610,612,735
        long capacity = (long) size * 4 / 3;

        // Ensure minimum capacity of 16
        return Math.max(16, (int) capacity);
    }

    public static boolean isIntegralNumber(Number n) {
        return n instanceof Byte || n instanceof Short || 
               n instanceof Integer || n instanceof Long ||
               n instanceof AtomicInteger || n instanceof AtomicLong;
    }

    /**
     * Compares two numbers deeply, handling floating point precision.
     *
     * @param a First number.
     * @param b Second number.
     * @return true if numbers are equal within the defined precision, false otherwise.
     */
    public static boolean compareNumbers(Number a, Number b) {
        // Handle floating point comparisons
        if (a instanceof Float || a instanceof Double ||
                b instanceof Float || b instanceof Double) {

            // Check for overflow/underflow when comparing with BigDecimal
            if (a instanceof BigDecimal || b instanceof BigDecimal) {
                try {
                    BigDecimal bd;
                    if (a instanceof BigDecimal) {
                        bd = (BigDecimal) a;
                    } else {
                        bd = (BigDecimal) b;
                    }

                    // If BigDecimal is outside Double's range, they can't be equal
                    if (bd.compareTo(BigDecimal.valueOf(Double.MAX_VALUE)) > 0 ||
                            bd.compareTo(BigDecimal.valueOf(-Double.MAX_VALUE)) < 0) {
                        return false;
                    }
                } catch (Exception e) {
                    return false;
                }
            }

            // Normal floating point comparison
            double d1 = a.doubleValue();
            double d2 = b.doubleValue();
            return nearlyEqual(d1, d2);
        }

        // Fast path for integral numbers (avoids BigDecimal conversion)
        if (isIntegralNumber(a) && isIntegralNumber(b)) {
            return a.longValue() == b.longValue();
        }
        
        // For other non-floating point numbers (e.g., BigDecimal, BigInteger), use exact comparison
        try {
            BigDecimal x = convert2BigDecimal(a);
            BigDecimal y = convert2BigDecimal(b);
            return x.compareTo(y) == 0;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Correctly handles floating point comparisons with proper NaN and near-zero handling.
     *
     * @param a First double.
     * @param b Second double.
     * @return true if numbers are nearly equal within epsilon, false otherwise.
     */
    public static boolean nearlyEqual(double a, double b) {
        // Fast path: bitwise equality handles NaN==NaN (doubleToLongBits normalizes NaN).
        // Note: +0.0 and -0.0 have different bit patterns and are handled by the tolerance check below.
        if (Double.doubleToLongBits(a) == Double.doubleToLongBits(b)) {
            return true;
        }
        // NaN values that aren't the same bit pattern are not equal
        if (Double.isNaN(a) || Double.isNaN(b)) {
            return false;
        }
        // Treat any infinity as unequal to finite numbers
        if (Double.isInfinite(a) || Double.isInfinite(b)) {
            return false;
        }
        
        double diff = Math.abs(a - b);
        double norm = Math.max(Math.abs(a), Math.abs(b));
        
        // Near zero: use absolute tolerance; elsewhere: use relative tolerance
        return (norm == 0.0) ? diff <= DeepEquals.DOUBLE_EPSILON : diff <= DeepEquals.DOUBLE_EPSILON * norm;
    }
    
    /**
     * Correctly handles floating point comparisons for floats.
     *
     * @param a First float.
     * @param b Second float.
     * @return true if numbers are nearly equal within epsilon, false otherwise.
     */
    public static boolean nearlyEqual(float a, float b) {
        // Fast path: bitwise equality handles NaN==NaN (floatToIntBits normalizes NaN).
        // Note: +0.0f and -0.0f have different bit patterns and are handled by the tolerance check below.
        if (Float.floatToIntBits(a) == Float.floatToIntBits(b)) {
            return true;
        }
        // NaN values that aren't the same bit pattern are not equal
        if (Float.isNaN(a) || Float.isNaN(b)) {
            return false;
        }
        // Treat any infinity as unequal to finite numbers
        if (Float.isInfinite(a) || Float.isInfinite(b)) {
            return false;
        }
        
        float diff = Math.abs(a - b);
        float norm = Math.max(Math.abs(a), Math.abs(b));
        
        // Near zero: use absolute tolerance; elsewhere: use relative tolerance
        return (norm == 0.0f) ? diff <= DeepEquals.FLOAT_EPSILON : diff <= DeepEquals.FLOAT_EPSILON * norm;
    }

    public static int hashDouble(double value) {
        // Handle special cases first
        if (Double.isNaN(value)) {
            return 0x7ff80000;  // Stable NaN bucket
        }
        if (Double.isInfinite(value)) {
            return value > 0 ? 0x7ff00000 : 0xfff00000;  // Separate buckets for +∞ and -∞
        }

        // Normalize negative zero to positive zero
        if (value == 0.0) {
            value = 0.0;  // This ensures -0.0 becomes 0.0
        }

        // Large-magnitude regime: value * 1e10 would exceed Long.MAX_VALUE, making
        // Math.round saturate — which previously collapsed EVERY double above ~9.2e8
        // into a single hash bucket (degrading unordered-collection comparison to
        // O(n^2) pairwise probes). Quantize relatively instead by masking the low
        // 12 mantissa bits (~2^-40 ≈ 1e-12 relative granularity, matching
        // nearlyEqual's relative epsilon). Near-equal pairs that straddle a mask
        // boundary are still found by the cross-bucket slow-path fallback.
        if (value >= 9.0e8 || value <= -9.0e8) {
            long bits = Double.doubleToLongBits(value) & 0xFFFFFFFFFFFFF000L;
            return (int) (bits ^ (bits >>> 32));
        }

        // FIX: Use coarser quantization (1e10 instead of 1e12) to align with nearlyEqual's
        // epsilon tolerance of 1e-12. This ensures values within epsilon hash to same bucket.
        // The quantization is intentionally 100x coarser than epsilon to handle:
        // 1. Floating-point arithmetic errors in the quantization itself
        // 2. The fact that nearlyEqual uses relative tolerance (epsilon * max(|a|, |b|))
        // 3. Edge cases where values near powers of 2 may have slightly different representations

        double scale = 1e10;  // Coarser than 1/DOUBLE_EPSILON (1e12) to provide safety margin
        double quantized = Math.round(value * scale) / scale;

        // Ensure -0.0 becomes 0.0
        if (quantized == 0.0) {
            quantized = 0.0;
        }

        long bits = Double.doubleToLongBits(quantized);
        return (int) (bits ^ (bits >>> 32));
    }

    public static int hashFloat(float value) {
        // Handle special cases first
        if (Float.isNaN(value)) {
            return 0x7fc00000;  // Stable NaN bucket
        }
        if (Float.isInfinite(value)) {
            return value > 0 ? 0x7f800000 : 0xff800000;  // Separate buckets for +∞ and -∞
        }

        // Normalize negative zero to positive zero
        if (value == 0.0f) {
            value = 0.0f;  // This ensures -0.0f becomes 0.0f
        }

        // Large-magnitude regime: value * 1e5 would exceed Integer.MAX_VALUE, making
        // Math.round saturate — which previously collapsed EVERY float above ~21,474
        // into a single hash bucket. Quantize relatively instead by masking the low
        // 3 mantissa bits (~2^-20 ≈ 1e-6 relative granularity, matching nearlyEqual's
        // relative epsilon). Near-equal pairs that straddle a mask boundary are still
        // found by the cross-bucket slow-path fallback.
        if (value >= 2.0e4f || value <= -2.0e4f) {
            return Float.floatToIntBits(value) & 0xFFFFFFF8;
        }

        // FIX: Use coarser quantization (1e5 instead of 1e6) to align with nearlyEqual's
        // epsilon tolerance of 1e-6. This ensures values within epsilon hash to same bucket.
        float scale = 1e5f;  // Coarser than 1/FLOAT_EPSILON (1e6) to provide safety margin
        float quantized = Math.round(value * scale) / scale;

        // Ensure -0.0f becomes 0.0f
        if (quantized == 0.0f) {
            quantized = 0.0f;
        }

        return Float.floatToIntBits(quantized);
    }

    public enum DiffCategory {
        VALUE,
        TYPE,
        SIZE,
        LENGTH,
        DIMENSION
    }

    public enum Difference {
        // Basic value difference (includes numbers, atomic values, field values)
        VALUE_MISMATCH("value mismatch", DiffCategory.VALUE),
        FIELD_VALUE_MISMATCH("field value mismatch", DiffCategory.VALUE),

        // Collection-specific
        COLLECTION_SIZE_MISMATCH("collection size mismatch", DiffCategory.SIZE),
        COLLECTION_MISSING_ELEMENT("missing collection element", DiffCategory.VALUE),
        COLLECTION_TYPE_MISMATCH("collection type mismatch", DiffCategory.TYPE),
        COLLECTION_ELEMENT_MISMATCH("collection element mismatch", DiffCategory.VALUE),

        // Map-specific
        MAP_SIZE_MISMATCH("map size mismatch", DiffCategory.SIZE),
        MAP_MISSING_KEY("missing map key", DiffCategory.VALUE),
        MAP_VALUE_MISMATCH("map value mismatch", DiffCategory.VALUE),

        // Array-specific
        ARRAY_DIMENSION_MISMATCH("array dimensionality mismatch", DiffCategory.DIMENSION),
        ARRAY_COMPONENT_TYPE_MISMATCH("array component type mismatch", DiffCategory.TYPE),
        ARRAY_LENGTH_MISMATCH("array length mismatch", DiffCategory.LENGTH),
        ARRAY_ELEMENT_MISMATCH("array element mismatch", DiffCategory.VALUE),

        // General type mismatch (when classes don't match)
        TYPE_MISMATCH("type mismatch", DiffCategory.TYPE);

        private final String description;
        private final DiffCategory category;

        Difference(String description, DiffCategory category) {
            this.description = description;
            this.category = category;
        }

        String getDescription() { return description; }
        DiffCategory getCategory() { return category; }
    }

    /**
     * Tiny struct-like class to hold both the path & the mismatch phrase.
     */
    private static class PathResult {
        final String path;
        final String mismatchPhrase;

        PathResult(String path, String mismatchPhrase) {
            this.path = path;
            this.mismatchPhrase = mismatchPhrase;
        }
    }
}

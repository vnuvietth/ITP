package com.cedarsoftware.util;

import java.util.Collection;

public class CompactCILinkedSet<E>  {


}

package com.cedarsoftware.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Objects;
import java.util.RandomAccess;

import com.cedarsoftware.util.fastdoubleparser.JavaBigDecimalParser;
import com.cedarsoftware.util.fastdoubleparser.JavaBigIntegerParser;
import com.cedarsoftware.util.fastdoubleparser.JavaDoubleParser;
import com.cedarsoftware.util.fastdoubleparser.JavaFloatParser;

import static java.util.Collections.swap;

/**
 * Mathematical utility class providing enhanced numeric operations and algorithms.
 * <p>
 * This class provides:
 * </p>
 * <ul>
 *   <li>Minimum/Maximum calculations for various numeric types</li>
 *   <li>Smart numeric parsing with minimal type selection</li>
 *   <li>Permutation generation</li>
 *   <li>Common mathematical constants</li>
 * </ul>
 *
 * <p><strong>Features:</strong></p>
 * <ul>
 *   <li>Support for primitive types (long, double)</li>
 *   <li>Support for BigInteger and BigDecimal</li>
 *   <li>Null-safe operations</li>
 *   <li>Efficient implementations</li>
 *   <li>Thread-safe operations</li>
 * </ul>
 *
 * <p><strong>Security Configuration:</strong></p>
 * <p>MathUtilities provides configurable security options through system properties.
 * All security features are <strong>disabled by default</strong> for backward compatibility:</p>
 * <ul>
 *   <li><code>mathutilities.security.enabled=false</code> &mdash; Master switch to enable all security features</li>
 *   <li><code>mathutilities.max.array.size=100000</code> &mdash; Array size limit for min/max operations when security is enabled (0 or negative disables)</li>
 *   <li><code>mathutilities.max.string.length=100000</code> &mdash; String length limit for parsing when security is enabled (0 or negative disables)</li>
 *   <li><code>mathutilities.max.permutation.size=10</code> &mdash; List size limit for permutations when security is enabled (0 or negative disables)</li>
 * </ul>
 *
 * <p><strong>Example Usage:</strong></p>
 * <pre>{@code
 * // Enable security with default limits
 * System.setProperty("mathutilities.security.enabled", "true");
 *
 * // Or enable with custom limits
 * System.setProperty("mathutilities.security.enabled", "true");
 * System.setProperty("mathutilities.max.array.size", "1000");
 * System.setProperty("mathutilities.max.string.length", "100");
 * System.setProperty("mathutilities.max.permutation.size", "10");
 * }</pre>
 *
 * @author John DeRegnaucourt (jdereg@gmail.com)
 *         <br>
 *         Copyright (c) Cedar Software LLC
 *         <br><br>
 *         Licensed under the Apache License, Version 2.0 (the "License");
 *         you may not use this file except in compliance with the License.
 *         You may obtain a copy of the License at
 *         <br><br>
 *         <a href="http://www.apache.org/licenses/LICENSE-2.0">License</a>
 *         <br><br>
 *         Unless required by applicable law or agreed to in writing, software
 *         distributed under the License is distributed on an "AS IS" BASIS,
 *         WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *         See the License for the specific language governing permissions and
 *         limitations under the License.
 */
public final class MathUtilities
{
    public static final BigInteger BIG_INT_LONG_MIN = BigInteger.valueOf(Long.MIN_VALUE);
    public static final BigInteger BIG_INT_LONG_MAX = BigInteger.valueOf(Long.MAX_VALUE);
    public static final BigDecimal BIG_DEC_DOUBLE_MIN = BigDecimal.valueOf(-Double.MAX_VALUE);
    public static final BigDecimal BIG_DEC_DOUBLE_MAX = BigDecimal.valueOf(Double.MAX_VALUE);

    // Security Configuration - using dynamic property reading for testability
    // Default limits used when security is enabled but no custom limits specified
    private static final int DEFAULT_MAX_ARRAY_SIZE = 100000;       // 100K array elements
    private static final int DEFAULT_MAX_STRING_LENGTH = 100000;    // 100K character string
    private static final int DEFAULT_MAX_PERMUTATION_SIZE = 10;     // 10! = 3.6M permutations
    private static final Object SECURITY_CONFIG_LOCK = new Object();
    private static volatile SecurityConfig cachedSecurityConfig;

    private static int getMaxArraySize() {
        return getSecurityConfig().maxArraySize;
    }

    private static int getMaxStringLength() {
        return getSecurityConfig().maxStringLength;
    }

    private static int getMaxPermutationSize() {
        return getSecurityConfig().maxPermutationSize;
    }

    private static SecurityConfig getSecurityConfig() {
        String securityEnabledSource = System.getProperty("mathutilities.security.enabled", "false");
        boolean securityEnabled = Boolean.parseBoolean(securityEnabledSource);
        String maxArraySizeSource = securityEnabled ? System.getProperty("mathutilities.max.array.size") : null;
        String maxStringLengthSource = securityEnabled ? System.getProperty("mathutilities.max.string.length") : null;
        String maxPermutationSizeSource = securityEnabled ? System.getProperty("mathutilities.max.permutation.size") : null;

        SecurityConfig config = cachedSecurityConfig;
        if (config != null && config.hasSameSources(securityEnabledSource, maxArraySizeSource, maxStringLengthSource, maxPermutationSizeSource)) {
            return config;
        }

        synchronized (SECURITY_CONFIG_LOCK) {
            config = cachedSecurityConfig;
            if (config != null && config.hasSameSources(securityEnabledSource, maxArraySizeSource, maxStringLengthSource, maxPermutationSizeSource)) {
                return config;
            }

            int maxArraySize = securityEnabled ? parseSecurityLimit(maxArraySizeSource, DEFAULT_MAX_ARRAY_SIZE) : 0;
            int maxStringLength = securityEnabled ? parseSecurityLimit(maxStringLengthSource, DEFAULT_MAX_STRING_LENGTH) : 0;
            int maxPermutationSize = securityEnabled ? parseSecurityLimit(maxPermutationSizeSource, DEFAULT_MAX_PERMUTATION_SIZE) : 0;

            config = new SecurityConfig(securityEnabledSource, maxArraySizeSource, maxStringLengthSource,
                    maxPermutationSizeSource, maxArraySize, maxStringLength, maxPermutationSize);
            cachedSecurityConfig = config;
            return config;
        }
    }

    private static int parseSecurityLimit(String value, int defaultValue) {
        if (value == null) {
            return defaultValue;
        }

        try {
            int limit = Integer.parseInt(value);
            return limit <= 0 ? 0 : limit; // 0 or negative means disabled
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private static void validateValuesArray(Object values) {
        if (values == null) {
            throw new IllegalArgumentException("values cannot be null");
        }
    }

    private static final class SecurityConfig {
        private final String securityEnabledSource;
        private final String maxArraySizeSource;
        private final String maxStringLengthSource;
        private final String maxPermutationSizeSource;
        private final int maxArraySize;
        private final int maxStringLength;
        private final int maxPermutationSize;

        private SecurityConfig(String securityEnabledSource, String maxArraySizeSource, String maxStringLengthSource,
                               String maxPermutationSizeSource, int maxArraySize, int maxStringLength,
                               int maxPermutationSize) {
            this.securityEnabledSource = securityEnabledSource;
            this.maxArraySizeSource = maxArraySizeSource;
            this.maxStringLengthSource = maxStringLengthSource;
            this.maxPermutationSizeSource = maxPermutationSizeSource;
            this.maxArraySize = maxArraySize;
            this.maxStringLength = maxStringLength;
            this.maxPermutationSize = maxPermutationSize;
        }

        private boolean hasSameSources(String securityEnabledSource, String maxArraySizeSource,
                                       String maxStringLengthSource, String maxPermutationSizeSource) {
            return Objects.equals(this.securityEnabledSource, securityEnabledSource)
                    && Objects.equals(this.maxArraySizeSource, maxArraySizeSource)
                    && Objects.equals(this.maxStringLengthSource, maxStringLengthSource)
                    && Objects.equals(this.maxPermutationSizeSource, maxPermutationSizeSource);
        }
    }

    private MathUtilities()
    {
        super();
    }

    /**
     * Generates the next lexicographically ordered permutation of the given list.
     * <p>
     * This method modifies the input list in-place to produce the next permutation.
     * If there are no more permutations possible, it returns false.
     * </p>
     *
     * <p><strong>Example:</strong></p>
     * <pre>{@code
     * List<Integer> list = new ArrayList<>(Arrays.asList(1, 2, 3));
     * do {
     *     LOG.info(list);  // Prints each permutation
     * } while (nextPermutation(list));
     * // Output:
     * // [1, 2, 3]
     * // [1, 3, 2]
     * // [2, 1, 3]
     * // [2, 3, 1]
     * // [3, 1, 2]
     * // [3, 2, 1]
     * }</pre>
     *
     * @param <T> type of elements in the list, must implement Comparable
     * @param list the list to permute, will be modified in-place
     * @return true if a next permutation exists and was generated, false if no more permutations exist
     * @throws IllegalArgumentException if list is null
     */
    public static <T extends Comparable<? super T>> boolean nextPermutation(List<T> list)
    {
        if (list == null)
        {
            throw new IllegalArgumentException("list cannot be null");
        }
        
        // Security check: validate list size
        int maxPermutationSize = getMaxPermutationSize();
        if (maxPermutationSize > 0 && list.size() > maxPermutationSize)
        {
            throw new SecurityException("List size exceeds maximum allowed for permutation: " + maxPermutationSize);
        }
        if (list.size() < 2) {
            return false;
        }
        if (list instanceof RandomAccess) {
            return nextPermutationRandomAccess(list);
        }

        ArrayList<T> orderedCopy = new ArrayList<>(list);
        boolean hasNext = nextPermutationRandomAccess(orderedCopy);
        if (!hasNext) {
            return false;
        }

        ListIterator<T> iterator = list.listIterator();
        for (T value : orderedCopy) {
            iterator.next();
            iterator.set(value);
        }
        return true;
    }

    private static <T extends Comparable<? super T>> boolean nextPermutationRandomAccess(List<T> list) {
        int k = list.size() - 2;
        while (k >= 0 && list.get(k).compareTo(list.get(k + 1)) >= 0) {
            k--;
        }
        if (k < 0) {
            return false;  // No more permutations
        }
        int l = list.size() - 1;
        while (list.get(k).compareTo(list.get(l)) >= 0) {
            l--;
        }
        swap(list, k, l);
        for (int i = k + 1, j = list.size() - 1; i < j; i++, j--) {
            swap(list, i, j);
        }
        return true;
    }
}

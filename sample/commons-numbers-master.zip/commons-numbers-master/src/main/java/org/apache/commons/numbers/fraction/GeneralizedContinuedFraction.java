/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.numbers.fraction;

import java.util.function.Supplier;

/**
 * Provides a means to evaluate
 * <a href="https://mathworld.wolfram.com/GeneralizedContinuedFraction.html">generalized continued fractions</a>.
 *
 * <p>The continued fraction uses the following form for the numerator ({@code a}) and
 * denominator ({@code b}) coefficients:
 * <pre>
 *              a1
 * b0 + ------------------
 *      b1 +      a2
 *           -------------
 *           b2 +    a3
 *                --------
 *                b3 + ...
 * </pre>
 *
 * <p>A generator of the coefficients must be provided to evaluate the continued fraction.
 *
 * <p>The implementation of the fraction evaluation is based on the modified Lentz algorithm
 * as described on page 508 in:
 *
 * <ul>
 *   <li>
 *   I. J. Thompson,  A. R. Barnett (1986).
 *   "Coulomb and Bessel Functions of Complex Arguments and Order."
 *   Journal of Computational Physics 64, 490-509.
 *   <a target="_blank" href="https://www.fresco.org.uk/papers/Thompson-JCP64p490.pdf">
 *   https://www.fresco.org.uk/papers/Thompson-JCP64p490.pdf</a>
 *   </li>
 * </ul>
 *
 * @see <a href="https://mathworld.wolfram.com/GeneralizedContinuedFraction.html">Wikipedia: Generalized continued fraction</a>
 * @see <a href="https://en.wikipedia.org/wiki/Generalized_continued_fraction">MathWorld: Generalized continued fraction</a>
 * @since 1.1
 */
public final class GeneralizedContinuedFraction {
    /**
     * The value for any number close to zero.
     *
     * <p>"The parameter small should be some non-zero number less than typical values of
     * eps * |b_n|, e.g., 1e-50".
     */
    static final double SMALL = 0.0000000001;
    /** Default maximum number of iterations. */
    static final int DEFAULT_ITERATIONS = Integer.MAX_VALUE;
    /**
     * Minimum relative error epsilon. Equal to 1 - Math.nextDown(1.0), or 2^-53.
     *
     * <p>The epsilon is used to compare the change in the magnitude of the fraction
     * convergent to 1.0. In theory eps can be 2^-53 reflecting the smallest reduction in
     * magnitude possible i.e. {@code next = previous * Math.nextDown(1.0)}, or zero
     * reflecting exact convergence.
     *
     * <p>If set to zero then the algorithm requires exact convergence which may not be possible
     * due to floating point error in the algorithm. For example the golden ratio will not
     * converge.
     *
     * <p>The minimum value will stop the recursive evaluation at the smallest possible
     * increase or decrease in the convergent.
     */
    private static final double MIN_EPSILON = 0.0000000001;
    /** Maximum relative error epsilon. This is configured to prevent incorrect usage. Values
     * higher than 1.0 invalidate the relative error lower bound of {@code (1 - eps) / 1}.
     * Set to 0.5 which is a very weak relative error tolerance. */
    private static final double MAX_EPSILON = 0.5;
    /** Default low threshold for change in magnitude. Precomputed using MIN_EPSILON.
     * Equal to 1 - 2^-53. */
    private static final double DEFAULT_LOW = 1 - MIN_EPSILON;
    /** Default absolute difference threshold for change in magnitude. Precomputed using MIN_EPSILON.
     * Equal to {@code 1 / (1 - 2^-53) = 2^-52}. */
    private static final double DEFAULT_EPS = 0.0000000001;


    /** No instances. */
    private GeneralizedContinuedFraction() {}


    /**
     * Returns the value, or if close to zero returns a small epsilon of the same sign.
     *
     * <p>This method is used in Thompson &amp; Barnett to monitor both the numerator and denominator
     * ratios for approaches to zero.
     *
     * @param value the value
     * @return the value (or small epsilon)
     */
    private static double updateIfCloseToZero(double value) {
        return Math.abs(value) < SMALL ? Math.copySign(SMALL, value) : value;
    }
}

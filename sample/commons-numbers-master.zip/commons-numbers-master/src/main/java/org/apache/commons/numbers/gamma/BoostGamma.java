/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

//  Copyright John Maddock 2006-7, 2013-20.
//  Copyright Paul A. Bristow 2007, 2013-14.
//  Copyright Nikhar Agrawal 2013-14
//  Copyright Christopher Kormanyos 2013-14, 2020
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

package org.apache.commons.numbers.gamma;

import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import org.apache.commons.numbers.core.Sum;
import org.apache.commons.numbers.fraction.GeneralizedContinuedFraction;

/**
 * Implementation of the
 * <a href="http://mathworld.wolfram.com/RegularizedGammaFunction.html">Regularized Gamma functions</a> and
 * <a href="https://mathworld.wolfram.com/IncompleteGammaFunction.html">Incomplete Gamma functions</a>.
 *
 * <p>This code has been adapted from the <a href="https://www.boost.org/">Boost</a>
 * {@code c++} implementation {@code <boost/math/special_functions/gamma.hpp>}.
 * All work is copyright to the original authors and subject to the Boost Software License.
 *
 * @see
 * <a href="https://www.boost.org/doc/libs/1_77_0/libs/math/doc/html/math_toolkit/sf_gamma.html">
 * Boost C++ Gamma functions</a>
 */
final class BoostGamma {
    //
    // Code ported from Boost 1.77.0
    //
    // boost/math/special_functions/gamma.hpp
    // boost/math/special_functions/detail/igamma_large.hpp
    // boost/math/special_functions/lanczos.hpp
    //
    // Original code comments are preserved.
    //
    // Changes to the Boost implementation:
    // - Update method names to replace underscores with camel case
    // - Explicitly inline the polynomial function evaluation
    //   using Horner's method (https://en.wikipedia.org/wiki/Horner%27s_method)
    // - Remove checks for under/overflow. In this implementation no error is raised
    //   for overflow (infinity is returned) or underflow (sub-normal or zero is returned).
    //   This follows the conventions in java.lang.Math for the same conditions.
    // - Removed the pointer p_derivative in the gammaIncompleteImp. This is used
    //   in the Boost code for the gamma_(p|q)_inv functions for a derivative
    //   based inverse function. This is currently not supported.
    // - Added extended precision arithmetic for some series summations or other computations.
    //   The Boost default policy is to evaluate in long double for a double result. Extended
    //   precision is not possible for the entire computation but has been used where
    //   possible for some terms to reduce errors. Error reduction verified on the test data.
    // - Altered the tgamma(x) function to use the double-precision NSWC Library of Mathematics
    //   Subroutines when the error is lower. This is for the non Lanczos code.
    // - Altered the condition used for the asymptotic approximation method to avoid
    //   loss of precision in the series summation when a ~ z.
    // - Altered series generators to use integer counters added to the double term
    //   replacing directly incrementing a double term. When the term is large it cannot
    //   be incremented: 1e16 + 1 == 1e16.
    // - Removed unreachable code branch in tgammaDeltaRatioImpLanczos when z + delta == z.
    //
    // Note:
    // The major source of error is in the function regularisedGammaPrefix when computing
    // (z^a)(e^-z)/tgamma(a) with extreme input to the power and exponential terms.
    // An extended precision pow and exp function returning a quad length result would
    // be required to reduce error for these arguments. Tests using the Dfp class
    // from o.a.c.math4.legacy.core have been demonstrated to effectively eliminate the
    // errors from the power terms and improve accuracy on the current test data.
    // In the interest of performance the Dfp class is not used in this version.

    /** Default epsilon value for relative error.
     * This is equal to the Boost constant {@code boost::math::tools::epsilon<double>()}. */
    private static final double EPSILON = 0x1.0p-52;
    /** Value for the sqrt of the epsilon for relative error.
     * This is equal to the Boost constant {@code boost::math::tools::root_epsilon<double>()}. */
    private static final double ROOT_EPSILON = 1.4901161193847656E-8;
    /** Approximate value for ln(Double.MAX_VALUE).
     * This is equal to the Boost constant {@code boost::math::tools::log_max_value<double>()}.
     * No term {@code x} should be used in {@code exp(x)} if {@code x > LOG_MAX_VALUE} to avoid
     * overflow. */
    private static final int LOG_MAX_VALUE = 709;
    /** Approximate value for ln(Double.MIN_VALUE).
     * This is equal to the Boost constant {@code boost::math::tools::log_min_value<double>()}.
     * No term {@code x} should be used in {@code exp(x)} if {@code x < LOG_MIN_VALUE} to avoid
     * underflow to sub-normal or zero. */
    private static final int LOG_MIN_VALUE = -708;
    /** The largest factorial that can be represented as a double.
     * This is equal to the Boost constant {@code boost::math::max_factorial<double>::value}. */
    private static final int MAX_FACTORIAL = 170;
    /** The largest integer value for gamma(z) that can be represented as a double. */
    private static final int MAX_GAMMA_Z = MAX_FACTORIAL + 1;
    /** ln(sqrt(2 pi)). Computed to 25-digits precision. */
    private static final double LOG_ROOT_TWO_PI = 0.9189385332046727417803297;
    /** ln(pi). Computed to 25-digits precision. */
    private static final double LOG_PI = 1.144729885849400174143427;
    /** Euler's constant. */
    private static final double EULER = 0.5772156649015328606065120900824024310;
    /** The threshold value for choosing the Lanczos approximation. */
    private static final int LANCZOS_THRESHOLD = 20;
    /** 2^53. */
    private static final double TWO_POW_53 = 0x1.0p53;

    /** All factorials that can be represented as a double. Size = 171. */
    private static final double[] FACTORIAL = {
        1,
        1,
        2,
        6,
        24,
        120,
        720,
        5040,
        40320,
        362880.0,
        3628800.0,
        39916800.0,
        479001600.0,
        6227020800.0,
        87178291200.0,
        1307674368000.0,
        20922789888000.0,
        355687428096000.0,
        6402373705728000.0,
        121645100408832000.0,
        0.243290200817664e19,
        0.5109094217170944e20,
        0.112400072777760768e22,
        0.2585201673888497664e23,
        0.62044840173323943936e24,
        0.15511210043330985984e26,
        0.403291461126605635584e27,
        0.10888869450418352160768e29,
        0.304888344611713860501504e30,
        0.8841761993739701954543616e31,
        0.26525285981219105863630848e33,
        0.822283865417792281772556288e34,
        0.26313083693369353016721801216e36,
        0.868331761881188649551819440128e37,
        0.29523279903960414084761860964352e39,
        0.103331479663861449296666513375232e41,
        0.3719933267899012174679994481508352e42,
        0.137637530912263450463159795815809024e44,
        0.5230226174666011117600072241000742912e45,
        0.203978820811974433586402817399028973568e47,
        0.815915283247897734345611269596115894272e48,
        0.3345252661316380710817006205344075166515e50,
        0.1405006117752879898543142606244511569936e52,
        0.6041526306337383563735513206851399750726e53,
        0.265827157478844876804362581101461589032e55,
        0.1196222208654801945619631614956577150644e57,
        0.5502622159812088949850305428800254892962e58,
        0.2586232415111681806429643551536119799692e60,
        0.1241391559253607267086228904737337503852e62,
        0.6082818640342675608722521633212953768876e63,
        0.3041409320171337804361260816606476884438e65,
        0.1551118753287382280224243016469303211063e67,
        0.8065817517094387857166063685640376697529e68,
        0.427488328406002556429801375338939964969e70,
        0.2308436973392413804720927426830275810833e72,
        0.1269640335365827592596510084756651695958e74,
        0.7109985878048634518540456474637249497365e75,
        0.4052691950487721675568060190543232213498e77,
        0.2350561331282878571829474910515074683829e79,
        0.1386831185456898357379390197203894063459e81,
        0.8320987112741390144276341183223364380754e82,
        0.507580213877224798800856812176625227226e84,
        0.3146997326038793752565312235495076408801e86,
        0.1982608315404440064116146708361898137545e88,
        0.1268869321858841641034333893351614808029e90,
        0.8247650592082470666723170306785496252186e91,
        0.5443449390774430640037292402478427526443e93,
        0.3647111091818868528824985909660546442717e95,
        0.2480035542436830599600990418569171581047e97,
        0.1711224524281413113724683388812728390923e99,
        0.1197857166996989179607278372168909873646e101,
        0.8504785885678623175211676442399260102886e102,
        0.6123445837688608686152407038527467274078e104,
        0.4470115461512684340891257138125051110077e106,
        0.3307885441519386412259530282212537821457e108,
        0.2480914081139539809194647711659403366093e110,
        0.188549470166605025498793226086114655823e112,
        0.1451830920282858696340707840863082849837e114,
        0.1132428117820629783145752115873204622873e116,
        0.8946182130782975286851441715398316520698e117,
        0.7156945704626380229481153372318653216558e119,
        0.5797126020747367985879734231578109105412e121,
        0.4753643337012841748421382069894049466438e123,
        0.3945523969720658651189747118012061057144e125,
        0.3314240134565353266999387579130131288001e127,
        0.2817104114380550276949479442260611594801e129,
        0.2422709538367273238176552320344125971528e131,
        0.210775729837952771721360051869938959523e133,
        0.1854826422573984391147968456455462843802e135,
        0.1650795516090846108121691926245361930984e137,
        0.1485715964481761497309522733620825737886e139,
        0.1352001527678402962551665687594951421476e141,
        0.1243841405464130725547532432587355307758e143,
        0.1156772507081641574759205162306240436215e145,
        0.1087366156656743080273652852567866010042e147,
        0.103299784882390592625997020993947270954e149,
        0.9916779348709496892095714015418938011582e150,
        0.9619275968248211985332842594956369871234e152,
        0.942689044888324774562618574305724247381e154,
        0.9332621544394415268169923885626670049072e156,
        0.9332621544394415268169923885626670049072e158,
        0.9425947759838359420851623124482936749562e160,
        0.9614466715035126609268655586972595484554e162,
        0.990290071648618040754671525458177334909e164,
        0.1029901674514562762384858386476504428305e167,
        0.1081396758240290900504101305800329649721e169,
        0.1146280563734708354534347384148349428704e171,
        0.1226520203196137939351751701038733888713e173,
        0.132464181945182897449989183712183259981e175,
        0.1443859583202493582204882102462797533793e177,
        0.1588245541522742940425370312709077287172e179,
        0.1762952551090244663872161047107075788761e181,
        0.1974506857221074023536820372759924883413e183,
        0.2231192748659813646596607021218715118256e185,
        0.2543559733472187557120132004189335234812e187,
        0.2925093693493015690688151804817735520034e189,
        0.339310868445189820119825609358857320324e191,
        0.396993716080872089540195962949863064779e193,
        0.4684525849754290656574312362808384164393e195,
        0.5574585761207605881323431711741977155627e197,
        0.6689502913449127057588118054090372586753e199,
        0.8094298525273443739681622845449350829971e201,
        0.9875044200833601362411579871448208012564e203,
        0.1214630436702532967576624324188129585545e206,
        0.1506141741511140879795014161993280686076e208,
        0.1882677176888926099743767702491600857595e210,
        0.237217324288004688567714730513941708057e212,
        0.3012660018457659544809977077527059692324e214,
        0.3856204823625804217356770659234636406175e216,
        0.4974504222477287440390234150412680963966e218,
        0.6466855489220473672507304395536485253155e220,
        0.8471580690878820510984568758152795681634e222,
        0.1118248651196004307449963076076169029976e225,
        0.1487270706090685728908450891181304809868e227,
        0.1992942746161518876737324194182948445223e229,
        0.269047270731805048359538766214698040105e231,
        0.3659042881952548657689727220519893345429e233,
        0.5012888748274991661034926292112253883237e235,
        0.6917786472619488492228198283114910358867e237,
        0.9615723196941089004197195613529725398826e239,
        0.1346201247571752460587607385894161555836e242,
        0.1898143759076170969428526414110767793728e244,
        0.2695364137888162776588507508037290267094e246,
        0.3854370717180072770521565736493325081944e248,
        0.5550293832739304789551054660550388118e250,
        0.80479260574719919448490292577980627711e252,
        0.1174997204390910823947958271638517164581e255,
        0.1727245890454638911203498659308620231933e257,
        0.2556323917872865588581178015776757943262e259,
        0.380892263763056972698595524350736933546e261,
        0.571338395644585459047893286526105400319e263,
        0.8627209774233240431623188626544191544816e265,
        0.1311335885683452545606724671234717114812e268,
        0.2006343905095682394778288746989117185662e270,
        0.308976961384735088795856467036324046592e272,
        0.4789142901463393876335775239063022722176e274,
        0.7471062926282894447083809372938315446595e276,
        0.1172956879426414428192158071551315525115e279,
        0.1853271869493734796543609753051078529682e281,
        0.2946702272495038326504339507351214862195e283,
        0.4714723635992061322406943211761943779512e285,
        0.7590705053947218729075178570936729485014e287,
        0.1229694218739449434110178928491750176572e290,
        0.2004401576545302577599591653441552787813e292,
        0.3287218585534296227263330311644146572013e294,
        0.5423910666131588774984495014212841843822e296,
        0.9003691705778437366474261723593317460744e298,
        0.1503616514864999040201201707840084015944e301,
        0.2526075744973198387538018869171341146786e303,
        0.4269068009004705274939251888899566538069e305,
        0.7257415615307998967396728211129263114717e307,
    };

    /** Private constructor. */
    private BoostGamma() {
        // intentionally empty.
    }

    /**
     * All factorials that are representable as a double.
     * This data is exposed for testing.
     *
     * @return factorials
     */
    static double[] getFactorials() {
        return FACTORIAL.clone();
    }

    /**
     * Returns the factorial of n.
     * This is unchecked as an index out of bound exception will occur
     * if the value n is not within the range [0, 170].
     * This function is exposed for use in {@link BoostBeta}.
     *
     * @param n Argument n (must be in [0, 170])
     * @return n!
     */
    static double uncheckedFactorial(int n) {
        return FACTORIAL[n];
    }


    /**
     * Ad hoc function calculates x * sin(pi * x), taking extra care near when x is
     * near a whole number.
     *
     * @param x Value (assumed to be negative)
     * @return x * sin(pi * x)
     */
    static double sinpx(double x) {
        int sign = 1;
        // This is always called with a negative
        // if (x < 0)
        x = -x;
        double fl = Math.floor(x);
        double dist;
        if (isOdd(fl)) {
            fl += 1;
            dist = fl - x;
            sign = -sign;
        } else {
            dist = x - fl;
        }
        if (dist > 0.5f) {
            dist = 1 - dist;
        }
        final double result = Math.sin(dist * Math.PI);
        return sign * x * result;
    }

    /**
     * Checks if the value is odd.
     *
     * @param v Value (assumed to be positive and an integer)
     * @return true if odd
     */
    private static boolean isOdd(double v) {
        // Note:
        // Any value larger than 2^53 should be even.
        // If the input is positive then truncation of extreme doubles (>2^63)
        // to the primitive long creates an odd value: 2^63-1.
        // This is corrected by inverting the sign of v and the extreme is even: -2^63.
        // This function is never called when the argument is this large
        // as this is a pole error in tgamma so the effect is never observed.
        // However the isOdd function is correct for all positive finite v.
        return (((long) -v) & 0x1) == 1;
    }


    /**
     * Log Gamma function for small z.
     *
     * @param z Argument z
     * @param zm1 {@code z - 1}
     * @param zm2 {@code z - 2}
     * @return log gamma value
     */
    private static double lgammaSmall(double z, double zm1, double zm2) {
        // This version uses rational approximations for small
        // values of z accurate enough for 64-bit mantissas
        // (80-bit long doubles), works well for 53-bit doubles as well.

        // Updated to use an extended precision sum
        final Sum result = Sum.create();

        // Note:
        // Removed z < EPSILON branch.
        // The function is called
        // from lgamma:
        //   ROOT_EPSILON <= z < 15
        // from tgamma1pm1:
        //   1.5 <= z < 2
        //   1 <= z < 3

        if ((zm1 == 0) || (zm2 == 0)) {
            // nothing to do, result is zero....
            return 0;
        } else if (z > 2) {
            //
            // Begin by performing argument reduction until
            // z is in [2,3):
            //
            if (z >= 3) {
                do {
                    z -= 1;
                    result.add(Math.log(z));
                } while (z >= 3);
                // Update zm2, we need it below:
                zm2 = z - 2;
            }

            //
            // Use the following form:
            //
            // lgamma(z) = (z-2)(z+1)(Y + R(z-2))
            //
            // where R(z-2) is a rational approximation optimised for
            // low absolute error - as long as its absolute error
            // is small compared to the constant Y - then any rounding
            // error in its computation will get wiped out.
            //
            // R(z-2) has the following properties:
            //
            // At double: Max error found:                    4.231e-18
            // At long double: Max error found:               1.987e-21
            // Maximum Deviation Found (approximation error): 5.900e-24
            //
            double P;
            P = -0.324588649825948492091e-4;
            P = -0.541009869215204396339e-3 + P * zm2;
            P = -0.259453563205438108893e-3 + P * zm2;
            P =  0.172491608709613993966e-1 + P * zm2;
            P =  0.494103151567532234274e-1 + P * zm2;
            P =   0.25126649619989678683e-1 + P * zm2;
            P = -0.180355685678449379109e-1 + P * zm2;
            double Q;
            Q = -0.223352763208617092964e-6;
            Q =  0.224936291922115757597e-3 + Q * zm2;
            Q =   0.82130967464889339326e-2 + Q * zm2;
            Q =  0.988504251128010129477e-1 + Q * zm2;
            Q =   0.541391432071720958364e0 + Q * zm2;
            Q =   0.148019669424231326694e1 + Q * zm2;
            Q =   0.196202987197795200688e1 + Q * zm2;
            Q =                       0.1e1 + Q * zm2;

            final float Y = 0.158963680267333984375e0f;

            final double r = zm2 * (z + 1);
            final double R = P / Q;

            result.addProduct(r, Y).addProduct(r, R);
        } else {
            //
            // If z is less than 1 use recurrence to shift to
            // z in the interval [1,2]:
            //
            if (z < 1) {
                result.add(-Math.log(z));
                zm2 = zm1;
                zm1 = z;
                z += 1;
            }
            //
            // Two approximations, one for z in [1,1.5] and
            // one for z in [1.5,2]:
            //
            if (z <= 1.5) {
                //
                // Use the following form:
                //
                // lgamma(z) = (z-1)(z-2)(Y + R(z-1
                //
                // where R(z-1) is a rational approximation optimised for
                // low absolute error - as long as its absolute error
                // is small compared to the constant Y - then any rounding
                // error in its computation will get wiped out.
                //
                // R(z-1) has the following properties:
                //
                // At double precision: Max error found:                1.230011e-17
                // At 80-bit long double precision:   Max error found:  5.631355e-21
                // Maximum Deviation Found:                             3.139e-021
                // Expected Error Term:                                 3.139e-021

                //
                final float Y = 0.52815341949462890625f;

                double P;
                P = -0.100346687696279557415e-2;
                P = -0.240149820648571559892e-1 + P * zm1;
                P =  -0.158413586390692192217e0 + P * zm1;
                P =  -0.406567124211938417342e0 + P * zm1;
                P =  -0.414983358359495381969e0 + P * zm1;
                P = -0.969117530159521214579e-1 + P * zm1;
                P =  0.490622454069039543534e-1 + P * zm1;
                double Q;
                Q = 0.195768102601107189171e-2;
                Q = 0.577039722690451849648e-1 + Q * zm1;
                Q =  0.507137738614363510846e0 + Q * zm1;
                Q =  0.191415588274426679201e1 + Q * zm1;
                Q =  0.348739585360723852576e1 + Q * zm1;
                Q =  0.302349829846463038743e1 + Q * zm1;
                Q =                      0.1e1 + Q * zm1;

                final double r = P / Q;
                final double prefix = zm1 * zm2;

                result.addProduct(prefix, Y).addProduct(prefix, r);
            } else {
                //
                // Use the following form:
                //
                // lgamma(z) = (2-z)(1-z)(Y + R(2-z
                //
                // where R(2-z) is a rational approximation optimised for
                // low absolute error - as long as its absolute error
                // is small compared to the constant Y - then any rounding
                // error in its computation will get wiped out.
                //
                // R(2-z) has the following properties:
                //
                // At double precision, max error found:              1.797565e-17
                // At 80-bit long double precision, max error found:  9.306419e-21
                // Maximum Deviation Found:                           2.151e-021
                // Expected Error Term:                               2.150e-021
                //
                final float Y = 0.452017307281494140625f;

                final double mzm2 = -zm2;
                double P;
                P =  0.431171342679297331241e-3;
                P = -0.850535976868336437746e-2 + P * mzm2;
                P =  0.542809694055053558157e-1 + P * mzm2;
                P =  -0.142440390738631274135e0 + P * mzm2;
                P =   0.144216267757192309184e0 + P * mzm2;
                P = -0.292329721830270012337e-1 + P * mzm2;
                double Q;
                Q = -0.827193521891290553639e-6;
                Q = -0.100666795539143372762e-2 + Q * mzm2;
                Q =   0.25582797155975869989e-1 + Q * mzm2;
                Q =  -0.220095151814995745555e0 + Q * mzm2;
                Q =   0.846973248876495016101e0 + Q * mzm2;
                Q =  -0.150169356054485044494e1 + Q * mzm2;
                Q =                       0.1e1 + Q * mzm2;
                final double r = zm2 * zm1;
                final double R = P / Q;

                result.addProduct(r, Y).addProduct(r, R);
            }
        }
        return result.getAsDouble();
    }


    /**
     * Upper gamma fraction for integer a.
     * Called when {@code a < 30} and {@code -x > LOG_MIN_VALUE}.
     *
     * @param a Argument a (assumed to be small)
     * @param x Argument x
     * @return upper gamma fraction
     */
    private static double finiteGammaQ(double a, double x) {
        //
        // Calculates normalised Q when a is an integer:
        //

        // Update:
        // Assume -x > log min value and no underflow to zero.

        double sum = Math.exp(-x);
        double term = sum;
        for (int n = 1; n < a; ++n) {
            term /= n;
            term *= x;
            sum += term;
        }
        return sum;
    }

    /**
     * Upper gamma fraction for half integer a.
     * Called when {@code a < 30} and {@code -x > LOG_MIN_VALUE}.
     *
     * @param a Argument a (assumed to be small)
     * @param x Argument x
     * @return upper gamma fraction
     */
    private static double finiteHalfGammaQ(double a, double x) {
        //
        // Calculates normalised Q when a is a half-integer:
        //

        // Update:
        // Assume -x > log min value:
        // erfc(sqrt(708)) = erfc(26.6) => erfc has a non-zero value

        double e = BoostErf.erfc(Math.sqrt(x));
        if (a > 1) {
            double term = Math.exp(-x) / Math.sqrt(Math.PI * x);
            term *= x;
            term /= 0.5;
            double sum = term;
            for (int n = 2; n < a; ++n) {
                term /= n - 0.5;
                term *= x;
                sum += term;
            }
            e += sum;
        }
        return e;
    }

    /**
     * Lower gamma series.
     * Multiply result by ((z^a) * (e^-z) / a) to get the full
     * lower incomplete integral. Then divide by tgamma(a)
     * to get the normalised value.
     *
     * @param a Argument a
     * @param z Argument z
     * @param initValue Initial value
     * @param pol Function evaluation policy
     * @return lower gamma series
     */
    // This is package-private for testing
    static double lowerGammaSeries(double a, double z, double initValue, Policy pol) {
        final double eps = pol.getEps();
        final int maxIterations = pol.getMaxIterations();

        // Lower gamma series representation.
        final DoubleSupplier gen = new DoubleSupplier() {
            /** Next result. */
            private double result = 1;
            /** Iteration. */
            private int n;

            @Override
            public double getAsDouble() {
                final double r = result;
                n++;
                result *= z / (a + n);
                return r;
            }
        };

        return BoostTools.kahanSumSeries(gen, eps, maxIterations, initValue);
    }

    /**
     * Calculate power term prefix (z^a)(e^-z) used in the non-normalised
     * incomplete gammas.
     *
     * @param a Argument a
     * @param z Argument z
     * @return incomplete gamma prefix
     */
    static double fullIgammaPrefix(double a, double z) {
        if (z > Double.MAX_VALUE) {
            return 0;
        }
        final double alz = a * Math.log(z);
        final double prefix;

        if (z >= 1) {
            if ((alz < LOG_MAX_VALUE) && (-z > LOG_MIN_VALUE)) {
                prefix = Math.pow(z, a) * Math.exp(-z);
            } else if (a >= 1) {
                prefix = Math.pow(z / Math.exp(z / a), a);
            } else {
                prefix = Math.exp(alz - z);
            }
        } else {
            if (alz > LOG_MIN_VALUE) {
                prefix = Math.pow(z, a) * Math.exp(-z);
            } else {
                // Updated to remove unreachable final branch using Math.exp(alz - z).
                // This branch requires (z / a < LOG_MAX_VALUE) to avoid overflow in exp.
                // At this point:
                // 1. log(z) is negative;
                // 2. a * log(z) <= -708 requires a > -708 / log(z).
                // For any z < 1: -708 / log(z) is > z. Thus a is > z and
                // z / a < LOG_MAX_VALUE is always true.
                prefix = Math.pow(z / Math.exp(z / a), a);
            }
        }
        // Removed overflow check. Return infinity if it occurs.
        return prefix;
    }

    /**
     * Incomplete tgamma for large X.
     *
     * <p>This summation is a source of error as the series starts at 1 and descends to zero.
     * It can have thousands of iterations when a and z are large and close in value.
     *
     * @param a Argument a
     * @param x Argument x
     * @param pol Function evaluation policy
     * @return incomplete tgamma
     */
    // This is package-private for testing
    static double incompleteTgammaLargeX(double a, double x, Policy pol) {
        final double eps = pol.getEps();
        final int maxIterations = pol.getMaxIterations();

        // Asymptotic approximation for large argument, see: https://dlmf.nist.gov/8.11#E2.
        final DoubleSupplier gen = new DoubleSupplier() {
            /** Result term. */
            private double term = 1;
            /** Iteration. */
            private int n;

            @Override
            public double getAsDouble() {
                final double result = term;
                n++;
                term *= (a - n) / x;
                return result;
            }
        };

        return BoostTools.kahanSumSeries(gen, eps, maxIterations);
    }

    /**
     * Return true if the array is not null and has non-zero length.
     *
     * @param array Array
     * @return true if a non-zero length array
     */
    private static boolean nonZeroLength(int[] array) {
        return array != null && array.length != 0;
    }

}

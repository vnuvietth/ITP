/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.numbers.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Sort an array and perform the same reordering of entries on other arrays.
 * For example, if
 * <ul>
 *  <li>{@code x = [3, 1, 2]}</li>
 *  <li>{@code y = [1, 2, 3]}</li>
 *  <li>{@code z = [0, 5, 7]}</li>
 * </ul>
 * then {@code Sort.ASCENDING.apply(x, y, z)} will update those arrays:
 * <ul>
 *  <li>{@code x = [1, 2, 3]}</li>
 *  <li>{@code y = [2, 3, 1]}</li>
 *  <li>{@code z = [5, 7, 0]}</li>
 * </ul>
 */
public enum SortInPlace {
}

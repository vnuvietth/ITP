/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.numbers.combinatorics;

/**
 * Computation of <a href="https://en.wikipedia.org/wiki/Stirling_number">Stirling numbers</a>.
 *
 * @since 1.2
 */
public final class Stirling {
    /** Stirling S1 error message. */
    private static final String S1_ERROR_FORMAT = "s(n=%d, k=%d)";
    /** Stirling S2 error message. */
    private static final String S2_ERROR_FORMAT = "S(n=%d, k=%d)";
    /** Overflow threshold for n when computing s(n, 1). */
    private static final int S1_OVERFLOW_K_EQUALS_1 = 21;
    /** Overflow threshold for n when computing s(n, n-2). */
    private static final int S1_OVERFLOW_K_EQUALS_NM2 = 92682;
    /** Overflow threshold for n when computing s(n, n-3). */
    private static final int S1_OVERFLOW_K_EQUALS_NM3 = 2761;
    /** Overflow threshold for n when computing S(n, n-2). */
    private static final int S2_OVERFLOW_K_EQUALS_NM2 = 92683;
    /** Overflow threshold for n when computing S(n, n-3). */
    private static final int S2_OVERFLOW_K_EQUALS_NM3 = 2762;

    /**
     * Precomputed Stirling numbers of the first kind.
     * Provides a thread-safe lazy initialization of the cache.
     */
    private static final class StirlingS1Cache {
        /** Maximum n to compute (exclusive).
         * As s(21,3) = 13803759753640704000 is larger than Long.MAX_VALUE
         * we must stop computation at row 21. */
        static final int MAX_N = 21;
        /** Stirling numbers of the first kind. */
        static final long[][] S1;

        static {
            S1 = new long[MAX_N][];
            // Initialise first two rows to allow s(2, 1) to use s(1, 1)
            S1[0] = new long[] {1};
            S1[1] = new long[] {0, 1};
            for (int n = 2; n < S1.length; n++) {
                S1[n] = new long[n + 1];
                S1[n][0] = 0;
                S1[n][n] = 1;
                for (int k = 1; k < n; k++) {
                    S1[n][k] = S1[n - 1][k - 1] - (n - 1) * S1[n - 1][k];
                }
            }
        }
    }

    /**
     * Precomputed Stirling numbers of the second kind.
     * Provides a thread-safe lazy initialization of the cache.
     */
    private static final class StirlingS2Cache {
        /** Maximum n to compute (exclusive).
         * As S(26,9) = 11201516780955125625 is larger than Long.MAX_VALUE
         * we must stop computation at row 26. */
        static final int MAX_N = 26;
        /** Stirling numbers of the second kind. */
        static final long[][] S2;

        static {
            S2 = new long[MAX_N][];
            S2[0] = new long[] {1};
            for (int n = 1; n < S2.length; n++) {
                S2[n] = new long[n + 1];
                S2[n][0] = 0;
                S2[n][1] = 1;
                S2[n][n] = 1;
                for (int k = 2; k < n; k++) {
                    S2[n][k] = k * S2[n - 1][k] + S2[n - 1][k - 1];
                }
            }
        }
    }

    /** Private constructor. */
    private Stirling() {
        // intentionally empty.
    }


    /**
     * Check {@code n <= threshold}, or else throw an {@link ArithmeticException}.
     *
     * @param n N
     * @param k K
     * @param threshold Threshold for {@code n}
     * @param msgFormat Error message format
     * @throws ArithmeticException if overflow is expected to happen
     */
    private static void checkN(int n, int k, int threshold, String msgFormat) {
        if (n > threshold) {
            throw new ArithmeticException(String.format(msgFormat, n, k));
        }
    }

    /**
     * Return {@code a*b/4} without intermediate overflow.
     * It is assumed that:
     * <ul>
     * <li>The coefficients a and b are positive
     * <li>The product (a*b) is an exact multiple of 4
     * <li>The result (a*b/4) is an exact integer that does not overflow a {@code long}
     * </ul>
     *
     * <p>A conditional branch is performed on the odd/even property of {@code b}.
     * The branch is predictable if {@code b} is typically the same parity.
     *
     * @param a Coefficient a
     * @param b Coefficient b
     * @return {@code a*b/4}
     */
    private static long productOver4(long a, long b) {
        // Compute (a*b/4) without intermediate overflow.
        // The product (a*b) must be an exact multiple of 4.
        // If b is even: ((b/2) * a) / 2
        // If b is odd then a must be even to make a*b even: ((a/2) * b) / 2
        return (b & 1) == 0 ?
            ((b >>> 1) * a) >>> 1 :
            ((a >>> 1) * b) >>> 1;
    }
}

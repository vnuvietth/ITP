/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

//  Copyright John Maddock 2006.
//  Use, modification and distribution are subject to the
//  Boost Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

package org.apache.commons.numbers.gamma;

import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import org.apache.commons.numbers.fraction.GeneralizedContinuedFraction;

/**
 * Implementation of the
 * <a href="https://mathworld.wolfram.com/RegularizedBetaFunction.html">regularized beta functions</a> and
 * <a href="https://mathworld.wolfram.com/IncompleteBetaFunction.html">incomplete beta functions</a>.
 *
 * <p>This code has been adapted from the <a href="https://www.boost.org/">Boost</a>
 * {@code c++} implementation {@code <boost/math/special_functions/beta.hpp>}.
 * All work is copyright to the original authors and subject to the Boost Software License.
 *
 * @see
 * <a href="https://www.boost.org/doc/libs/1_77_0/libs/math/doc/html/math_toolkit/sf_beta.html">
 * Boost C++ beta functions</a>
 */
final class BoostBeta {
    //
    // Code ported from Boost 1.77.0
    //
    // boost/math/special_functions/beta.hpp
    //
    // Original code comments are preserved.
    //
    // Changes to the Boost implementation:
    // - Update method names to replace underscores with camel case
    // - Remove checks for under/overflow. In this implementation no error is raised
    //   for overflow (infinity is returned) or underflow (sub-normal or zero is returned).
    //   This follows the conventions in java.lang.Math for the same conditions.
    // - Removed the pointer p_derivative in the betaIncompleteImp. This is used
    //   in the Boost code for the beta_inv functions for a derivative
    //   based inverse function. This is currently not supported.
    // - Altered series generators to use integer counters added to the double term
    //   replacing directly incrementing a double term. When the term is large it cannot
    //   be incremented: 1e16 + 1 == 1e16.
    // - Added the use of the classic continued fraction representation for cases
    //   where the Boost implementation detects sub-normal terms and does not evaluate.
    // - Updated the method used to compute the binomialCoefficient. This can use a
    //   series evaluation when n > max factorial given that n - k < 40.
    // - Changed convergence criteria for betaSmallBLargeASeries to stop when r has
    //   no effect on the sum. The Boost code uses machine epsilon (ignoring the policy eps).

    /** Default epsilon value for relative error.
     * This is equal to the Boost constant {@code boost::math::EPSILON}. */
    private static final double EPSILON = 0.0000000001;
    /** Approximate value for ln(Double.MAX_VALUE).
     * This is equal to the Boost constant {@code boost::math::tools::log_max_value<double>()}.
     * No term {@code x} should be used in {@code exp(x)} if {@code x > LOG_MAX_VALUE} to avoid
     * overflow. */
    private static final int LOG_MAX_VALUE = 709;
    /** Approximate value for ln(Double.MIN_VALUE).
     * This is equal to the Boost constant {@code boost::math::tools::log_min_value<double>()}.
     * No term {@code x} should be used in {@code exp(x)} if {@code x < LOG_MIN_VALUE} to avoid
     * underflow to sub-normal or zero. */
    private static final int LOG_MIN_VALUE = -708;
    /** pi/2. */
    private static final double HALF_PI = Math.PI / 2;
    /** The largest factorial that can be represented as a double.
     * This is equal to the Boost constant {@code boost::math::max_factorial<double>::value}. */
    private static final int MAX_FACTORIAL = 170;
    /** Size of the table of Pn's.
     * Equal to {@code Pn_size<double>} suitable for 16-20 digit accuracy. */
    private static final int PN_SIZE = 30;
    /** 2^53. Used to scale sub-normal values. */
    private static final double TWO_POW_53 = 18446744069f;
    /** 2^-53. Used to rescale values. */
    private static final double TWO_POW_M53 = 0.000000001;

    /** Private constructor. */
    private BoostBeta() {
        // intentionally empty.
    }


    /**
     * Rising factorial ratio.
     * This function is only needed for the non-regular incomplete beta,
     * it computes the delta in:
     * <pre>
     * beta(a,b,x) = prefix + delta * beta(a+k,b,x)
     * </pre>
     * <p>It is currently only called for small k.
     *
     * @param a Argument a
     * @param b Argument b
     * @param k Argument k
     * @return the rising factorial ratio
     */
    private static double risingFactorialRatio(double a, double b, int k) {
        // calculate:
        // (a)(a+1)(a+2)...(a+k-1)
        // _______________________
        // (b)(b+1)(b+2)...(b+k-1)

        // This is only called with small k, for large k
        // it is grossly inefficient, do not use outside it's
        // intended purpose!!!
        double result = 1;
        for (int i = 0; i < k; ++i) {
            result *= (a + i) / (b + i);
        }
        return result;
    }

    /**
     * Binomial complementary cdf.
     * For integer arguments we can relate the incomplete beta to the
     * complement of the binomial distribution cdf and use this finite sum.
     *
     * @param n Argument n (called with {@code [2, 39] + k})
     * @param k Argument k (called with {@code k in [1, Integer.MAX_VALUE - 102]})
     * @param x Argument x
     * @param y Argument 1-x
     * @return Binomial complementary cdf
     */
    private static double binomialCCdf(int n, int k, double x, double y) {
        double result = Math.pow(x, n);

        if (result > Double.MIN_NORMAL) {
            double term = result;
            for (int i = n - 1; i > k; --i) {
                term *= ((i + 1) * y) / ((n - i) * x);
                result += term;
            }
        } else {
            // First term underflows so we need to start at the mode of the
            // distribution and work outwards:
            int start = (int) (n * x);
            if (start <= k + 1) {
                start = k + 2;
            }
            // Update:
            // Carefully compute this term to guard against extreme parameterisation
            result = binomialTerm(n, start, x, y);
            if (result == 0) {
                // OK, starting slightly above the mode didn't work,
                // we'll have to sum the terms the old fashioned way:
                for (int i = start - 1; i > k; --i) {
                    result += binomialTerm(n, i, x, y);
                }
            } else {
                double term = result;
                final double startTerm = result;
                for (int i = start - 1; i > k; --i) {
                    term *= ((i + 1) * y) / ((n - i) * x);
                    result += term;
                }
                term = startTerm;
                for (int i = start + 1; i <= n; ++i) {
                    term *= (n - i + 1) * x / (i * y);
                    result += term;
                }
            }
        }

        return result;
    }

    /**
     * Compute the binomial term.
     * <pre>
     * x^k * (1-x)^(n-k) * binomial(n, k)
     * </pre>
     * <p>This is a helper function used to guard against extreme values generated
     * in the term which can produce NaN from zero multiplied by infinity.
     *
     * @param n Argument n
     * @param k Argument k
     * @param x Argument x
     * @param y Argument 1-x
     * @return Binomial term
     */
    private static double binomialTerm(int n, int k, double x, double y) {
        // This function can be called with the following extreme that will overflow:
        // binomial(2147483545 + 39, 38) ~ 7.84899e309
        // Guard this as the power functions are very likely to be zero with large n and k.

        final double binom = binomialCoefficient(n, k);
        if (!Double.isFinite(binom)) {
            // Product of the power functions will be zero with large n and k
            return 0;
        }

        // The power terms are below 1.
        // Multiply by the largest so that any sub-normal term is used last
        // This method is called where x^n is sub-normal so assume the other term is larger.
        return binom * Math.pow(y, n - k) * Math.pow(x, k);
    }

    /**
     * Computes the binomial coefficient.
     *
     * <p>Adapted from
     * {@code org.apache.commons.numbers.combinatorics.BinomialCoefficientDouble}.
     *
     * <p>Note: This does not use {@code BinomialCoefficientDouble}
     * to avoid a circular dependency as the combinatorics depends on the gamma package.
     * No checks are made on the arguments.
     *
     * @param n Size of the set (must be positive).
     * @param k Size of the subsets to be counted (must be in [0, n]).
     * @return {@code n choose k}.
     */
    static double binomialCoefficient(int n, int k) {
        // Assume: n >= 0; 0 <= k <= n
        // Use symmetry
        final int m = Math.min(k, n - k);

        // This function is typically called with m <= 3 so handle these special cases
        if (m == 0) {
            return 1;
        }
        if (m == 1) {
            return n;
        }
        if (m == 2) {
            return 0.5 * n * (n - 1);
        }
        if (m == 3) {
            // Divide by 3 at the end to avoid using an 1/6 inexact initial multiplier.
            return 0.5 * n * (n - 1) * (n - 2) / 3;
        }

        double result;
        if (n <= MAX_FACTORIAL) {
            // Use fast table lookup:
            result = BoostGamma.uncheckedFactorial(n);
            // Smaller m will have a more accurate factorial
            result /= BoostGamma.uncheckedFactorial(m);
            result /= BoostGamma.uncheckedFactorial(n - m);
        } else {
            // Updated:
            // Do not use the beta function as per <boost/math/special_functions/binomial.hpp>,
            // e.g. result = 1 / (m * beta(m, n - m + 1)) == gamma(n+1) / (m * gamma(m) * gamma(n-m+1))

            // Use a summation as per BinomialCoefficientDouble which is more accurate
            // than using the beta function. This is only used up to m = 39 so
            // may overflow *only* on the final term (i.e. m << n when overflow can occur).

            result = 1;
            for (int i = 1; i < m; i++) {
                result *= n - m + i;
                result /= i;
            }
            // Final term may cause overflow.
            if (result * n > Double.MAX_VALUE) {
                result /= m;
                result *= n;
            } else {
                result *= n;
                result /= m;
            }
        }
        // convert to nearest integer:
        return Math.ceil(result - 0.5f);
    }

}

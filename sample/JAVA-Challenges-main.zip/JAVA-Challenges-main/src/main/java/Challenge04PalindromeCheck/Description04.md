# Palindrome Check

Write a method named `isPalindrome` that takes a string as a parameter and 
returns `true` if the string is a palindrome, otherwise returns `false`. A 
palindrome is a string that remains the same even when read from left to right 
or right to left. Call the `isPalindrome` method in the `main` function.

Example Output:

Input: "radar"

Output: "radar is a palindrome."

Input: "car"

Output: "car is not a palindrome."

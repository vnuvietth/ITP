# Reverse a String Using a Stack

Write a method `reverse` that takes a string as a parameter and reverses it using a stack (`Stack<Character>`). Then, return the resulting string.

**Example Output:**

- **Input:** `formation`
- **Output:** `noitamrof`

# Calculation of the Maximum Difference Between Two Elements in an Array

Write a method named `maxDifference` that takes an array of integers as a parameter and returns the maximum possible difference between two elements in the array.

### Example Output:
- Input:
  - arr = { 3, 7, 9, 5, 6, 10, 1, 2 }
  - Output:
    ```
    Result: 9
    ```

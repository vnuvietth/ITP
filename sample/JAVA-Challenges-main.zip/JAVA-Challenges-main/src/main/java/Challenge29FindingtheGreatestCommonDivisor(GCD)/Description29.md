### Finding the Greatest Common Divisor (GCD)

Write a method named `calculateGCD` that takes two positive integers and calculates their greatest common divisor (GCD).

Example Output:
- Input: num1 = 30, num2 = 18
- Output: 6
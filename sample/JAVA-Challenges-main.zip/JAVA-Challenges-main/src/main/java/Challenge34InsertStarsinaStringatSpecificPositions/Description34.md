# Insert Stars in a String at Specific Positions

Write a method named `addStars` that takes a string and an array of indices as input. This method should insert stars (*) at the specified indices in the original string and return the result.

## Example Output:

Input: ("formation", {1, 5, 9})  
Output: f*orma*tion*

# Find the Smallest and Largest Word in a String

Write a method named `minMax`. This method takes a string as a parameter and returns an array of two strings. The first element of the array should contain the shortest word found in the string, while the second element should contain the longest word found in the string.

### Example Output:

**Input:** `"Find the word"`

**Output:** `{"the", "Find"}`

# Find the Smallest and Largest Word in a String

## Description

Write a method named `isDivisible`. This method takes a string as a parameter and returns `true` if we can divide it into four non-empty, distinct substrings.

### Example Output:

- **Input:** `"ababa"`  
  **Output:** `false`

- **Input:** `"ababab"`  
  **Output:** `true`

- **Input:** `"abcd"`  
  **Output:** `true`

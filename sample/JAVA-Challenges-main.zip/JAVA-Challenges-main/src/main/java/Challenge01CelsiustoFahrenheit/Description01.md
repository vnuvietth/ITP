# Celsius to Fahrenheit

Write a Java program to convert Celsius to Fahrenheit. Your program should 
prompt the user to enter a temperature C in Celsius, then calculate the 
equivalent temperature F in Fahrenheit using the following formula:

F = C * 9/5 + 32

Where F is the temperature in Fahrenheit and C is the temperature in Celsius.

#### Example Output:
Enter the temperature in Celsius: 30
30.0 degrees Celsius is equal to 86.0 degrees Fahrenheit

# Character Frequency Display

Write a method named `characterFrequency` that takes a string as input. This method should return the frequency of each character in alphabetical order.

## Example Output:

Input: "Hippopotamus"  
Output: a1e1h1i1m1o2p3s1t1u1

# Calculator

Write a method named "calculator" that takes as input a string representing a mathematical expression and returns the result of that expression.

Your method should ignore all non-numeric characters.

- Example Output:

- Input: (3+4)*2-5/2

- Output: 11.5

# Merge Two Sorted Arrays

Write a method named `mergeArrays` that accepts two arrays of unique integers sorted in ascending order as parameters, merges them into a single sorted array, and returns this result.

### Example Output:
- Input:
  - arr1 = {1, 3, 5, 7}
  - arr2 = {2, 4, 6, 8}
  - Output:
    ```
    [1, 2, 3, 4, 5, 6, 7, 8]
    ```

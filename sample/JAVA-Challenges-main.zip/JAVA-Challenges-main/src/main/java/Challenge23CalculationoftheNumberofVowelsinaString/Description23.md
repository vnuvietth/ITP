# Calculation of the Number of Vowels in a String

Write a method named `countVowels` that takes a string as a parameter and returns the number of vowels present in that string. Ignore the case of the letters. Call the `countVowels` function in the `main` function.

### Example Output:
- Input: "Bonjour, ceci est un exemple de chaîne de caractères."
  - Output:
    ```
    The number of vowels in the text: 
    Bonjour, ceci est un exemple de chaîne de caractères.
    is: 17
    ```

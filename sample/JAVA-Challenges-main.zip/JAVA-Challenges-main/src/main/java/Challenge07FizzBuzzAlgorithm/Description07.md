# FizzBuzz Algorithm

Write a program that prompts the user to enter a positive number n (n>0) and 
displays numbers from 1 to n. However, for multiples of 3, display "Fizz" instead 
of the number, and for multiples of 5, display "Buzz". For numbers that are multiples 
of both 3 and 5, display "FizzBuzz".

## Example Output:

Input: -6
Output: "Please enter a positive integer."
Input: 17
Output: "1 2 Fizz 4 Buzz Fizz 7 8 Fizz Buzz 11 Fizz 13 14 FizzBuzz 16 17"
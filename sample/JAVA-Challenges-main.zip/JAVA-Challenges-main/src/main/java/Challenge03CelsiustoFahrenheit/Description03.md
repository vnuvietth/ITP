# Celsius to Fahrenheit

Write a method named `calculateFactorial` that takes a positive integer n as 
a parameter and returns the factorial of that number.

Example Output:
Input: -6
Output: "Error: Invalid input. Please enter a positive integer."
Input: 6
Output: "The factorial of 6 is: 720."

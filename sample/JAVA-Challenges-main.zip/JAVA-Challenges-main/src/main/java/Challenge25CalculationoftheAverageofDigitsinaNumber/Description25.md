# Calculation of the Average of Digits in a Number

Write a method named `averageDigits` that takes an integer as a parameter, calculates the average of its digits, and returns the result.

### Example Output:
- Input: 31560
  - Output:
    ```
    Result: 3
    ```

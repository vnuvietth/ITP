# Sum of Digits Calculation

Write a method named `sumOfDigits` that takes an integer as a parameter and
returns the sum of its digits.
Call the `sumOfDigits` method in the `main` function.

## Example Output:
Input: 546

Output: The sum of the digits of 546 is: 15
# Email Address Validation

Write a method named `validateEmail` that takes a string as a parameter and checks if it matches a valid email address format. It returns `true` or `false`.
Call the `validateEmail` method in the `main` function.

## Example Output:

Input: "example@example"
Output: example@example is a valid email address: false
Input: "example@example.com"
Output: example@example.com is a valid email address: true
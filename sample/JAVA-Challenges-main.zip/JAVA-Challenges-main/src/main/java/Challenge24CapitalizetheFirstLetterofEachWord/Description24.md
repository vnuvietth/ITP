# Challenge 24: Capitalize the First Letter of Each Word

Write a method named `capitalizeFirstLetter` that takes a string as a parameter and returns a new string where the first letter of each word is capitalized. Call the `capitalizeFirstLetter` method in the `main` function.

### Example Output:
- Input: "conversion de la première lettre de chaque mot en majuscule"
  - Output:
    ```
    Result: Conversion De La Première Lettre De Chaque Mot En Majuscule
    ```

# Prime Number Verification

Write a method named `isPrimeNumber` that takes a positive integer as a parameter and determines if it is a prime number or not. Call the `isPrimeNumber` function in the `main` function.

### Example Output:
- Input: 17
  - Output: `17 is a prime number: true`
- Input: 15
  - Output: `15 is a prime number: false`

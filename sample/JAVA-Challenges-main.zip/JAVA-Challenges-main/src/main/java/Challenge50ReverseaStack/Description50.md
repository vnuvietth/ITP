# Reverse a Stack

Write a recursive method `reverse` that takes a stack of characters (`Stack<Character>`) as a parameter and reverses it using recursion (without using loops). Then, return the result.

**Example Output:**

- **Input:** `a b c d`
- **Output:** `d c b a`

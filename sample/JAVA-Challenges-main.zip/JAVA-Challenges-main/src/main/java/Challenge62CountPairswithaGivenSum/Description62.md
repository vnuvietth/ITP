# Count Pairs with a Given Sum

Given an array of N integers and an integer K, the task is to find the number of pairs of integers in the array whose sum equals K.

Write a method named `countPairs` that returns the number of pairs of integers in the array whose sum equals K.

### Example Output:

**Input:** `arr = {1, 5, 7, -1}, K = 6`  
**Output:** `2`

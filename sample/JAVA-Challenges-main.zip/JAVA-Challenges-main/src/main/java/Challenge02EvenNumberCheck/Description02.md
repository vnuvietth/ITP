# Even Number Check

Write a method named `isEvenNumber` that takes an integer as a parameter and 
returns `true` if the number is even, otherwise returns `false`. Call the 
`isEvenNumber` method in the `main` function.

#### Example Output:
Input: 10 

Output: 10 is an even number.

Input: 15

Output: 15 is not an even number.

# Calculation of the Sum of Matrix Elements

Write a method named `sumMatrix` that takes a matrix of integers as a parameter and returns the sum of all the elements in this matrix. Call the `sumMatrix` method in the `main` function.

### Example Output:
- Input:
  ```java
  int[][] matrix = {
      {1, 2, 3},
      {4, 5, 6},
      {7, 8, 9}
  };

- Output:
The sum of the elements of the matrix is: 45

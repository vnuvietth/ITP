# Longest Increasing Subarray

Write a method named `longestIncreasingSubarray` that takes an array of integers and returns the length of the longest increasing subarray.

## Example Output:

Input: { 5, 6, 3, 5, 7, 8, 9, 11, 2, 4, 10 }
Output: 6

"Because the longest increasing subarray is { 3, 5, 7, 8, 9, 11 }!"
class Solution {
    public int distinctIntegers(int n) {
        return Math.max(n - 1, 1);
    }
}

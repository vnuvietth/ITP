package Easy;

class MinimumCutstoDivideaCircle {
    public static int numberOfCuts(int n) {
        return n == 1 ? 0 : (n % 2 == 0 ? n / 2 : n);
    }
}

package Easy;


import org.w3c.dom.Node;

import java.util.List;

class MaximumDepthofNaryTree {
//    public int maxDepth(Node1 root) {
//        if (root == null) {
//            return 0;
//        }
//
//        int max = Integer.MIN_VALUE;
//
//        for (Node1 child : root.children) {
//            max = Math.max(max, maxDepth(child));
//        }
//
//        return 1 + Math.max(max, 0);
//    }
}

// Definition for a Node.
//class Node1 {
//    public int val;
//    public List<Node> children;
//
//    public Node1() {}
//
//    public Node1(int _val,List<Node> _children) {
//        val = _val;
//        children = _children;
//    }
//};
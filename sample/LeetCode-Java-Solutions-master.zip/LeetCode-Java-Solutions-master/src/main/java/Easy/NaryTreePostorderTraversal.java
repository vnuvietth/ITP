package Easy;/*
// Definition for a Node.
class Node {
    public int val;
    public List<Node> children;

    public Node() {}

    public Node(int _val) {
        val = _val;
    }

    public Node(int _val, List<Node> _children) {
        val = _val;
        children = _children;
    }
};
*/

import java.util.ArrayList;
import java.util.List;

class NaryTreePostorderTraversal {
//  public List<Integer> postorder(Node1 root) {
//    List<Integer> result = new ArrayList<>();
////    helper(root, result);
//    return result;
//  }
  
//  private void helper(Node1 root, List<Integer> result) {
//    if (root == null) {
//      return;
//    }
//    for (Node1 child : root.children) {
//      helper(child, result);
//    }
//    result.add(root.val);
//  }
}

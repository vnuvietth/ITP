package Easy;

class AccountBalanceAfterRoundedPurchase {
    public int accountBalanceAfterPurchase(int purchaseAmount) {
        if (purchaseAmount % 10 >= 5) {
            purchaseAmount += 10 - purchaseAmount % 10;
        } else {
            purchaseAmount -= purchaseAmount % 10;
        }
        return 100 - purchaseAmount;
    }

//    public static void main(String[] args) {
//        System.out.println("Executing unit: public int accountBalanceAfterPurchase(int purchaseAmount) ...");
//
//        String param0 = (String) jsonObject.get("purchaseAmount");
//        System.out.println("purchaseAmount = "  + param0);
//
//        AccountBalanceAfterRoundedPurchase object = new AccountBalanceAfterRoundedPurchase();
//        Object output = object.accountBalanceAfterPurchase(Integer.parseInt(param0));
//
//        System.out.println("output = "  + output.toString());
//    }
}

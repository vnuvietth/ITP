package Easy;

class KItemsWiththeMaximumSum {
    public static int kItemsWithMaximumSum(int numOnes, int numZeros, int numNegOnes, int k) {
        int sum = 0;
        sum += (numOnes > k ? k: numOnes) * 1;
        k -= (numOnes > k ? k : numOnes);
        sum += (numZeros > k ? k : numZeros) * 0;
        k -= (numZeros > k ? k : numZeros);
        sum += (numNegOnes > k? k : numNegOnes) * -1;
        return sum;
    }
}

package Easy;

class DistributeCandiestoPeople {
  public static int[] distributeCandies(int candies, int num_people) {
    int[] people = new int[num_people];
    for (int give = 0; candies > 0; candies -= give) {
      people[give % num_people] +=  (candies > ++give? give:candies);
    }
    return people;
  }
}

package Easy;

class NumberofDaysinaMonth {
  public static int numberOfDays(int Y, int M) {
    final int[] DAY_COUNT = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    boolean isLeapYear = Y % 4 == 0 && ((Y % 100 == 0) ? (Y % 400 == 0) : true);
    return DAY_COUNT[M - 1] + (M == 2 ? (isLeapYear ? 1 : 0) : 0);
  }
}

package Easy;

class FindClosestPerson {
    public static int findClosest(int x, int y, int z) {
        int diffOne = (x > z?x - z: z - x);
        int diffTwo = (y > z ? y - z : z - y);
        return diffOne == diffTwo ? 0 : (diffOne < diffTwo ? 1 : 2);
    }
}

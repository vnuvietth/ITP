package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class NumberofArithmeticTriplets {
  public int arithmeticTriplets(int[] nums, int diff) {
    int count = 0;
    Set<Integer> set = new HashSet<>();
    for (int num : nums) {
      if (set.contains(num - diff) && set.contains(num - 2 * diff)) {
        count++;
      }
      set.add(num);
    }
    return count;
  }
}

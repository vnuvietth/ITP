package Easy;

class MaximumProductofTwoDigits {
    public static int maxProduct(int n) {
        int maximum = -2147483648;
        int secondMaximum = -2147483648;
        while (n > 0) {
            int num = n % 10;
            n /= 10;
            if (num > maximum) {
                secondMaximum = maximum;
                maximum = num;
            } else if (num > secondMaximum) {
                secondMaximum = num;
            }
        }
        return maximum * secondMaximum;
    }
}

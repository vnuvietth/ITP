package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class CountIntegersWithEvenDigitSum {
  public CountIntegersWithEvenDigitSum(){}
  public int countEven(int num) {
    return (int) IntStream.range(1, num + 1).boxed().filter(this::isSumOfDigitsEven).count();
  }

  public boolean isSumOfDigitsEven(int num) {
    int sum = 0;
    while (num > 0) {
      sum += num % 10;
      num /= 10;
    }
    return sum % 2 == 0;
  }
}

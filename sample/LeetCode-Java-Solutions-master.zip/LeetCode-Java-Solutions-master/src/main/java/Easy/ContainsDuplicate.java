package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class ContainsDuplicate {
  public boolean containsDuplicate(int[] nums) {
    return Arrays.stream(nums).boxed().collect(Collectors.toSet()).size() < nums.length;
  }
}

package Easy;

class CountDistinctNumbersonBoard {
    public static int distinctIntegers(int n) {
        return n - 1 > 1 ? n-1 : 1;
    }
}

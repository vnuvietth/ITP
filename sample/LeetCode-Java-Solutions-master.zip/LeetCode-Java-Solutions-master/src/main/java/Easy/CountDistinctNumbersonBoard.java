package Easy;

class CountDistinctNumbersonBoard {
    public int distinctIntegers(int n) {
        return Math.max(n - 1, 1);
    }
}

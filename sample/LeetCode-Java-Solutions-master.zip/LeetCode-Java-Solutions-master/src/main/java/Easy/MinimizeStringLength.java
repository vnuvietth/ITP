package Easy;

class MinimizeStringLength {
    public int minimizedStringLength(String s) {
        return (int) s.chars()
            .distinct()
            .count();
    }
}

package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import java.math.BigInteger;


class FindGreatestCommonDivisorofArray {
  public int findGCD(int[] nums) {
    return BigInteger.valueOf(Arrays.stream(nums).max().orElse(1))
        .gcd(BigInteger.valueOf(Arrays.stream(nums).min().orElse(1))).intValue();
  }
}

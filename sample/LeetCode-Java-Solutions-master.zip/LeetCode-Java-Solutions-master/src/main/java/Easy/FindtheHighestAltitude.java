package Easy;

class FindtheHighestAltitude {
    public int largestAltitude(int[] gain) {
        int highestAltitude = 0;
        int currAltitude = 0;
        for (int i = 0; i < gain.length; i++) {
            currAltitude = currAltitude + gain[i];
            highestAltitude = Math.max(highestAltitude, currAltitude);
        }
        return highestAltitude;
    }
}

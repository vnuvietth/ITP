package Easy;

/**
* Definition for singly-linked list.
* public class ListNode {
*     int val;
*     ListNode next;
*     ListNode(int x) { val = x; }
* }
*/
class DeleteNodeinaLinkedList {
//  public void deleteNode(ListNode node) {
//    int nextVal = node.next.val;
//    node.next = node.next.next;
//    node.val = nextVal;
//  }
}

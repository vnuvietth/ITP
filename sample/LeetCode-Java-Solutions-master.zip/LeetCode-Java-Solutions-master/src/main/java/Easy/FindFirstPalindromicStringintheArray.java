package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class FindFirstPalindromicStringintheArray {
    public String firstPalindrome(String[] words) {
        return Arrays.stream(words)
            .filter(word -> word.equals(new StringBuilder(word).reverse().toString()))
            .findFirst()
            .orElse("");
    }
}

package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class MaximumValueofaStringinanArray {
//    public int maximumValue(String[] strs) {
//        return Arrays.stream(strs)
//                .mapToInt(M1bitand2bitCharacters::getStringValue)
//                .max()
//                .orElse(0);
//    }

    private static int getStringValue(String s) {
        for (char c : s.toCharArray()) {
            if (!Character.isDigit(c)) {
                return s.length();
            }
        }
        return Integer.parseInt(s);
    }
}

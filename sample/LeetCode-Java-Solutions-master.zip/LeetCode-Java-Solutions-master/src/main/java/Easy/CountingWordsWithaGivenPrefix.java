package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class CountingWordsWithaGivenPrefix {
  public int prefixCount(String[] words, String pref) {
    return (int) Arrays.stream(words).filter(w -> w.startsWith(pref)).count();
  }
}

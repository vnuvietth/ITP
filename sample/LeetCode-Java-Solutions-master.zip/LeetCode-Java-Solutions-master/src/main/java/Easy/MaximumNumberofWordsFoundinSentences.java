package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class MaximumNumberofWordsFoundinSentences {
  public int mostWordsFound(String[] sentences) {
    return Arrays.stream(sentences).map(sentence -> sentence.split("\\s").length)
        .max(Integer::compare).orElse(0);
  }
}

package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class FindtheXORofNumbersWhichAppearTwice {
    public int duplicateNumbersXOR(int[] nums) {
        Set<Integer> set = new HashSet<>();
        int xor = 0;
        for (int num : nums) {
            if (!set.add(num)) {
                xor = xor ^ num;
            }
        }
        return xor;
    }
}

package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class CheckiftheSentenceIsPangram {
  public boolean checkIfPangram(String sentence) {
    return sentence.chars().mapToObj(c -> (char) c).collect(Collectors.toSet()).size() == 26;
  }
}

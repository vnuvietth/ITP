package Easy;

import java.util.LinkedList;
import java.util.Queue;

class NumberofRecentCalls {
  
  private Queue<Integer> queue;
  
  public NumberofRecentCalls() {
    queue = new LinkedList<>();
  }

  public int ping(int t) {
    while (!queue.isEmpty() && t - queue.peek() > 3000) {
      queue.remove();
    }
    queue.add(t);
    return queue.size();
  }
}

/**
 * Your RecentCounter object will be instantiated and called as such:
 * RecentCounter obj = new RecentCounter();
 * int param_1 = obj.ping(t);
 */

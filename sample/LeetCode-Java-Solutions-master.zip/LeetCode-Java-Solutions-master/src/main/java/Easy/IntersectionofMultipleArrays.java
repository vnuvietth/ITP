package Easy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;


class IntersectionofMultipleArrays {
  public List<Integer> intersection(int[][] nums) {
    Map<Integer, Integer> counter = new HashMap<>();
    for (int[] num : nums) {
      for (int element : num) {
        counter.put(element, counter.getOrDefault(element, 0) + 1);
      }
    }
    return counter.entrySet()
      .stream()
      .filter(entry -> entry.getValue() == nums.length)
      .map(Entry::getKey)
      .sorted()
      .collect(Collectors.toList());
  }
}

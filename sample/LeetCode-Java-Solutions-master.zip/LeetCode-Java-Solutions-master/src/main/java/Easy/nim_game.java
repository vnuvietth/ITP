package Easy;

public class nim_game {
    public boolean canWinNim(int n) {
        if(n%4==0)
            return false;
        else
            return true;
    }
}

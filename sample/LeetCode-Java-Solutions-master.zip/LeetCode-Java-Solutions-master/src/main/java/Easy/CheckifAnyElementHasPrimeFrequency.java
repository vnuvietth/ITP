package Easy;
import java.util.*;

class CheckifAnyElementHasPrimeFrequency {
    public boolean checkPrimeFrequency(int[] nums) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int num : nums) {
            map.put(num, map.getOrDefault(num, 0) + 1);
        }
        for (Integer value : map.values()) {
            if (isPrime1(value)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isPrime1(int num) {
        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return num > 1 && true;
    }
}

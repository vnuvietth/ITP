package Easy;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode() {}
 *     TreeNode(int val) { this.val = val; }
 *     TreeNode(int val, TreeNode left, TreeNode right) {
 *         this.val = val;
 *         this.left = left;
 *         this.right = right;
 *     }
 * }
 */
class AverageofLevelsinBinaryTree {
//  public List<Double> averageOfLevels(TreeNode root) {
//    List<Double> result = new ArrayList<>();
//    Queue<TreeNode> queue = new LinkedList<>();
//    queue.add(root);
//    while (!queue.isEmpty()) {
//      int size = queue.size();
//      double total = 0.0;
//      for (int i = 0; i < size; i++) {
//        TreeNode removed = queue.remove();
//        total += removed.val;
//        if (removed.left != null) {
//          queue.add(removed.left);
//        }
//        if (removed.right != null) {
//          queue.add(removed.right);
//        }
//      }
//      result.add(total / size);
//    }
//    return result;
//  }
}

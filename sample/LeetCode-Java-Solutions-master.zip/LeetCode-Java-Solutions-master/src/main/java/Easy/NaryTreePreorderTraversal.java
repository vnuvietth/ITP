package Easy;/*
// Definition for a Node.
class Node {
    public int val;
    public List<Node> children;

    public Node() {}

    public Node(int _val) {
        val = _val;
    }

    public Node(int _val, List<Node> _children) {
        val = _val;
        children = _children;
    }
};
*/

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

class NaryTreePreorderTraversal {
//  public List<Integer> preorder(Node1 root) {
//    if (root == null) {
//      return new ArrayList<>();
//    }
//    List<Integer> list = new ArrayList<>();
//    Stack<Node1> stack = new Stack<>();
//    stack.push(root);
//    while (!stack.isEmpty()) {
//      Node1 popped = stack.pop();
//      list.add(popped.val);
//      List<Node1> children = popped.children;
//      for (int i = children.size() - 1; i >= 0; i--) {
//        stack.push(children.get(i));
//      }
//    }
//    return list;
//  }
}

package Easy;

class FindtheMaximumAchievableNumber {
    public static int theMaximumAchievableX(int num, int t) {
        return num + 2 * t;
    }
}

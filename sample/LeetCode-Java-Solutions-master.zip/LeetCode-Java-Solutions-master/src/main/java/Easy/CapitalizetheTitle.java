package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class CapitalizetheTitle {
  public String capitalizeTitle(String title) {
    return Arrays.stream(title.split("\\s+"))
        .map(e -> e.length() <= 2 ? e.toLowerCase() :
            e.substring(0, 1).toUpperCase() + e.substring(1).toLowerCase())
        .collect(Collectors.joining(" "));
  }
}

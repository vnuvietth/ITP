package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class MakeArrayZerobySubtractingEqualAmounts {
  public int minimumOperations(int[] nums) {
    return Arrays.stream(nums).boxed().filter(n -> n > 0).collect(Collectors.toSet()).size();
  }
}

package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class CheckIfNandItsDoubleExist {
  public boolean checkIfExist(int[] arr) {
    Set<Integer> set = new HashSet<>();
    for (Integer num : arr) {
      if (set.contains(num * 2) || (num % 2 == 0 && set.contains(num / 2))) {
        return true;
      }
      set.add(num);
    }
    return false;
  }
}

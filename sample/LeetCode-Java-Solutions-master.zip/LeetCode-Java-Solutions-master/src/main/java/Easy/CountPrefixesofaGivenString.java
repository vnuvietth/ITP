package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class CountPrefixesofaGivenString {
  public int countPrefixes(String[] words, String s) {
    return (int) Arrays.stream(words).filter(word -> s.startsWith(word)).count();
  }
}

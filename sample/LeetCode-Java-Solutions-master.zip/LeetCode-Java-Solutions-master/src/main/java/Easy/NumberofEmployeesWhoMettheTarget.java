package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class NumberofEmployeesWhoMettheTarget {
    public int numberOfEmployeesWhoMetTarget(int[] hours, int target) {
        return (int) Arrays.stream(hours).filter(hour -> hour >= target).count();
    }
}

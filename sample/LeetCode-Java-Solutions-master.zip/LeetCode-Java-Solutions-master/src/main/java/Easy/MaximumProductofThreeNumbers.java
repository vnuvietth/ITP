package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class MaximumProductofThreeNumbers {
  public int maximumProduct(int[] nums) {
    Arrays.sort(nums);
    int n = nums.length;
    int lastThree = nums[n - 1] * nums[n - 2] * nums[n - 3];
    int firstTwoAndLast = nums[0] * nums[1] * nums[n - 1];
    return Math.max(lastThree, firstTwoAndLast);
  }
}

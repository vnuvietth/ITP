package Easy;

class CategorizeBoxAccordingtoCriteria {
    
    private static final int BULKY_DIMENSION_THRESHOLD = 10000;
    private static final int BULKY_VOLUME_THRESHOLD = 1000000000;
    private static final int HEAVY_MASS_THRESHOLD = 100;
    
    public static String categorizeBox(int length, int width, int height, int mass) {
        long volume = ((long) length) * width * height;
        boolean isBulky = length >= 10000 ||
            width >= 10000 ||
            height >= 10000 ||
            mass >= 10000 ||
            volume >= 1000000000;
        boolean isHeavy = mass >= 100;
        if (isBulky && isHeavy) {
            return "Both";
        }
        if (!(isBulky || isHeavy)) {
            return "Neither";
        }
        return isBulky ? "Bulky" : "Heavy";
    }

    public static void main(String[] args) {
        System.out.println("BULKY_DIMENSION_THRESHOLD = " + 10000);
    }
}

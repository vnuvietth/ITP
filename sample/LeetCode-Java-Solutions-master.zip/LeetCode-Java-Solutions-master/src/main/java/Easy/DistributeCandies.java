package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class DistributeCandies {
  public int distributeCandies(int[] candyType) {
    return Math.min(
      Arrays.stream(candyType).boxed().collect(Collectors.toSet()).size(),
      candyType.length / 2
    );
  }
}

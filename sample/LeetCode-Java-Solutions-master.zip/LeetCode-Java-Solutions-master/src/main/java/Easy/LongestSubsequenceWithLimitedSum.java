package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class LongestSubsequenceWithLimitedSum {
  public int[] answerQueries(int[] nums, int[] queries) {
    Arrays.sort(nums);
    Arrays.parallelPrefix(nums, Integer::sum);
    for (int i = 0; i < queries.length; i++) {
      int idx = Arrays.binarySearch(nums, queries[i]);
      queries[i] = Math.abs(idx + 1);
    }
    return queries;
  }
}

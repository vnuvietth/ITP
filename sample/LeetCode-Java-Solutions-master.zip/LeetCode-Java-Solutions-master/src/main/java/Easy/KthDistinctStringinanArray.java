package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import java.util.Map.Entry;

class KthDistinctStringinanArray {
  public String kthDistinct(String[] arr, int k) {
    return Arrays.stream(arr).collect(
            Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()))
        .entrySet().stream().filter(entry -> entry.getValue().equals(1L)).map(Entry::getKey)
        .skip(k - 1)
        .findFirst().orElse("");
  }
}

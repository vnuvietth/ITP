package Easy;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class CheckifBitwiseORHasTrailingZeros {
    public boolean hasTrailingZeros(int[] nums) {
        return Arrays.stream(nums)
                .filter(num -> Integer.numberOfTrailingZeros(num) > 0)
                .count() >= 2;
    }
}

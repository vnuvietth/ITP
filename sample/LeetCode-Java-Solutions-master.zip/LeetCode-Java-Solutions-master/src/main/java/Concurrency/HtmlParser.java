package Concurrency;

import java.util.List;

public class HtmlParser {
    public List<String> getUrls(String url) {
        return null;
    }
}

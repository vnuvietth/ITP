# Concurrency LeetCode Java Solutions 
S.no | Coding Problem 
--- | --- 
1 | [Building H2O](https://github.com/varunu28/LeetCode-Java-Solutions/tree/master/Concurrency/Building%20H2O.java)
2 | [Design Bounded Blocking Queue](https://github.com/varunu28/LeetCode-Java-Solutions/tree/master/Concurrency/Design%20Bounded%20Blocking%20Queue.java)
3 | [Fizz Buzz Multithreaded](https://github.com/varunu28/LeetCode-Java-Solutions/tree/master/Concurrency/Fizz%20Buzz%20Multithreaded.java)
4 | [Print FooBar Alternately](https://github.com/varunu28/LeetCode-Java-Solutions/tree/master/Concurrency/Print%20FooBar%20Alternately.java)
5 | [Print Zero Even Odd](https://github.com/varunu28/LeetCode-Java-Solutions/tree/master/Concurrency/Print%20Zero%20Even%20Odd.java)
6 | [Print in Order](https://github.com/varunu28/LeetCode-Java-Solutions/tree/master/Concurrency/Print%20in%20Order.java)
7 | [The Dining Philosophers](https://github.com/varunu28/LeetCode-Java-Solutions/tree/master/Concurrency/The%20Dining%20Philosophers.java)
8 | [Traffic Light Controlled Intersection](https://github.com/varunu28/LeetCode-Java-Solutions/tree/master/Concurrency/Traffic%20Light%20Controlled%20Intersection.java)

package ch_20;

import java.util.Scanner;
import java.util.Stack;

/**
 * 20.22 (Nonrecursive Tower of Hanoi) Implement the moveDisks method in Listing
 * 18.8 using a stack instead of using recursion.
 */
public class Exercise20_22 {

    public static class HanoiMove {
        boolean isLastInFromTower = false;
        int n;
        char fromTower;
        char toTower;
        char auxTower;

        HanoiMove(boolean isLastInFromTower, int n, char fromTower, char toTower, char auxTower) {
            this.isLastInFromTower = isLastInFromTower;
            this.n = n;
            this.fromTower = fromTower;
            this.toTower = toTower;
            this.auxTower = auxTower;
        }
    }
}
package ch_20;

import java.util.Stack;

/**
 * ***20.19 (Game: solution ratio for 24-point game) When you pick four cards from a
 * deck of 52 cards for the 24-point game introduced in Programming Exercise
 * 20.13, the four cards may not have a 24-point solution. What is the number
 * of all possible picks of four cards from 52 cards? Among all possible picks,
 * how many of them have 24-point solutions? What is the success ratio—that is,
 * (number of picks with solutions)/ (number of all possible picks of four cards)?
 * Write a program to find these answers.
 */
public class Exercise20_19 {
    /**
     * C(n,r)=n!/(n−r)!r!
     * C = combinations
     * n = total objects
     * r = sample size (slots)
     *
     * @param r sample size
     * @param n number of unique objects
     * @return c
     */
    public static long findTotalPossibleCombinations(int r, int n) {
        /* Permutations / Slots! = possible combinations */
        long permutations = 1; // Initialize
        long slots = 1; // Initialize
        int sampleFactor = n;
        int slotsFactor = r;

        while (slotsFactor >= 1) {
            permutations *= sampleFactor;
            slots *= slotsFactor;
            sampleFactor--;
            slotsFactor--;
        }

        return permutations / slots;
    }

    public static String delimit2(String str) {
        String res = "";

        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == '(' || str.charAt(i) == ')' || str.charAt(i) == '+' || str.charAt(i) == '-'
                    || str.charAt(i) == '/' || str.charAt(i) == '*') {

                res += " " + str.charAt(i) + " ";

            } else {
                res += str.charAt(i);

            }

        }

        return res;
    }
}

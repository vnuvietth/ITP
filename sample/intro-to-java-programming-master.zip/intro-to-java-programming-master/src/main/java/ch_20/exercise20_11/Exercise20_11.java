package ch_20.exercise20_11;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Stack;

/**
 * 20.11 (Match grouping symbols) A Java program contains various pairs of grouping
 * symbols, such as:
 * ■ Parentheses: ( and )
 * ■ Braces: { and }
 * ■ Brackets: [ and ]
 * Note that the grouping symbols cannot overlap. For example, (a{b)} is illegal.
 * Write a program to check whether a Java source-code file has correct pairs of
 * grouping symbols. Pass the source-code file name as a command-line argument.
 */
public class Exercise20_11 {
    public static boolean isPair(char ch1, char ch2) {
        switch (ch1) {
            case '}':
                return ch2 == '{';
            case ')':
                return ch2 == '(';
            case ']':
                return ch2 == '[';
        }
        return false;

    }


}

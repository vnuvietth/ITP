package ch_20;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

/**
 * ***20.15 (Game: the 24-point card game) Improve Programming Exercise 20.13
 * to enable the computer to display the expression if one exists, as shown in
 * Figure 20.20. Otherwise, report that the expression does not exist. Place the
 * label for verification result at the bottom of UI. The expression must use all
 * four cards and evaluates to 24.
 */
public class Exercise20_15 {
    public static boolean equals24(double i) {
        return i >= 23.999 && i <= 24.001;
    }

    public static double operate(double a, double b, int op) {
        if (op == 0) return a + b;
        if (op == 1) return a - b;
        if (op == 2) return a * b;
        if (op == 3) {
            return a / b;
        }
        return 0;
    }


}

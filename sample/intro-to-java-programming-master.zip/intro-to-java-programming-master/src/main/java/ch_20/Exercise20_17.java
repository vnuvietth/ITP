package ch_20;


/**
 * **20.17 (Game: the 24-point card game) This exercise is a variation of the 24-point
 * card game described in Programming Exercise 20.13. Write a program to
 * check whether there is a 24-point solution for the four specified numbers. The
 * program lets the user enter four values, each between 1 and 13, as shown in
 * Figure 20.21. The user can then click the Solve button to display the solution or
 * display “No solution” if none exist.
 */
public class Exercise20_17{

    public static boolean equals24(double i) {
        return i >= 23.999 && i <= 24.001;
    }

    public static double operate2(double a, double b, int op) {
        if (op == 0) return a + b;
        if (op == 1) return a - b;
        if (op == 2) return a * b;
        if (op == 3) {
            return a / b;
        }
        throw new IllegalArgumentException("operate( " + a + ", " + b + ", " + op + " )");

    }

    public static String findSolution(int[] numbers) {
        for (int a = 0; a < 4; a++) {
            for (int b = 0; b < 4; b++) {
                if (a != b) {
                    for (int c = 0; c < 4; c++) {
                        if (a != c && b != c) {
                            for (int d = 0; d < 4; d++) {
                                // permutation of 4 numbers, index is a,b,c,d
                                if (a != d && b != d && c != d) {
                                    for (int x = 0; x < 4; x++) {
                                        for (int y = 0; y < 4; y++) {
                                            // 3 ops '+-*/', in x,y,z
                                            for (int z = 0; z < 4; z++) {
                                                // Exp 1
                                                if (equals24(operate2(numbers[a], operate2(numbers[b], operate2(numbers[c], numbers[d],
                                                        x), y), z))) {
                                                    return getExpressionString(1, numbers[a], numbers[b], numbers[c], numbers[d]
                                                            , x, y, z);
                                                }
                                                // Exp 2
                                                if (equals24(operate2(numbers[a], operate2(operate2(numbers[b], numbers[c], x),
                                                        numbers[d], y), z))) {
                                                    return getExpressionString(2, numbers[a], numbers[b], numbers[c], numbers[d]
                                                            , x, y, z);
                                                }
                                                // Exp 3
                                                if (equals24(operate2(operate2(numbers[a], operate2(numbers[b], numbers[c], x), y),
                                                        numbers[d], z))) {
                                                    return getExpressionString(3, numbers[a], numbers[b], numbers[c], numbers[d]
                                                            , x, y, z);
                                                }
                                                // Exp 4
                                                if (equals24(operate2(operate2(numbers[a], numbers[b], x), operate2(numbers[c],
                                                        numbers[d], y), z))) {
                                                    return getExpressionString(4, numbers[a], numbers[b], numbers[c], numbers[d]
                                                            , x, y, z);
                                                }
                                                // Exp 5
                                                if (equals24(operate2(operate2(operate2(numbers[a], numbers[b], x), numbers[c], y),
                                                        numbers[d], z))) {
                                                    return getExpressionString(5, numbers[a], numbers[b], numbers[c], numbers[d]
                                                            , x, y, z);
                                                }
                                            }
                                        }

                                    }

                                }

                            }

                        }

                    }


                }

            }
        }

        return "No Solution";
    }

    public static String getOp(int op) {
        switch (op) {
            case 0:
                return "+";
            case 1:
                return "-";
            case 2:
                return "*";
            case 3:
                return "/";
        }
        return "";
    }

    public static String getExpressionString(int exp,
                               int a,
                               int b,
                               int c,
                               int d,
                               int x,
                               int y,
                               int z) {
        switch (exp) {
            case 1:
                return "" + a + getOp(z) + "(" + b + getOp(y) + "(" + c + getOp(x) + d + ")" + ")";
            case 2:
                return "" + a + getOp(z) + "(" + y + getOp(y) + "(" + b + getOp(x) + c + ")" + ")";
            case 3:
                return "" + d + getOp(z) + "(" + a + getOp(y) + "(" + b + getOp(x) + c + ")" + ")";
            case 4:
                return "(" + a + getOp(x) + b + ")" + getOp(z) + "(" + c + getOp(y) + d + ")";
            case 5:
                return "" + d + getOp(z) + "(" + c + getOp(y) + "(" + a + getOp(x) + b + ")" + ")";
        }
        return "";
    }

}

package ch_20;

import java.util.Scanner;
import java.util.Stack;

/**
 * *20.23 (Evaluate expression) Modify Listing 20.9 EvaluateExpression.java to add
 * operators ^ for exponent and % for modulus. For example, 3 ^ 2 is 9 and 3 % 2
 * is 1. The ^ operator has the highest precedence and the % operator has the same
 * precedence as the * and / operators. Your program should prompt the user to
 * enter an expression. Here is a sample run of the program:
 * Enter an expression: (5 * 2 ^ 3 + 2 * 3 % 2) * 4
 * (5 * 2 ^ 3 + 2 * 3 % 2) * 4 = 160
 */
public class Exercise20_23 {

    public static String insertBlanks(String s) {
        String result = "";
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '(' || s.charAt(i) == ')' ||
                    s.charAt(i) == '+' || s.charAt(i) == '-' ||
                    s.charAt(i) == '*' || s.charAt(i) == '/' ||
                    s.charAt(i) == '^' || s.charAt(i) == '%') // Check for exponent and modulus operands.
                result += " " + s.charAt(i) + " ";
            else
                result += s.charAt(i);
        }
        return result;
    }
}
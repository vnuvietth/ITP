package ch_06;

import java.util.*;

/**
 * **6.29 (Twin primes) Twin primes are a pair of prime numbers that differ by 2.
 * For example, 3 and 5 are twin primes, 5 and 7 are twin primes, and 11 and 13 are twin primes.
 * Write a program to find all twin primes less than 1,000. Display the output as follows:
 * (3, 5)
 * (5, 7)
 * ...
 */
public class Exercise06_29 {
    public static boolean isPrime(int num) {
        boolean prime = true;
        for (int i = 2; i <= (num / 2); i++) {
            if (num % i == 0) {
                prime = false;
                break;
            }
        }
        return prime;
    }

    public static int[] twinPrime(int[] primes, int prime) {
        if (primes[prime + 2] > 0) {
            return new int[]{prime, prime + 2};
        }
        return new int[]{0, 0};
    }
}
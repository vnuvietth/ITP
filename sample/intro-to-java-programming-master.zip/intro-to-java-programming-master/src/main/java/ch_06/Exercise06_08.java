package ch_06;

/**
 * 6.8 (Conversions between Celsius and Fahrenheit) Write a class that contains the following two methods:
 * public static double celsiusToFahrenheit(double celsius)
 * public static double fahrenheitToCelsius(double fahrenheit)
 * The formula for the conversion is:
 * fahrenheit=(9.0/5)*celsius+32
 * celsius=(5.0/9)*(fahrenheit – 32)
 */
public class Exercise06_08 {
    /**
     * Convert from Celsius to Fahrenheit
     */
    public static double celsiusToFahrenheit(double celsius) {
        return (9.0 / 5) * celsius + 32;
    }

    /**
     * Convert from Fahrenheit to Celsius
     */
    public static double fahrenheitToCelsius(double fahrenheit) {
        return (5.0 / 9) * (fahrenheit - 32);
    }
}
package ch_06;

/**
 * *6.19 (The MyTriangle class) Create a class named MyTriangle that contains the
 * following two methods:
 * /** Return true if the sum of any two sides is
 * * greater than the third side.
 * public static boolean isValid(
 * double side1,double side2,double side3)
 * /** Return the area of the triangle.
 * public static double area(
 * double side1,double side2,double side3)
 * <p>
 * <p>
 * Write a test program that reads three sides for a triangle and computes the area if
 * the input is valid. Otherwise,it displays that the input is invalid.The formula for
 * computing the area of a triangle is given in Programming Exercise2.19.
 *
 * @author Harry D.
 */
public class Exercise06_19 {
    /**
     * Return the area of the triangle.
     */
    public static double area(double side1, double side2, double side3) {
        double s = (side1 + side2 + side3) / 2;

        return Math.sqrt((s * (s - side1) * (s - side2) * (s - side3)));
    }

    /**
     * Return true if the sum of any two sides is
     * greater than the third side.
     */
    public static boolean isValid(
            double side1, double side2, double side3) {
        if ((side1 + side2) > side3) {
            return false;
        } else if ((side1 + side3) > side2) {
            return false;
        } else if ((side2 + side3) > side1) {
            return false;
        } else {
            return true;
        }
    }

    public static double findSide(double x, double y, double w, double z) {

        return Math.pow(Math.pow(x - w, 2) + Math.pow(y - z, 2), 0.5);
    }
}

package ch_06;

/**
 * 6.1 (Math: pentagonal numbers) A pentagonal number is defined
 * as  . . ., and so on. Therefore, the
 * first few numbers are 1, 5, 12, 22, . . . . Write a method with
 * the following header that returns a pentagonal number:
 */
public class Exercise06_01 {
    public static int getPentagonalNumber(int n) {
        return n * (3 * n - 1) / 2;
    }
}


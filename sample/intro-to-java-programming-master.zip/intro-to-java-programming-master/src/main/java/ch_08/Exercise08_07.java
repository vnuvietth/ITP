package ch_08;


/**
 * *8.7 (Points nearest to each other) Listing 8.3 gives a program that finds
 * two points in a two-dimensional space nearest to each other. Revise the
 * program so that it finds two points in a three-dimensional space nearest to
 * each other. Use a two-dimensional array to represent the points. Exercise25_01 the
 * program using the following points: double[][] points = {{-1, 0, 3}, {-1, -1,
 * -1}, {4, 1, 1}, {2, 0.5, 9}, {3.5, 2, -1}, {3, 1.5, 3}, {-1.5, 4, 2}, {5.5,
 * 4, -0.5}};
 * 
 * The formula for computing the distance between two points (x1, y1, z1) and
 * (x2, y2, z2) is SQRT[(x2 - x1)^2 + (y2 - y1)^2 + (z2 - z1)^2].
 * 
 * @author Harry Dulaney
 *
 */
public class Exercise08_07 {
	public static double distance(double x1, double y1, double z1, double x2, double y2, double z2) {
		return Math.sqrt(((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)) + ((z2 - z1) * (z2 - z1)));
	}

}
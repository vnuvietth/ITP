package ch_08;

/**
 * 8.4 (Compute the weekly hours for each employee)
 * Suppose the weekly hours for all employees are stored
 * in a two-dimensional array. Each row records an employee's
 * seven-day work hours with seven columns. For example, the
 * following array stores the work hours for eight employees.
 * Write a program that displays employees and their total
 * hours in decreasing order of the total hours.
 */
public class Exercise08_04 {
    public static void printArray(int[][] array) {

//		for(int i = array.length - 1; i >= 0; i--) { //Print in reverse
        for (int i = 0; i < array.length; i++) {
            System.out.print("Employee number: " + array[i][1] + "'s total hours for the week were ");
            System.out.print(array[i][0] + "\n");
//		}
        }


    }

}

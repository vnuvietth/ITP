package ch_08;

/* 8.1 (Sum elements column by column) Write a method that returns the sum of 
 * all the elements in a specified column in a matrix using the following header:
 * public static double sumColumn(double[][] m, int columnIndex)
 * Write a test program that reads a 3-by-4 
 * matrix and displays the sum of each column.
 */

import java.util.Scanner;

public class Exercise08_01 {

	public static double sumColumn(double[][] m, int columnIndex) {
		
		double sum = 0;
		
		for( int i = 0; i < m.length; i++) {
			
			sum += m[i][columnIndex];
		}
		return sum;
		
          }
}
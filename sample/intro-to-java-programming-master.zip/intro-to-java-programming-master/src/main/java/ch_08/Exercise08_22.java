package ch_08;

import java.util.*;

/**
 * *8.22 (Even number of 1s) Write a program that generates a 6-by-6 two-dimensional
 * matrix filled with 0s and 1s, displays the matrix, and checks if every row and
 * every column have an even number of 1s.
 *
 * @author Harry D.
 */
public class Exercise08_22 {
    public static void fillZeroAndOnes(int[][] arr) {
        for (int i = 0; i < arr.length; i += getRandom()) {
            for (int j = 0; j < arr[i].length; j += getRandom()) {
                arr[i][j] = 1;
            }
        }
    }

    public static int getRandom() {
        return (int) (0.5 + Math.random() * 3);
    }
}
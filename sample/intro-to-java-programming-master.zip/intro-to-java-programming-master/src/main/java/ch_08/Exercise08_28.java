package ch_08;

/*8.28 (Strictly identical arrays) The two-dimensional 
 * arrays m1 and m2 are strictly identical if their corresponding 
 * elements are equal. Write a method that returns true if m1 and m2 
 * are strictly identical, using the following header:
 * 
 * public static boolean equals(int[][] m1, int[][] m2)
 * 
 * Write a test program that prompts the user to enter 
 * two 3 � 3 arrays of integers and displays whether the
 * two are strictly identical. 
 */

import java.util.Scanner;

public class Exercise08_28 {

	public static boolean equals(int[][] m1, int[][] m2) {
		
		boolean isEqual = true;
		
		for(int i = 0; i < m1.length; i++) {

				 if(m1[i][0] != m2[i][0]) {
					isEqual = false;
					break;
				}else if(m1[i][1] != m2[i][1]) {
					isEqual = false;
					break;
				}else if(m1[i][2] != m2[i][2]) {
					isEqual = false;
					break;
				}
		}
		return isEqual;
	}

}

package ch_08.activities;

import java.util.Scanner;

/**
 * Listing 8.3 FindNearestPoints.java from (8.6 Case Study: Finding the Closest
 * Pair) Given a set of points, the closest-pair problem is to find the two
 * points that are nearest to each other.
 * 
 * In Figure 8.3, for example, points (1, 1) and (2, 0.5) are closest to each
 * other. There are several ways to solve this problem. An intuitive approach is
 * to compute the distances between all pairs of points and find the one with
 * the minimum distance, as implemented in Listing 8.3
 */
public class FindNearestPoints {
	/** Compute the distance between two points (x1, y1) and (x2, y2) */
	public static double distance(double x1, double y1, double x2, double y2) {
		return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
	}
}

package ch_08;

import java.util.Scanner;


/**
 * 8.6 (Algebra: multiply two matrices)
 * Write a method to multiply two matrices. The header of the method is:
 * <p>
 * public static double[][] multiplyMatrix(double[][] a, double[][] b)
 * <p>
 * To multiply matrix a by matrix b, the number of columns in A must
 * be the same as the number of rows in B, and the two matrices must have
 * elements of the same or compatible types. Let c be the result of the
 * multiplication. Assume the column size of matrix a is n. Each element
 * cij is ai1 � b1j + ai2 � b2j + � + ain � bnj. For example, for two
 * 3 � 3 matrices a and b, c is..............
 * <p>
 * Write a test program that prompts the user
 * to enter two 3 � 3 matrices and displays
 * their product.
 */
public class Exercise08_06 {
    public static double[][] multiplyMatrix(double[][] a, double[][] b) {

        double[][] result = new double[3][3];

        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                for (int z = 0; z < a.length; z++) {

                    result[i][j] += a[i][z] * b[z][j];
                }
            }
        }
        return result;
    }
}

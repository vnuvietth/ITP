package ch_18;

import java.util.Scanner;

/**
 * *18.24 (Hex to decimal) Write a recursive method that parses a hex number as a string
 * into a decimal integer.
 * <p>
 * The method header is:
 * public static int hex2Dec(String hexString)
 * Write a test program that prompts the user to enter a hex string and displays its
 * decimal equivalent.
 */
public class Exercise18_24 {

    public static long hexCharToDecimal(char ch) {
        if ('A' <= ch && ch <= 'F')
            return 10 + ch - 'A';
        else
            return ch - '0';
    }
}

package ch_18;

/**
 * 18.4 (Sum series) Write a recursive method to compute the following series:
 * m(i) = 1 + 1/2 + 1/3 +.... + 1/i
 * Write a test program that displays m(i) for i = 1, 2, . . ., 10.
 *
 * @author Harry Dulaney
 */
public class Exercise18_04 {
    public static double compute(int target) {
        double sum = 1;
        int denominator = 1;
        return compute(sum, denominator, target);
    }

    public static double compute(double sum, int denominator, int target) {
        if (denominator == target) {
            return sum;
        }
        sum += 1.0 / ++denominator;
        return compute(sum, denominator, target);
    }
}

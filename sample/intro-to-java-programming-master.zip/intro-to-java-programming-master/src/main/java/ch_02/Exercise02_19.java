package ch_02;

import java.util.*;

/**
 * 2.19 (Geometry: area of a triangle) Write a
 * program that prompts the user to enter three
 * points (x1, y1), (x2, y2), (x3, y3) of a triangle and
 * displays its area
 **/
public class Exercise02_19 {

    public static double findSide(double x0, double y0, double x1, double y1) {
        return Math.pow(Math.pow(x0 - x1, 2) + Math.pow(y0 - y1, 2), 0.5);
    }


}

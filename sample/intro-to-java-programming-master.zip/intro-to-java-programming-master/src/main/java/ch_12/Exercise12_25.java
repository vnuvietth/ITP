package ch_12;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

/**
 * *12.25 (Process large dataset) A university posts its employees’ salaries at http://
 * cs.armstrong.edu/liang/data/Salary.txt. Each line in the file consists of a faculty
 * member’s first name, last name, rank, and salary (see Programming Exercise
 * 12.24).
 * <p>
 * Write a program to display the total salary for assistant professors,
 * associate professors, full professors, and all faculty, respectively, and display
 * the average salary for assistant professors, associate professors, full professors,
 * and all faculty, respectively.
 */
public class Exercise12_25 {
    public static double average(int count, double total) {
        return total / count;
    }

    public static double sum(double totalSalaryAssistant, double totalSalaryAssociate, double totalSalaryFull) {
        return totalSalaryAssistant + totalSalaryAssociate + totalSalaryFull;
    }

    public static int sum(int c1, int c2, int c3) {
        return c1 + c2 + c3;
    }


}

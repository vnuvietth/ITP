package ch_12.exercise12_09;

/**
 * 12.9 (BinaryFormatException) Exercise 12.7 implements the bin2Dec method
 * to throw a BinaryFormatException if the string is not a binary string.
 * Define a custom exception called BinaryFormatException. Implement the
 * bin2Dec method to throw a BinaryFormatException if the string is not a
 * binary string.
 */
public class Exercise12_09 {

    public static int getBinaryValue(char binaryChar, int index) {
        int weight = (int) Math.pow(2, index);
        if (binaryChar == '1') {
            return weight;
        }
        return 0;
    }

}

package ch_07;

import java.util.*;

/**
 * *7.12 (Reverse an array) The reverse method in Section 7.7 reverses an array by
 * copying it to a new array. Rewrite the method that reverses the array passed in
 * the argument and returns this array.
 * <p>
 * Write a test program that prompts the user to
 * enter ten numbers, invokes the method to reverse the numbers, and displays the
 * numbers.
 *
 * @author Harry Dulaney
 */
public class Exercise07_12 {
    public static int[] reverse(int[] a) {
        int j = a.length - 1;
        for (int i = 0; i < a.length / 2; i++) {
            int tmp = a[i];
            a[i] = a[j];
            a[j] = tmp;
            j--;
        }
        return a;
    }

}
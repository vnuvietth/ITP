package ch_07;

import java.util.Scanner;

/**
 * 7.26 (Strictly identical arrays) The arrays list1 and list2 are
 * strictly identical if their corresponding elements are equal.
 * Write a method that returns true if list1 and list2 are strictly
 * identical, using the following header:
 * Write a test program that prompts the user to enter two lists of
 * integers and displays whether the two are strictly identical.
 * Here is a sample run. Note that the first number in the input
 * indicates the number of the elements in the list.
 * This number is not part of the list.
 */
public class Exercise07_26 {
    public static boolean equals7(int[] list1, int[] list2) {

        boolean equalorNot = true;

        if (list1.length != list2.length)
            equalorNot = false;

        for (int i = 0; i < list1.length; i++) {

            if (list1[i] != list2[i])
                equalorNot = false;

        }
        return equalorNot;

    }

}

package ch_07;

import java.util.Arrays;
import java.util.Scanner;

/**
 * 7.27 (Identical arrays) The arrays list1 and list2 are identical if they have the
 * same contents.
 * <p>
 * Write a method that returns true if list1 and list2 are identical, using the following header:
 * public static boolean equals(int[] list1, int[] list2)
 * <p>
 * Write a test program that prompts the user to enter two lists of integers and displays whether the two are identical.
 * <p>
 * Here are the sample runs. Note that the first
 * number in the input indicates the number of the elements in the list. This number
 * is not part of the list.
 * Enter list1: 5 2 5 6 6 1
 * Enter list2: 5 5 2 6 1 6
 * Two lists are identical
 */
public class Exercise07_27 {
    public static boolean equals8(int[] list1, int[] list2) {
        Arrays.sort(list1);
        Arrays.sort(list2);

        if (list1.length != list2.length) {
            return false;
        }
        for (int i = 0; i < list1.length; i++) {
            if (list1[i] != list2[i]) {
                return false;
            }
        }
        return true;
    }
}

package ch_07;

import java.util.Scanner;

/**
 * 7.2 (Reverse the numbers entered) Write a program that
 * reads ten integers and displays them in the reverse
 * of the order in which they were read.
 */
public class Exercise07_02 {

    public  static void displayReverse(int[] arrRev) {
        for (int i = arrRev.length - 1; i >= 0; i--) {
            System.out.print(arrRev[i] + " ");

        }
    }
}

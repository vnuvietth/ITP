package ch_07;

import java.util.Arrays;
import java.util.Scanner;

/**
 * *7.28 (Math: combinations) Write a program that prompts the user to enter 10 integers
 * and displays all combinations of picking two numbers from the 10.
 *
 * @author Harry.
 */
public class Exercise07_28 {
    public static String[] nextSet(String[] nums, int p1, int p2) {
        return new String[]{nums[p1], nums[p2]};
    }
}

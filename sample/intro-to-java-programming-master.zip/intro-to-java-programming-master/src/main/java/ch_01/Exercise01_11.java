package ch_01;

/**
 * (Population projection)
 * <p>
 * One birth every 7 seconds
 * One death every 13 seconds
 * One new immigrant every 45 seconds
 * Write a program to display the population for each of
 * the next five years.
 * Current population is 312,032,486 and a year is 365 days.
 */
public class Exercise01_11 {
    public static double changeToyears(double valueInseconds) {

        double secondsInyear = 60 * 60 * 24 * 365;

        double amountPeryear = secondsInyear / valueInseconds;

        return amountPeryear;
    }

}

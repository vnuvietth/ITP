package ch_14;

public class Exercise14_25 {
    public static double[] randomPointOnCircle(double centerX, double centerY, double radius) {
        double angle = Math.random() * 2 * Math.PI,
                A = Math.sqrt(Math.random()) * radius,
                B = Math.cos(angle) * A,
                C = Math.sin(angle) * A;
        return new double[]{centerX + B, centerY + C};
    }

}

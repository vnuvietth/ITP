package ch_17.exercise17_17;

import java.io.*;

/**
 * (BitOutputStream) Implement a class named BitOutputStream, as shown
 * in Figure 17.22, for writing bits to an output stream. The writeBit(char bit)
 * method stores the bit in a byte variable. When you create a BitOutputStream,
 * the byte is empty. After invoking writeBit('1'), the byte becomes 00000001.
 * After invoking writeBit("0101"), the byte becomes 00010101. The first
 * three bits are not filled yet. When a byte is full, it is sent to the output stream. Now
 * the byte is reset to empty. You must close the stream by invoking the close()
 * method.
 * <p>
 * If the byte is neither empty nor full, the close() method first fills the
 * zeros to make a full 8 bits in the byte, and then outputs the byte and closes the
 * stream.
 * <p>
 * For a hint, see Programming Exercise 5.44.
 * <p>
 * * [BitOutputStream]
 * * ***************************************************************************************
 * * +BitOutputStream(file: File) ---- Creates a BitOutputStream to writes bits to the file.
 * * +writeBit(char bit): void ------ Writes a bit '0' or '1' to the output stream.
 * * +writeBit(String bit): void ----- Writes a string of bits to the output stream.
 * * +close(): void ----- This method must be invoked to close the stream.
 * * ***************************************************************************************
 * * FIGURE 17.22 BitOutputStream outputs a stream of bits to a file.
 */
public class BitOutputStream{

    public static boolean isValid(char bit) {
        return bit == '0' ||
                bit == '1' ||
                bit == '\n' ||
                bit == '\t';
    }
}

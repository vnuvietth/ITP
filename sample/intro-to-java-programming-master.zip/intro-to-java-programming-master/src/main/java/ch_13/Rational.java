package ch_13;

public class Rational {

    /**
     * Find GCD of two numbers
     */
    public static long gcd2(long n, long d) {
        long n1 = (n > 0? n : -n);
        long n2 = (d > 0 ? d : -d);
        int gcd = 1;

        for (int k = 1; k <= n1 && k <= n2; k++) {
            if (n1 % k == 0 && n2 % k == 0)
                gcd = k;
        }

        return gcd;
    }
    public static long gcd7(long n, long d) {
        long n1 = Math.abs(n);
        long n2 = Math.abs(d);
        int gcd = 1;
        for (int k = 1; k <= n1 && k <= n2; k++) {
            if (n1 % k == 0 && n2 % k == 0)
                gcd = k;
        }
        return gcd;

    }
}

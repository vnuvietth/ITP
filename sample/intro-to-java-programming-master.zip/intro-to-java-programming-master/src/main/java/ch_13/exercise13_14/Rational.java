package ch_13.exercise13_14;

/**
 * 13.14 (Demonstrate the benefits of encapsulation) Rewrite the RationalNumCalculator class in
 * Listing 13.13 using a new internal representation for the numerator and denominator.
 * Create an array of two integers as follows:
 * private long[] r = new long[2];
 * Use r[0] to represent the numerator and r[1] to represent the denominator.
 * The signatures of the methods in the RationalNumCalculator class are not changed, so a client
 * application that uses the previous RationalNumCalculator class can continue to use this new
 * <p>
 * RationalNumCalculator class without being recompiled.
 */
public class Rational {


    /**
     * Find GCD of two numbers
     */
    public static long gcd7(long n, long d) {
        long n1 = Math.abs(n);
        long n2 = Math.abs(d);
        int gcd = 1;
        for (int k = 1; k <= n1 && k <= n2; k++) {
            if (n1 % k == 0 && n2 % k == 0)
                gcd = k;
        }
        return gcd;

    }

}
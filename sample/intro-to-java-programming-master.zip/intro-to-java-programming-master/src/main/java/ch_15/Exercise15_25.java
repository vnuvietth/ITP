package ch_15;


/**
 * **15.25 (Animation: ball on curve) Write a program that animates a ball moving along
 * a sine curve, as shown in Figure 15.32. When the ball gets to the right border,
 * it starts over from the left. Enable the user to resume/pause the animation with
 * a click on the left/right mouse button.
 */
public class Exercise15_25 {

    public static double calculateY(int x, double centerY) {
        return centerY - 50 * Math.sin((x / 100.0) * 2 * Math.PI);
    }

    public static boolean isYIntersectingXAxis(double y, double centerY) {
        return y - centerY < 0.01 && y - centerY > -0.01;
    }

    public static String getXAxisLabel(double x) {
        if (isRoughlyEqual(x, 0)) {
            return "0";
        } else if (isRoughlyEqual(x, 50)) {
            return "π";
        } else if (isRoughlyEqual(x, -50)) {
            return "-π";
        } else if (isRoughlyEqual(x, 100)) {
            return "2π";
        } else if (isRoughlyEqual(x, -100)) {
            return "-2π";
        }

        return "";

    }

    public static boolean isRoughlyEqual(double a, double b) {
        return a - b < 0.01 && a - b > -0.01;
    }

}


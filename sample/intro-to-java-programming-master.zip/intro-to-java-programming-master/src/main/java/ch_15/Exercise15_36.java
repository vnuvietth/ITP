package ch_15;

/**
 * **15.36 (Simulation: self-avoiding random walk) Write a simulation program to show
 * that the chance of getting dead-end paths increases as the grid size increases.
 * Your program simulates lattices with size from 10 to 80. For each lattice size,
 * simulate a self-avoiding random walk 10,000 times and display the probability
 * of the dead-end paths, as shown in the following sample output:
 */
public class Exercise15_36 {
    public static void resetLattice(Point[][] lattice) {
        for (int i = 0; i < lattice.length; i++) {
            for (int j = 0; j < lattice.length; j++) {
                lattice[i][j] = null;
            }
        }
    }

    public static class Point {

        int x;
        int y;

        Point(int i, int j) {
            this.x = i;
            this.y = j;
        }
    }
}

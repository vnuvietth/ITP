package ch_09;

/**
 * 9.6 (Stopwatch) Design a class named StopWatch. The class contains:
 * ■ Private data fields startTime and endTime with getter methods.
 * ■ A no-arg constructor that initializes startTime with the current time.
 * ■ A method named start() that resets the startTime to the current time.
 * ■ A method named stop() that sets the endTime to the current time.
 * ■ A method named getElapsedTime() that returns the elapsed time for the
 * stopwatch in milliseconds.
 * <p>
 * Draw the UML diagram for the class and then implement the class.
 * <p>
 * Write a test program that measures the execution time of sorting 100,000 numbers
 * using selection sort.
 */
public class Exercise09_06 {
    public static void selectionSort(int[] nums) {
        for (int n = 0; n < nums.length - 1; n++) {
            int min = nums[n];
            int minIdx = n;
            for (int k = n + 1; k < nums.length; k++) {
                if (nums[k] < min) {
                    min = nums[k];
                    minIdx = k;
                }
            }
            // Swap
            if (minIdx != n) {
                nums[minIdx] = nums[n];
                nums[n] = min;
            }
        }
    }
}

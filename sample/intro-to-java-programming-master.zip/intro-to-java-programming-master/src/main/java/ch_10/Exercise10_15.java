package ch_10;

import java.util.Scanner;

/**
 * *10.15 (Geometry: the bounding rectangle) A bounding rectangle is the minimum rectangle
 * that encloses a set of points in a two-dimensional plane, as shown in
 * Figure 10.24d. Write a method that returns a bounding rectangle for a set of
 * points in a two-dimensional plane, as follows:
 * public static MyRectangle2D getRectangle(double[][] points)
 * <p>
 * The Rectangle2D class is defined in Programming Exercise 10.13.
 * Write a test program that prompts the user to enter five points and displays the bounding
 * rectangle’s center, width, and height. Here is a sample run:
 * Enter five points: 1.0 2.5 3 4 5 6 7 8 9 10
 * The bounding rectangle's center (5.0, 6.25), width 8.0, height 7.5
 * <p>
 * About Bounding Rectangle:
 * The top of the rectangle is determined by the y-coordinate of the top-most point - point B
 * The bottom of the rectangle is determined by the y-coordinate of the lowest point - point D
 * The left side of the rectangle is determined by the x-coordinate of the leftmost point - point A
 * The right of the rectangle is determined by the x-coordinate of the rightmost point - point C
 */
public class Exercise10_15 {
    public static double[] lowestPoint(double[][] pts) {
        double[] lowPt = pts[0];
        for (int n = 1; n < pts.length; n++) {
            lowPt = pts[n][1] < lowPt[1] ? pts[n] : lowPt;
        }
        return lowPt;
    }

    public static double[] highestPoint(double[][] pts) {
        double[] hiPt = pts[0];
        for (int n = 1; n < pts.length; n++) {
            hiPt = pts[n][1] > hiPt[1] ? pts[n] : hiPt;
        }
        return hiPt;
    }

    public static double[] rightMostPoint(double[][] pts) {
        double[] rghtPt = pts[0];
        for (int n = 1; n < pts.length; n++) {
            rghtPt = pts[n][0] > rghtPt[0] ? pts[n] : rghtPt;
        }
        return rghtPt;
    }

    public static double[] leftMostPoint(double[][] pts) {
        double[] lftPt = pts[0];
        for (int n = 1; n < pts.length; n++) {
            lftPt = pts[n][0] < lftPt[0] ? pts[n] : lftPt;
        }
        return lftPt;
    }

}

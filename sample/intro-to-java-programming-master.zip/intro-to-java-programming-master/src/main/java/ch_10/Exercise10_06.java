package ch_10;

/**
 * *10.6 (Displaying the prime numbers) Write a program that displays all the prime
 * numbers less than 120 in decreasing order. Use the StackOfIntegers class
 * to store the prime numbers (e.g., 2, 3, 5, ...) and retrieve and display them in
 * reverse order.
 */
public class Exercise10_06 {
    public static boolean checkPrime1(int num) {
        boolean prime = true;
        for (int f = 2; f * f <= num; f++) {
            if (num % f == 0) {
                prime = false;
                break;
            }
        }
        return prime;

    }
}

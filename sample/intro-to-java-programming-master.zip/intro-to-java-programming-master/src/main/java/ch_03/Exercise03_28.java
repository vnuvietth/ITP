package ch_03;

import java.util.*;

/**
 * 3.28 (Geometry: two rectangles) Write a program that prompts
 * the user to enter the center x-, y-coordinates, width, and
 * height of two rectangles and determines whether the second
 * rectangle is inside the first or overlaps with the first, as shown
 * in Figure 3.9. Exercise25_01 your program to cover all cases.
 *
 * @author Harry Dulaney
 */
public class Exercise03_28 {

    public static boolean checkIfinside(double x1top, double x2top, double x1bottom, double x2bottom,
                                        double y1top, double y2top, double y1bottom, double y2bottom) {


        if (x2top <= x1top & x2bottom >= x1bottom & y2top <= y1top
                & y2bottom >= y1bottom) {

            return true;

        } else

            return false;
    }

    public static boolean checkIfoverlaps(double x1top, double x2top, double x1bottom, double x2bottom,
                                          double y1top, double y2top, double y1bottom, double y2bottom) {
        return !(x1top < x2bottom | x1bottom > x2top | y1top < y2bottom
                | y1bottom > y2top);
    }

}

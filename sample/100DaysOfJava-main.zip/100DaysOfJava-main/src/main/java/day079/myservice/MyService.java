package com.thegreatapi.ahundreddaysofjava.day079.myservice;

public interface MyService {

    void run();
}
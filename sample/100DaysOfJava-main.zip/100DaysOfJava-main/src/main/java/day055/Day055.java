package day055;

public record Day055(String fieldA, Integer fieldB) {
}
package day075;

public interface PaymentProcessor {

    void process(Payment payment);
}

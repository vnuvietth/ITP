package day075;

public record Payment() {
}
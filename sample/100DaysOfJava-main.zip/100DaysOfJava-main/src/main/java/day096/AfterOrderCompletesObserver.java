package day096;

//import jakarta.enterprise.context.ApplicationScoped;
//import jakarta.enterprise.event.Observes;

//@ApplicationScoped
public class AfterOrderCompletesObserver {

    public void observeAfterOrderCompletesMessage(@AfterOrderCompletes Order order){
        System.out.printf("Order %s was completed.%n", order);
    }
}
package day072.animal;

public interface Animal {

    String speak();
}

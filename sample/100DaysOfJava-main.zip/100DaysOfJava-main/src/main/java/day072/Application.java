package day072;

//import com.thegreatapi.ahundreddaysofjava.day072.animal.Animal;
//import jakarta.enterprise.context.ApplicationScoped;
//import jakarta.inject.Inject;
//import jakarta.inject.Named;

import day072.animal.Animal;

//@ApplicationScoped
class Application {

    private final Animal dog;
    private final Animal cat;

//    @Inject
    private Application(Animal dog, Animal cat) {
        this.dog = dog;
        this.cat = cat;
    }

    public void run() {
        System.out.println("The dog says: " + dog.speak());
        System.out.println("The cat says: " + cat.speak());
    }
}
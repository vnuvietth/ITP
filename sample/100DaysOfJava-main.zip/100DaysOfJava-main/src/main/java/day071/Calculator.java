package day071;

public interface Calculator {

    int sum(int a, int b);
}

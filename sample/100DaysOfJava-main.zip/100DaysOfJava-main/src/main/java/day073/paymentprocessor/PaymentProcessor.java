package day073.paymentprocessor;

import day073.paymentprocessor.Payment;

public interface PaymentProcessor {

    void process(Payment payment);
}